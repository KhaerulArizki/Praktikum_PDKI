<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$host = "localhost";
$user = "root";
$pass = "";
$db   = "database";

$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn){
    die("Koneksi Database Gagal : ".mysqli_connect_error());
}

mysqli_set_charset($conn,"utf8mb4");

function bersih($data){
    global $conn;
    return htmlspecialchars(mysqli_real_escape_string($conn,trim($data)));
}
