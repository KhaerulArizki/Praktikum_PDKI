<?php
session_start();
require_once "config/config.php";

// Cek koneksi
if (!$conn) {
    die("Koneksi database gagal.");
}

// Hanya menerima POST
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: dashboard_admin.php");
    exit();
}

// Ambil data dari form
$nama_kelas = trim($_POST['nama_kelas']);
$guru_id = trim($_POST['guru_id']);
$mata_pelajaran_id = trim($_POST['mata_pelajaran_id']);

$jadwal = isset($_POST['jadwal']) ? trim($_POST['jadwal']) : "";
$ruangan = isset($_POST['ruangan']) ? trim($_POST['ruangan']) : "";
$kuota = isset($_POST['kuota']) ? trim($_POST['kuota']) : 0;
$status = isset($_POST['status']) ? trim($_POST['status']) : "aktif";

// Validasi
if (
    empty($nama_kelas) ||
    empty($guru_id) ||
    empty($mata_pelajaran_id)
) {

    echo "<script>
            alert('Data kelas belum lengkap!');
            window.history.back();
          </script>";
    exit();
}

// Cek apakah nama kelas sudah ada
$cek = mysqli_prepare(
    $conn,
    "SELECT id FROM kelas WHERE nama_kelas=?"
);

mysqli_stmt_bind_param($cek, "s", $nama_kelas);
mysqli_stmt_execute($cek);
mysqli_stmt_store_result($cek);

if (mysqli_stmt_num_rows($cek) > 0) {

    echo "<script>
            alert('Nama kelas sudah ada!');
            window.history.back();
          </script>";

    exit();
}

// Simpan data
$sql = mysqli_prepare(
    $conn,
    "INSERT INTO kelas
    (nama_kelas,guru_id,mata_pelajaran_id,jadwal,ruangan,kuota,status,created_at)
    VALUES(?,?,?,?,?,?,?,NOW())"
);

mysqli_stmt_bind_param(
    $sql,
    "siissis",
    $nama_kelas,
    $guru_id,
    $mata_pelajaran_id,
    $jadwal,
    $ruangan,
    $kuota,
    $status
);

if (mysqli_stmt_execute($sql)) {

    echo "<script>
            alert('Kelas berhasil ditambahkan.');
            window.location='dashboard_admin.php';
          </script>";

} else {

    echo "<script>
            alert('Gagal menambahkan kelas!');
            window.history.back();
          </script>";

}
?>