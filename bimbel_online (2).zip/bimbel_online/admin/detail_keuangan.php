<?php
session_start();
require_once "../config/config.php";

include "header.php";
include "sidebar.php";

/** @var mysqli $conn */

if (!isset($_GET['id'])) {
    header("Location: kelola_keuangan.php");
    exit;
}

$id = intval($_GET['id']);

$query = mysqli_query($conn, "
SELECT
    pembayaran.*,
    users.nama_lengkap,
    mata_pelajaran.nama_mapel

FROM pembayaran

INNER JOIN siswa
ON pembayaran.siswa_id = siswa.id

INNER JOIN users
ON siswa.user_id = users.id

INNER JOIN mata_pelajaran
ON pembayaran.mata_pelajaran_id = mata_pelajaran.id

WHERE pembayaran.id='$id'
");

$data = mysqli_fetch_assoc($query);

if (!$data) {
    header("Location: kelola_keuangan.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">

<title>Detail Pembayaran</title>

<style>

body{

font-family:Segoe UI, sans-serif;
background:#f5f5f5;

}

.container{

width:800px;

margin:40px auto;

background:#fff;

padding:30px;

border-radius:10px;

box-shadow:0 2px 10px rgba(0,0,0,.1);

}

h2{

margin-bottom:25px;

color:#333;

}

table{

width:100%;

border-collapse:collapse;

}

table td{

padding:12px;

border-bottom:1px solid #eee;

}

.label{

font-weight:bold;

width:220px;

background:#fafafa;

}

.badge{

padding:6px 15px;

border-radius:20px;

color:white;

font-size:13px;

font-weight:bold;

}

.lunas{

background:#28a745;

}

.belum{

background:#dc3545;

}

.button{

display:inline-block;

margin-top:30px;

padding:10px 20px;

background:#667eea;

color:white;

text-decoration:none;

border-radius:6px;

}

.button:hover{

background:#5563d6;

}

</style>

</head>

<body>

<div class="container">

<h2>Detail Pembayaran</h2>

<table>

<tr>

<td class="label">Nama Siswa</td>

<td><?= htmlspecialchars($data['nama_lengkap']); ?></td>

</tr>

<tr>

<td class="label">Mata Pelajaran</td>

<td><?= htmlspecialchars($data['nama_mapel']); ?></td>

</tr>

<tr>

<td class="label">Jumlah Pembayaran</td>

<td>

Rp <?= number_format($data['jumlah'],0,',','.'); ?>

</td>

</tr>

<tr>

<td class="label">Tanggal Tagihan</td>

<td><?= $data['tanggal_tagihan']; ?></td>

</tr>

<tr>

<td class="label">Tanggal Bayar</td>

<td>

<?= !empty($data['tanggal_bayar']) ? $data['tanggal_bayar'] : '-'; ?>

</td>

</tr>

<tr>

<td class="label">Status</td>

<td>

<?php

if($data['status']=="Lunas"){

echo "<span class='badge lunas'>Lunas</span>";

}else{

echo "<span class='badge belum'>Belum Lunas</span>";

}

?>

</td>

</tr>

<tr>

<td class="label">Keterangan</td>

<td>

<?= nl2br(htmlspecialchars($data['keterangan'])); ?>

</td>

</tr>

</table>

<a href="kelola_keuangan.php" class="button">

← Kembali

</a>

<a href="edit_keuangan.php?id=<?= $data['id']; ?>" class="button">

✏ Edit

</a>

</div>

</body>
</html>