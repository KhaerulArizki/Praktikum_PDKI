<?php
session_start();
require_once "../config/config.php";

/** @var mysqli $conn */

// Pastikan data dikirim melalui POST
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: kelola_jadwal.php");
    exit;
}

// Ambil data
$id           = intval($_POST['id']);
$kelas_id     = intval($_POST['kelas_id']);
$hari         = mysqli_real_escape_string($conn, trim($_POST['hari']));
$jam_mulai    = mysqli_real_escape_string($conn, trim($_POST['jam_mulai']));
$jam_selesai  = mysqli_real_escape_string($conn, trim($_POST['jam_selesai']));

// Validasi
if (
    empty($id) ||
    empty($kelas_id) ||
    empty($hari) ||
    empty($jam_mulai) ||
    empty($jam_selesai)
) {
    header("Location: edit_jadwal.php?id=$id&msg=kosong");
    exit;
}

// Update data
$sql = "
UPDATE jadwal_mengajar SET
    kelas_id = '$kelas_id',
    hari = '$hari',
    jam_mulai = '$jam_mulai',
    jam_selesai = '$jam_selesai'
WHERE id = '$id'
";

$query = mysqli_query($conn, $sql);

if ($query) {

    header("Location: kelola_jadwal.php?msg=updated");
    exit;

} else {

    echo "<h2>Update Jadwal Gagal</h2>";
    echo "<hr>";
    echo "<b>Error:</b> " . mysqli_error($conn);
    echo "<br><br>";
    echo "<a href='edit_jadwal.php?id=".$id."'>Kembali</a>";

}
?>