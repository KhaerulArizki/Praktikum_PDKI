<?php
session_start();
require_once "../config/config.php";

/** @var mysqli $conn */

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: kelola_jadwal.php");
    exit;
}

$id          = intval($_POST['id']);
$kelas_id    = intval($_POST['kelas_id']);
$hari        = mysqli_real_escape_string($conn, trim($_POST['hari']));
$jam_mulai   = mysqli_real_escape_string($conn, trim($_POST['jam_mulai']));
$jam_selesai = mysqli_real_escape_string($conn, trim($_POST['jam_selesai']));

if (
    empty($kelas_id) ||
    empty($hari) ||
    empty($jam_mulai) ||
    empty($jam_selesai)
) {
    header("Location: kelola_jadwal.php?msg=error");
    exit;
}

/*
|--------------------------------------------------------------------------
| Validasi Jam
|--------------------------------------------------------------------------
*/

if ($jam_mulai >= $jam_selesai) {
    header("Location: kelola_jadwal.php?msg=jam");
    exit;
}

/*
|--------------------------------------------------------------------------
| Cek Bentrok Jadwal
|--------------------------------------------------------------------------
*/

$cek = mysqli_query($conn,"
SELECT id
FROM jadwal_mengajar
WHERE kelas_id='$kelas_id'
AND hari='$hari'
AND id != '$id'
AND(
    ('$jam_mulai' BETWEEN jam_mulai AND jam_selesai)
    OR
    ('$jam_selesai' BETWEEN jam_mulai AND jam_selesai)
    OR
    (jam_mulai BETWEEN '$jam_mulai' AND '$jam_selesai')
)
");

if(mysqli_num_rows($cek)>0){

    header("Location: kelola_jadwal.php?msg=jadwal");
    exit;

}

/*
|--------------------------------------------------------------------------
| Update Data
|--------------------------------------------------------------------------
*/

$update = mysqli_query($conn,"
UPDATE jadwal_mengajar
SET
    kelas_id='$kelas_id',
    hari='$hari',
    jam_mulai='$jam_mulai',
    jam_selesai='$jam_selesai'
WHERE id='$id'
");

if($update){

    header("Location: kelola_jadwal.php?msg=updated");

}else{

    header("Location: kelola_jadwal.php?msg=error");

}

exit;
?>