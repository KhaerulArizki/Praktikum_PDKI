<?php
session_start();
require_once "../config/config.php";

include "header.php";
include "sidebar.php";

/** @var mysqli $conn */

if (!isset($_GET['id'])) {
    header("Location: kelola_keuangan.php");
    exit;
}

$id = intval($_GET['id']);

$query = mysqli_query($conn, "
SELECT
    pembayaran.*,
    users.nama_lengkap
FROM pembayaran

INNER JOIN siswa
ON pembayaran.siswa_id = siswa.id

INNER JOIN users
ON siswa.user_id = users.id

WHERE pembayaran.id='$id'
");

$data = mysqli_fetch_assoc($query);

if (!$data) {
    header("Location: kelola_keuangan.php");
    exit;
}

// Data siswa
$result_siswa = mysqli_query($conn,"
SELECT
siswa.id,
users.nama_lengkap

FROM siswa

INNER JOIN users
ON siswa.user_id=users.id

ORDER BY users.nama_lengkap ASC
");

// Data Mata Pelajaran
$result_mapel = mysqli_query($conn,"
SELECT
id,
nama_mapel

FROM mata_pelajaran

ORDER BY nama_mapel ASC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<title>Edit Pembayaran</title>

<style>

body{

font-family:Segoe UI,sans-serif;
background:#f5f5f5;

}

.container{

width:700px;

margin:40px auto;

background:#fff;

padding:30px;

border-radius:10px;

box-shadow:0 2px 10px rgba(0,0,0,.1);

}

h2{

margin-bottom:25px;

}

.form-group{

margin-bottom:18px;

}

label{

display:block;

margin-bottom:8px;

font-weight:bold;

}

input,
select,
textarea{

width:100%;

padding:10px;

border:1px solid #ccc;

border-radius:6px;

}

textarea{

height:120px;

resize:vertical;

}

button{

padding:12px 20px;

background:#667eea;

color:white;

border:none;

border-radius:6px;

cursor:pointer;

font-size:15px;

}

button:hover{

background:#5563d6;

}

.btn{

display:inline-block;

padding:12px 20px;

background:#6c757d;

color:white;

text-decoration:none;

border-radius:6px;

margin-left:10px;

}

.btn:hover{

background:#5a6268;

}

</style>

</head>

<body>

<div class="container">

<h2>Edit Pembayaran</h2>

<form action="update_keuangan.php" method="POST">

<input
type="hidden"
name="id"
value="<?= $data['id']; ?>">

<div class="form-group">

<label>Nama Siswa</label>

<select name="siswa_id" required>

<?php while($siswa=mysqli_fetch_assoc($result_siswa)): ?>

<option
value="<?= $siswa['id']; ?>"

<?= ($siswa['id']==$data['siswa_id']) ? 'selected' : ''; ?>>

<?= htmlspecialchars($siswa['nama_lengkap']); ?>

</option>

<?php endwhile; ?>

</select>

</div>

<div class="form-group">

<label>Mata Pelajaran</label>

<select
name="mata_pelajaran_id"
required>

<?php while($mapel=mysqli_fetch_assoc($result_mapel)): ?>

<option
value="<?= $mapel['id']; ?>"

<?= ($mapel['id']==$data['mata_pelajaran_id']) ? 'selected' : ''; ?>>

<?= htmlspecialchars($mapel['nama_mapel']); ?>

</option>

<?php endwhile; ?>

</select>

</div>

<div class="form-group">

<label>Jumlah</label>

<input
type="number"
name="jumlah"
required
value="<?= $data['jumlah']; ?>">

</div>

<div class="form-group">

<label>Tanggal Tagihan</label>

<input
type="date"
name="tanggal_tagihan"
required
value="<?= $data['tanggal_tagihan']; ?>">

</div>

<div class="form-group">

<label>Tanggal Bayar</label>

<input
type="date"
name="tanggal_bayar"
value="<?= $data['tanggal_bayar']; ?>">

</div>

<div class="form-group">

<label>Status</label>

<select name="status">

<option
value="Belum Lunas"
<?= ($data['status']=="Belum Lunas")?"selected":""; ?>>

Belum Lunas

</option>

<option
value="Lunas"
<?= ($data['status']=="Lunas")?"selected":""; ?>>

Lunas

</option>

</select>

</div>

<div class="form-group">

<label>Keterangan</label>

<textarea
name="keterangan"><?= htmlspecialchars($data['keterangan']); ?></textarea>

</div>

<button type="submit">

💾 Simpan Perubahan

</button>

<a
href="kelola_keuangan.php"
class="btn">

← Kembali

</a>

</form>

</div>

</body>
</html>