<?php
session_start();

require_once "../config/config.php";

/** @var mysqli $conn */

// Cek apakah ID dikirim
if (!isset($_GET['id'])) {
    header("Location: kelola_keuangan.php");
    exit;
}

// Ambil ID pembayaran
$id = intval($_GET['id']);

// Cek apakah data ada
$cek = mysqli_query($conn, "
    SELECT id
    FROM pembayaran
    WHERE id = '$id'
");

if (mysqli_num_rows($cek) == 0) {
    header("Location: kelola_keuangan.php?msg=notfound");
    exit;
}

// Hapus data pembayaran
$hapus = mysqli_query($conn, "
    DELETE FROM pembayaran
    WHERE id = '$id'
");

// Cek hasil
if ($hapus) {

    header("Location: kelola_keuangan.php?msg=deleted");
    exit;

} else {

    header("Location: kelola_keuangan.php?msg=error");
    exit;

}
?>