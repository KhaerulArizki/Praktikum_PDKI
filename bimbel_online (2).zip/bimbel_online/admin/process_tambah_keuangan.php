<?php
session_start();
require_once "../config/config.php";
/**@var mysqli $conn*/
$siswa_id = $_POST['siswa_id'];
$mata_pelajaran_id = $_POST['mata_pelajaran_id'];
$jumlah = $_POST['jumlah'];
$tanggal_tagihan = $_POST['tanggal_tagihan'];
$tanggal_bayar = $_POST['tanggal_bayar'];
$status = $_POST['status'];
$keterangan = $_POST['keterangan'];

$query = mysqli_query($conn, "INSERT INTO pembayaran
(
    siswa_id,
    mata_pelajaran_id,
    jumlah,
    tanggal_tagihan,
    tanggal_bayar,
    status,
    keterangan
)
VALUES
(
    '$siswa_id',
    '$mata_pelajaran_id',
    '$jumlah',
    '$tanggal_tagihan',
    '$tanggal_bayar',
    '$status',
    '$keterangan'
)");

if($query){
    header("Location: kelola_keuangan.php?msg=success");
}else{
    echo mysqli_error($conn);
}