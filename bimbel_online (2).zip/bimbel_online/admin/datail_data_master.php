<?php
session_start();
require_once "../config/config.php";

/** @var mysqli $conn */

if (!isset($_GET['id']) || !isset($_GET['status'])) {
    header("Location: kelola_data_master.php");
    exit;
}

$id = intval($_GET['id']);
$status = $_GET['status'];

if ($status == "Guru") {

    $sql = "SELECT
                guru.id,
                guru.user_id,
                guru.nip AS nomor,
                users.nama_lengkap,
                users.email,
                users.no_hp,
                users.alamat
            FROM guru
            INNER JOIN users
                ON guru.user_id = users.id
            WHERE guru.id='$id'";

} else {

    $sql = "SELECT
                siswa.id,
                siswa.user_id,
                siswa.nis AS nomor,
                users.nama_lengkap,
                users.email,
                users.no_hp,
                users.alamat
            FROM siswa
            INNER JOIN users
                ON siswa.user_id = users.id
            WHERE siswa.id='$id'";
}

$query = mysqli_query($conn, $sql);

if (!$query) {
    die("Query Error : " . mysqli_error($conn));
}

$data = mysqli_fetch_assoc($query);

if (!$data) {
    header("Location: kelola_data_master.php");
    exit;
}

$nama = "Admin";

if(isset($_SESSION['nama_lengkap'])){
    $nama = $_SESSION['nama_lengkap'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Edit Data Master</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
}

body{
font-family:'Segoe UI',Tahoma,sans-serif;
background:#f5f7fa;
}

.header{

background:linear-gradient(135deg,#667eea,#764ba2);
color:white;
padding:20px 30px;
display:flex;
justify-content:space-between;
align-items:center;

}

.container{

width:750px;
margin:35px auto;
background:white;
padding:30px;
border-radius:15px;
box-shadow:0 3px 12px rgba(0,0,0,.1);

}

h2{

margin-bottom:25px;
color:#333;

}

label{

display:block;
margin-top:18px;
margin-bottom:8px;
font-weight:bold;

}

input,
textarea{

width:100%;
padding:12px;
border:1px solid #ddd;
border-radius:8px;
font-size:15px;

}

textarea{

height:120px;
resize:vertical;

}

.button-group{

margin-top:30px;
display:flex;
gap:10px;

}

.btn{

padding:12px 22px;
border:none;
border-radius:8px;
cursor:pointer;
font-size:15px;
text-decoration:none;
color:white;

}

.btn-save{

background:#28a745;

}

.btn-save:hover{

background:#218838;

}

.btn-back{

background:#6c757d;

}

.btn-back:hover{

background:#5a6268;

}

</style>

</head>

<body>

<div class="header">

<h2>Edit Data <?= htmlspecialchars($status); ?></h2>

<div><?= htmlspecialchars($nama); ?></div>

</div>

<div class="container">

<form action="update_data_master.php" method="POST">

<input type="hidden" name="id" value="<?= $data['id']; ?>">
<input type="hidden" name="user_id" value="<?= $data['user_id']; ?>">
<input type="hidden" name="status" value="<?= $status; ?>">

<label>Nama Lengkap</label>
<input
type="text"
name="nama_lengkap"
value="<?= htmlspecialchars($data['nama_lengkap']); ?>"
required>

<label>Email</label>
<input
type="email"
name="email"
value="<?= htmlspecialchars($data['email']); ?>"
required>

<label>NIP / NIS</label>
<input
type="text"
name="nomor"
value="<?= htmlspecialchars($data['nomor']); ?>"
required>

<label>No HP</label>
<input
type="text"
name="no_hp"
value="<?= htmlspecialchars($data['no_hp']); ?>">

<label>Alamat</label>

<textarea
name="alamat"><?= htmlspecialchars($data['alamat']); ?></textarea>

<div class="button-group">

<button
type="submit"
class="btn btn-save">

💾 Simpan Perubahan

</button>

<a
href="kelola_data_master.php"
class="btn btn-back">

⬅ Kembali

</a>

</div>

</form>

</div>

</body>

</html>