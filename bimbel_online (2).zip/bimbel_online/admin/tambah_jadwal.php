<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// PERBAIKAN: Sesuaikan path ini dengan letak folder config Anda. 
// Jika file ini di dalam folder 'proses', gunakan "../config/config.php"
require_once "config/config.php";

// Cek koneksi
if (!$conn) {
    die("Koneksi database gagal.");
}

// Hanya menerima POST
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: dashboard_admin.php");
    exit();
}

// Ambil data dan bersihkan
$kelas_id   = isset($_POST['kelas_id']) ? intval($_POST['kelas_id']) : 0;
$guru_id    = isset($_POST['guru_id']) ? intval($_POST['guru_id']) : 0;
$hari       = isset($_POST['hari']) ? trim($_POST['hari']) : "";
$jam_mulai  = isset($_POST['jam_mulai']) ? trim($_POST['jam_mulai']) : "";
$jam_selesai= isset($_POST['jam_selesai']) ? trim($_POST['jam_selesai']) : "";

// Validasi input kosong
if (
    $kelas_id == 0 ||
    $guru_id == 0 ||
    empty($hari) ||
    empty($jam_mulai) ||
    empty($jam_selesai)
) {
    echo "<script>
            alert('Data jadwal belum lengkap!');
            window.history.back();
          </script>";
    exit();
}

// Cek bentrok jadwal guru
$cek = mysqli_prepare(
    $conn,
    "SELECT id
     FROM jadwal_mengajar
     WHERE guru_id=?
     AND hari=?
     AND (
        (? BETWEEN jam_mulai AND jam_selesai)
        OR
        (? BETWEEN jam_mulai AND jam_selesai)
     )"
);

mysqli_stmt_bind_param(
    $cek,
    "isss",
    $guru_id,
    $hari,
    $jam_mulai,
    $jam_selesai
);

mysqli_stmt_execute($cek);
mysqli_stmt_store_result($cek);

if (mysqli_stmt_num_rows($cek) > 0) {
    echo "<script>
            alert('Guru sudah memiliki jadwal pada jam tersebut!');
            window.history.back();
          </script>";
    exit();
}
mysqli_stmt_close($cek); // Menutup statement cek jadwal

// Simpan jadwal
$sql = mysqli_prepare(
    $conn,
    "INSERT INTO jadwal_mengajar
    (
        kelas_id,
        guru_id,
        hari,
        jam_mulai,
        jam_selesai,
        created_at
    )
    VALUES
    (
        ?,?,?,?,?,
        NOW()
    )"
);

mysqli_stmt_bind_param(
    $sql,
    "iisss",
    $kelas_id,
    $guru_id,
    $hari,
    $jam_mulai,
    $jam_selesai
);

// PERBAIKAN: Jalankan eksekusi di dalam kondisi IF agar ELSE di bawahnya berfungsi
if (mysqli_stmt_execute($sql)) {
    echo "<script>
            alert('Jadwal berhasil ditambahkan');
            window.location='../admin/kelola_jadwal.php';
          </script>";
} else {
    echo "<script>
            alert('Gagal menambahkan jadwal!');
            window.history.back();
          </script>";
}

mysqli_stmt_close($sql); // Menutup statement insert
mysqli_close($conn); // Menutup koneksi database
?>