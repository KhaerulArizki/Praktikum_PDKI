<?php
require_once "config/config.php";

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM guru WHERE id='$id'");

header("Location: kelola_guru.php");
exit();
?>