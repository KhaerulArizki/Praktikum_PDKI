<?php
session_start();
require_once "../config/config.php";

/** @var mysqli $conn */

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: kelola_data_master.php");
    exit;
}

$id            = intval($_POST['id']);
$user_id       = intval($_POST['user_id']);
$status        = $_POST['status'];

$nama_lengkap  = mysqli_real_escape_string($conn, trim($_POST['nama_lengkap']));
$email         = mysqli_real_escape_string($conn, trim($_POST['email']));
$nomor         = mysqli_real_escape_string($conn, trim($_POST['nomor']));
$no_hp         = mysqli_real_escape_string($conn, trim($_POST['no_hp']));
$alamat        = mysqli_real_escape_string($conn, trim($_POST['alamat']));

if (
    empty($nama_lengkap) ||
    empty($email) ||
    empty($nomor)
) {
    header("Location: kelola_data_master.php?msg=error");
    exit;
}

/*
|--------------------------------------------------------------------------
| Cek Email
|--------------------------------------------------------------------------
*/

$cekEmail = mysqli_query(
    $conn,
    "SELECT id
     FROM users
     WHERE email='$email'
     AND id != '$user_id'"
);

if (mysqli_num_rows($cekEmail) > 0) {

    header("Location: kelola_data_master.php?msg=email");
    exit;
}

/*
|--------------------------------------------------------------------------
| Mulai Transaction
|--------------------------------------------------------------------------
*/

mysqli_begin_transaction($conn);

try {

    /*
    |--------------------------------------------------------------------------
    | Update users
    |--------------------------------------------------------------------------
    */

    $updateUser = mysqli_query($conn, "
        UPDATE users
        SET
            nama_lengkap='$nama_lengkap',
            email='$email',
            no_hp='$no_hp',
            alamat='$alamat'
        WHERE id='$user_id'
    ");

    if (!$updateUser) {
        throw new Exception(mysqli_error($conn));
    }

    /*
    |--------------------------------------------------------------------------
    | Update Guru / Siswa
    |--------------------------------------------------------------------------
    */

    if ($status == "Guru") {

        $updateGuru = mysqli_query($conn, "
            UPDATE guru
            SET
                nip='$nomor'
            WHERE id='$id'
        ");

        if (!$updateGuru) {
            throw new Exception(mysqli_error($conn));
        }

    } else {

        $updateSiswa = mysqli_query($conn, "
            UPDATE siswa
            SET
                nis='$nomor'
            WHERE id='$id'
        ");

        if (!$updateSiswa) {
            throw new Exception(mysqli_error($conn));
        }

    }
    mysqli_commit($conn);

    header("Location: kelola_data_master.php?msg=updated");
    exit;

} catch (Exception $e) {

    mysqli_rollback($conn);

    echo "<h3>Terjadi Kesalahan</h3>";
    echo "<pre>";
    echo $e->getMessage();
    echo "</pre>";

}
?>