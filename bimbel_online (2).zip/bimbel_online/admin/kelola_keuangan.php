<?php
session_start();

require_once "../config/config.php";

/** @var mysqli $conn */

// ===============================
// Nama Admin
// ===============================
$nama = $_SESSION['nama_lengkap'] ?? $_SESSION['nama'] ?? "Admin";


// ===============================
// Hapus Data
// ===============================
if (isset($_GET['action']) && $_GET['action'] == "delete" && isset($_GET['id'])) {

    $id = intval($_GET['id']);

    $hapus = mysqli_query($conn, "
        DELETE FROM pembayaran
        WHERE id='$id'
    ");

    if ($hapus) {
        header("Location: kelola_keuangan.php?msg=deleted");
    } else {
        header("Location: kelola_keuangan.php?msg=error");
    }
    exit;
}


// ===============================
// Ambil Data Pembayaran
// ===============================
$result_keuangan = mysqli_query($conn, "

SELECT

pembayaran.id,
users.nama_lengkap,
mata_pelajaran.nama_mapel,
pembayaran.jumlah,
pembayaran.tanggal_tagihan,
pembayaran.tanggal_bayar,
pembayaran.status,
pembayaran.keterangan

FROM pembayaran

INNER JOIN siswa
ON pembayaran.siswa_id = siswa.id

INNER JOIN users
ON siswa.user_id = users.id

INNER JOIN mata_pelajaran
ON pembayaran.mata_pelajaran_id = mata_pelajaran.id

ORDER BY pembayaran.id DESC

");

if (!$result_keuangan) {

    die("Query Error : " . mysqli_error($conn));

}


// ===============================
// Total Data
// ===============================
$total_keuangan = mysqli_num_rows($result_keuangan);


// ===============================
// Data Siswa
// ===============================
$result_siswa = mysqli_query($conn, "

SELECT

siswa.id,
users.nama_lengkap

FROM siswa

INNER JOIN users
ON siswa.user_id = users.id

ORDER BY users.nama_lengkap ASC

");


// ===============================
// Data Mata Pelajaran
// ===============================
$result_mapel = mysqli_query($conn, "

SELECT

id,
nama_mapel

FROM mata_pelajaran

ORDER BY nama_mapel ASC

");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Keuangan - Bimbel Online</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }

        /* Header Styles */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo {
            font-size: 24px;
        }

        .header-title h2 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 20px;
            border: 1px solid white;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: white;
            color: #667eea;
        }

        /* Layout Styles */
        .layout {
            display: flex;
            min-height: calc(100vh - 80px);
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: #2c3e50;
            padding: 20px 0;
        }

        .sidebar-header {
            padding: 20px;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 10px;
        }

        .menu-item {
            padding: 15px 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #bdc3c7;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(52, 152, 219, 0.2);
            color: white;
            border-left-color: #3498db;
        }

        .menu-icon {
            font-size: 20px;
        }

        /* Container Styles */
        .container {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }

        /* Page Header */
        .page-header{
display:flex;
justify-content:space-between;
align-items:center;
flex-wrap:wrap;
gap:20px;
margin-bottom:25px;
}

        .page-header h1 {
            font-size: 28px;
            color: #333;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        /* Stats Card */
        .stats-card{

width:250px;

background:#fff;

padding:25px;

border-radius:15px;

display:flex;

align-items:center;

gap:18px;

box-shadow:0 5px 15px rgba(0,0,0,.08);

margin-bottom:25px;

}
        .stats-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .stats-info h3 {
            font-size: 32px;
            color: #333;
        }

        .stats-info p {
            color: #666;
            font-size: 14px;
        }

        /* Search Box */
        .search-box {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: #667eea;
        }

        /* Table Styles */
        .table-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        thead th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }

        tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.3s;
        }

        tbody tr:hover {
            background-color: #f8f9fa;
        }

        tbody td {
            padding: 15px;
            font-size: 14px;
            color: #333;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-edit, .btn-delete, .btn-view {
            padding: 6px 12px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }

        .btn-view {
            background: #3498db;
            color: white;
        }

        .btn-edit {
            background: #2ecc71;
            color: white;
        }

        .btn-delete {
            background: #e74c3c;
            color: white;
        }

        .btn-view:hover {
            background: #2980b9;
        }

        .btn-edit:hover {
            background: #27ae60;
        }

        .btn-delete:hover {
            background: #c0392b;
        }
        .badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:bold;
    color:#fff;
}
.table-container{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

tbody tr:nth-child(even){
    background:#fafafa;
}

tbody tr:hover{
    background:#eef5ff;
}
.badge-success{
    background:#28a745;
}

.badge-danger{
    background:#dc3545;
}

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }

        /* Alert Messages */
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            animation: slideDown 0.3s;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .modal-header h2 {
            color: #333;
            font-size: 24px;
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover {
            color: #333;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s;
        }
        .action-buttons a{
    transition:.3s;
}

.action-buttons a:hover{
    transform:translateY(-2px);
}

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .layout {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
            }

            .page-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .table-container {
                overflow-x: auto;
            }

            table {
                min-width: 800px;
            }
        }
    </style>
</head>
<body>

<div class="header">
    <div class="header-left">
        <div class="header-title">
            <h2>Kelola Keuangan</h2>
        </div>
    </div>
    <div class="header-right">
        <div class="user-info">
            <div class="user-avatar">
                <?= strtoupper(substr($nama,0,1)); ?>
            </div>
            <span><?= htmlspecialchars($nama); ?></span>
        </div>
        <a href="../logout.php" class="logout-btn">
    Logout
</a>
    </div>
</div>
<div class="layout">
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Bimbel Online</h3>
            </div>
            <a href="dashboard_admin.php" class="menu-item">
                <span class="menu-icon"></span>
                <span>Dashboard</span>
            </a>
        </div>
<div class="container">
        <div class="page-header">
    <div>
        <h1>💰 Kelola Keuangan</h1>
        <p style="color:#777;margin-top:5px;">
            Kelola seluruh pembayaran siswa.
        </p>
    </div>

    <div style="display:flex;gap:15px;">
        <a href="dashboard_admin.php" class="btn-primary"
           style="background:#6c757d;">
            ⬅ Dashboard
        </a>

        <button class="btn-primary"
onclick="openModal('modalTambahPembayaran')">
➕ Tambah Pembayaran
</button>
    </div>
</div>
<?php if(isset($_GET['msg'])): ?>
    <?php if($_GET['msg']=="success"): ?>
        <div class="alert alert-success">
            ✓ Data pembayaran berhasil ditambahkan.
        </div>
    <?php elseif($_GET['msg']=="updated"): ?>
        <div class="alert alert-success">
            ✓ Data pembayaran berhasil diperbarui.
        </div>
    <?php elseif($_GET['msg']=="deleted"): ?>
        <div class="alert alert-success">
            ✓ Data pembayaran berhasil dihapus.
        </div>
    <?php elseif($_GET['msg']=="error"): ?>
        <div class="alert alert-danger">
            ✖ Terjadi kesalahan.
        </div>
    <?php endif; ?>
<?php endif; ?>

 <div style="display:flex;gap:20px;margin-bottom:25px;">

        <div class="stats-card">
    <div class="stats-icon">
        💰
    </div>
    <div class="stats-info">
        <h3><?= $total_keuangan; ?></h3>
        <p>Total Pembayaran</p>
    </div>

</div>
</div>

 <div class="search-box">
        <input
            type="text"
            id="searchInput"
            placeholder="Cari berdasarkan nama, email atau NIP/NIS..."
            onkeyup="searchTable()">
    </div>
</div>
<div class="table-container">
<?php if(mysqli_num_rows($result_keuangan)>0): ?>
<table id="keuanganTable">
<thead>
<tr>
<th>No</th>
<th>Nama Siswa</th>
<th>Mata Pelajaran</th>
<th>Jumlah</th>
<th>Tanggal Tagihan</th>
<th>Tanggal Bayar</th>
<th>Status</th>
<th>Keterangan</th>
<th width="180">Aksi</th>
</tr>

</thead>

<tbody>

<?php

$no=1;

while($data=mysqli_fetch_assoc($result_keuangan)):

?>

<tr>

<td><?= $no++; ?></td>

<td><?= htmlspecialchars($data['nama_lengkap']); ?></td>

<td><?= htmlspecialchars($data['nama_mapel']); ?></td>

<td>

Rp <?= number_format($data['jumlah'],0,',','.'); ?>

</td>

<td><?= htmlspecialchars($data['tanggal_tagihan']); ?></td>

<td>

<?= !empty($data['tanggal_bayar']) ? htmlspecialchars($data['tanggal_bayar']) : '-'; ?>

</td>

<td>

<?php

if($data['status']=="Lunas"){

echo "<span class='badge badge-success'>Lunas</span>";

}else{

echo "<span class='badge badge-danger'>Belum Lunas</span>";

}

?>

</td>

<td><?= htmlspecialchars($data['keterangan']); ?></td>

<td>

<div class="action-buttons">

<a

href="detail_keuangan.php?id=<?= $data['id']; ?>"

class="btn-view">

👁 Lihat

</a>

<a

href="edit_keuangan.php?id=<?= $data['id']; ?>"

class="btn-edit">

✏ Edit

</a>
<a
href="hapus_keuangan.php?id=<?= $data['id']; ?>"
class="btn-delete"
onclick="return confirm('Yakin ingin menghapus data pembayaran ini?');">
🗑️ Hapus
</a>

</div>

</td>

</tr>

<?php endwhile; ?>

<?php endif; ?>

</div>
</tbody>
</table>
<div style="padding:40px;text-align:center;">
<h3>Belum ada data pembayaran SPP.</h3>
</div>
</div>

<div id="modalTambahPembayaran" class="modal">

    <div class="modal-content">

        <div class="modal-header">

            <h2>Tambah Pembayaran</h2>

            <span class="close" onclick="closeModal('modalTambahPembayaran')">&times;</span>

        </div>

        <form action="process_tambah_keuangan.php" method="POST">

            <!-- Siswa -->
            <div class="form-group">

                <label>Nama Siswa</label>

                <select name="siswa_id" required>

                    <option value="">-- Pilih Siswa --</option>

                    <?php while($siswa=mysqli_fetch_assoc($result_siswa)): ?>

                        <option value="<?= $siswa['id']; ?>">

                            <?= htmlspecialchars($siswa['nama_lengkap']); ?>

                        </option>

                    <?php endwhile; ?>

                </select>

            </div>

            <!-- Mata Pelajaran -->
            <div class="form-group">

                <label>Mata Pelajaran</label>

                <select name="mata_pelajaran_id" required>

                    <option value="">-- Pilih Mata Pelajaran --</option>

                    <?php while($mapel=mysqli_fetch_assoc($result_mapel)): ?>

                        <option value="<?= $mapel['id']; ?>">

                            <?= htmlspecialchars($mapel['nama_mapel']); ?>

                        </option>

                    <?php endwhile; ?>

                </select>

            </div>

            <!-- Jumlah -->
            <div class="form-group">

                <label>Jumlah Pembayaran</label>

                <input
                    type="number"
                    name="jumlah"
                    required
                    min="0"
                    placeholder="Contoh : 500000">

            </div>

            <!-- Tanggal Tagihan -->
            <div class="form-group">

                <label>Tanggal Tagihan</label>

                <input
                    type="date"
                    name="tanggal_tagihan"
                    required>

            </div>

            <!-- Tanggal Bayar -->
            <div class="form-group">

                <label>Tanggal Bayar</label>

                <input
                    type="date"
                    name="tanggal_bayar">

            </div>

            <!-- Status -->
            <div class="form-group">

                <label>Status Pembayaran</label>

                <select name="status" required>

                    <option value="Belum Lunas">Belum Lunas</option>

                    <option value="Lunas">Lunas</option>

                </select>

            </div>

            <!-- Keterangan -->
            <div class="form-group">

                <label>Keterangan</label>

                <textarea
                    name="keterangan"
                    rows="4"
                    placeholder="Masukkan keterangan pembayaran"></textarea>

            </div>

            <button type="submit" class="btn-submit">

                Simpan Pembayaran

            </button>

        </form>

    </div>

</div>
<script>
document.addEventListener("keydown",function(e){

if(e.key==="Escape"){

closeModal("modalTambahPembayaran");

}

});

// TUTUP MODAL //
function openModal(id){

    document.getElementById(id).style.display = "block";

}
function closeModal(id){

    document.getElementById(id).style.display = "none";

}

// =============================
// TUTUP MODAL SAAT KLIK DI LUAR
// =============================
window.onclick = function(event){

    let modal = document.getElementById("modalTambahPembayaran");

    if(event.target == modal){

        modal.style.display = "none";

    }

}

// =============================
// SEARCH TABLE
// =============================
function searchTable(){
    let input = document.getElementById("searchInput");
    let filter = input.value.toUpperCase();
    let table=document.getElementById("keuanganTable");
if(!table) return;
    function searchTable(){

    let input = document.getElementById("searchInput");

    let filter = input.value.toUpperCase();

    let table = document.getElementById("keuanganTable");

    if(!table) return;

    let tr = table.getElementsByTagName("tr");

    for(let i=1;i<tr.length;i++){

        let td = tr[i].getElementsByTagName("td");

        let tampil=false;

        for(let j=0;j<td.length;j++){

            if(td[j]){

                let txt=td[j].textContent || td[j].innerText;

                if(txt.toUpperCase().indexOf(filter)>-1){

                    tampil=true;

                    break;

                }

            }

        }

        tr[i].style.display=tampil?"":"none";

    }

}{

        let td = tr[i].getElementsByTagName("td");

        let tampil = false;

        for(let j=0;j<td.length;j++){

            if(td[j]){

                let txt = td[j].textContent || td[j].innerText;

                if(txt.toUpperCase().indexOf(filter)>-1){

                    tampil = true;

                    break;

                }

            }

        }

        tr[i].style.display = tampil ? "" : "none";

    }

}

// =============================
// DETAIL
// =============================
function viewKeuangan(id){

    window.location.href = "detail_keuangan.php?id="+id;

}

// =============================
// EDIT
// =============================
function editKeuangan(id){

    window.location.href = "edit_keuangan.php?id="+id;

}
function deleteKeuangan(id){

    if(confirm("Apakah Anda yakin ingin menghapus data pembayaran ini?")){

        window.location.href = "hapus_keuangan.php?id=" + id;

    }

}
setTimeout(function(){

    let alert = document.querySelector(".alert");

    if(alert){

        alert.style.transition="0.5s";

        alert.style.opacity="0";

        setTimeout(function(){

            alert.remove();

        },500);

    }

},3000);

</script>

</body>
</html>