<?php
session_start();

require_once "../config/config.php";

/** @var mysqli $conn */

// Cek apakah parameter id ada
if (!isset($_GET['id'])) {
    header("Location: kelola_jadwal.php");
    exit;
}

// Ambil ID
$id = intval($_GET['id']);

// Cek apakah data ada
$cek = mysqli_query($conn, "SELECT * FROM jadwal_mengajar WHERE id='$id'");

if (mysqli_num_rows($cek) == 0) {
    header("Location: kelola_jadwal.php?msg=notfound");
    exit;
}

// Hapus data
$hapus = mysqli_query($conn, "DELETE FROM jadwal_mengajar WHERE id='$id'");

// Cek hasil
if ($hapus) {

    header("Location: kelola_jadwal.php?msg=deleted");
    exit;

} else {

    header("Location: kelola_jadwal.php?msg=error");
    exit;

}
?>