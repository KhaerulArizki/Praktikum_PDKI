<?php
session_start();
require_once "../config/config.php";

/** @var mysqli $conn */

if(!isset($_GET['id'])){
    header("Location: kelola_jadwal.php");
    exit;
}

$id = intval($_GET['id']);

$query = mysqli_query($conn,"
SELECT
    jadwal_mengajar.id,
    kelas.nama_kelas,
    kelas.ruangan,
    mata_pelajaran.nama_mapel,
    users.nama_lengkap,
    jadwal_mengajar.hari,
    jadwal_mengajar.jam_mulai,
    jadwal_mengajar.jam_selesai

FROM jadwal_mengajar

INNER JOIN kelas
ON jadwal_mengajar.kelas_id = kelas.id

INNER JOIN guru
ON kelas.guru_id = guru.id

INNER JOIN users
ON guru.user_id = users.id

INNER JOIN mata_pelajaran
ON kelas.mata_pelajaran_id = mata_pelajaran.id

WHERE jadwal_mengajar.id='$id'
");

if(!$query){
    die(mysqli_error($conn));
}

$data = mysqli_fetch_assoc($query);

if(!$data){
    header("Location: kelola_jadwal.php");
    exit;
}

$nama = "Admin";

if(isset($_SESSION['nama_lengkap'])){
    $nama = $_SESSION['nama_lengkap'];
}elseif(isset($_SESSION['nama'])){
    $nama = $_SESSION['nama'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">

<title>Detail Jadwal</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
}

body{
font-family:Segoe UI;
background:#f5f7fa;
}

.header{
background:linear-gradient(135deg,#667eea,#764ba2);
color:white;
padding:20px 30px;
display:flex;
justify-content:space-between;
align-items:center;
}

.container{
width:850px;
margin:40px auto;
background:white;
padding:30px;
border-radius:15px;
box-shadow:0 3px 15px rgba(0,0,0,.1);
}

table{
width:100%;
border-collapse:collapse;
}

td{
padding:15px;
border-bottom:1px solid #eee;
}

td:first-child{
width:220px;
font-weight:bold;
}

.btn{
display:inline-block;
padding:12px 20px;
border-radius:8px;
text-decoration:none;
margin-top:25px;
margin-right:10px;
color:white;
}

.back{
background:#6c757d;
}

.edit{
background:#28a745;
}

</style>

</head>

<body>

<div class="header">

<h2>Detail Jadwal Mengajar</h2>

<div>

<?= htmlspecialchars($nama); ?>

</div>

</div>

<div class="container">

<h2 style="margin-bottom:20px;">

Informasi Jadwal

</h2>

<table>

<tr>

<td>Nama Guru</td>

<td><?= htmlspecialchars($data['nama_lengkap']); ?></td>

</tr>

<tr>

<td>Mata Pelajaran</td>

<td><?= htmlspecialchars($data['nama_mapel']); ?></td>

</tr>

<tr>

<td>Kelas</td>

<td><?= htmlspecialchars($data['nama_kelas']); ?></td>

</tr>

<tr>

<td>Hari</td>

<td><?= htmlspecialchars($data['hari']); ?></td>

</tr>

<tr>

<td>Jam Mulai</td>

<td><?= htmlspecialchars($data['jam_mulai']); ?></td>

</tr>

<tr>

<td>Jam Selesai</td>

<td><?= htmlspecialchars($data['jam_selesai']); ?></td>

</tr>

<tr>

<td>Ruangan</td>

<td><?= htmlspecialchars($data['ruangan']); ?></td>

</tr>

</table>

<a
href="kelola_jadwal.php"
class="btn back">

← Kembali

</a>

<a
href="edit_jadwal.php?id=<?= $data['id']; ?>"
class="btn edit">

✏ Edit Jadwal

</a>

</div>

</body>

</html>