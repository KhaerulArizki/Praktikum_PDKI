<?php
session_start();
require_once "../config/config.php";

/**@var mysqli $conn*/
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: kelola_data_master.php");
    exit();
}

$status        = trim($_POST['status']);
$nama_lengkap  = trim($_POST['nama_lengkap']);
$username      = trim($_POST['username']);
$email         = trim($_POST['email']);
$password      = trim($_POST['password']);
$nomor         = trim($_POST['nomor']);
$no_hp         = trim($_POST['no_hp']);
$alamat        = trim($_POST['alamat']);

if (
    empty($status) ||
    empty($nama_lengkap) ||
    empty($username) ||
    empty($email) ||
    empty($password) ||
    empty($nomor)
) {
    header("Location: kelola_data_master.php?msg=error");
    exit();
}

$username = mysqli_real_escape_string($conn, $username);

$cek = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
if (mysqli_num_rows($cek) > 0) {

    header("Location: kelola_data_master.php?msg=email");
    exit();
}

$cekUsername = mysqli_query($conn, "SELECT id FROM users WHERE username='$username'");
if (mysqli_num_rows($cekUsername) > 0) {

    header("Location: kelola_data_master.php?msg=username");
    exit();
}

mysqli_begin_transaction($conn);
try {
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $role = strtolower($status);

    mysqli_query($conn, "

        INSERT INTO users
        (
            username,
            nama_lengkap,
            email,
            password,
            role,
            no_hp,
            alamat
        )

        VALUES
        (
            '$username',
            '$nama_lengkap',
            '$email',
            '$passwordHash',
            '$role',
            '$no_hp',
            '$alamat'

        )

    ");

    $user_id = mysqli_insert_id($conn);

    if ($status == "Guru") {

        mysqli_query($conn, "

            INSERT INTO guru
            (
                user_id,
                nip
            )

            VALUES
            (

                '$user_id',
                '$nomor'

            )

        ");

    } else {

        mysqli_query($conn, "

            INSERT INTO siswa
            (
                user_id,
                nis
            )

            VALUES
            (

                '$user_id',
                '$nomor'

            )

        ");

    }

    mysqli_commit($conn);

    header("Location: kelola_data_master.php?msg=success");

} catch (Exception $e) {

    mysqli_rollback($conn);

    header("Location: kelola_data_master.php?msg=error");

}