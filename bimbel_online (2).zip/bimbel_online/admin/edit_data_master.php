<?php
session_start();
require_once "../config/config.php";

/** @var mysqli $conn */
if (!isset($_GET['id']) || !isset($_GET['status'])) {
    header("Location: kelola_data_master.php");
    exit;
}

$id = intval($_GET['id']);
$status = $_GET['status'];

if ($status == "Guru") {

    $query = mysqli_query($conn,"
        SELECT
            guru.id,
            guru.nip AS nomor,
            guru.user_id,
            users.nama_lengkap,
            users.email,
            users.no_hp,
            users.alamat

        FROM guru

        JOIN users
        ON guru.user_id=users.id

        WHERE guru.id='$id'
    ");

} else {

    $query = mysqli_query($conn,"
        SELECT
            siswa.id,
            siswa.nis AS nomor,
            siswa.user_id,
            users.nama_lengkap,
            users.email,
            users.no_hp,
            users.alamat

        FROM siswa

        JOIN users
        ON siswa.user_id=users.id

        WHERE siswa.id='$id'
    ");

}

$data = mysqli_fetch_assoc($query);

if(!$data){
    header("Location: kelola_data_master.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Edit Data</title>

<style>

body{

font-family:Segoe UI;

background:#f5f5f5;

}

.container{

width:700px;

margin:40px auto;

background:white;

padding:30px;

border-radius:10px;

box-shadow:0 3px 10px rgba(0,0,0,.1);

}

input,textarea{

width:100%;

padding:12px;

margin-top:5px;

margin-bottom:20px;

}

button{

background:#4CAF50;

color:white;

padding:12px 20px;

border:none;

cursor:pointer;

}

a{

text-decoration:none;

}

</style>

</head>

<body>

<div class="container">

<h2>Edit Data <?= $status ?></h2>

<form action="update_data_master.php" method="POST">

<input type="hidden" name="id" value="<?= $data['id']; ?>">

<input type="hidden" name="user_id" value="<?= $data['user_id']; ?>">

<input type="hidden" name="status" value="<?= $status; ?>">

<label>Nama Lengkap</label>

<input
type="text"
name="nama_lengkap"
value="<?= htmlspecialchars($data['nama_lengkap']); ?>"
required>

<label>Email</label>

<input
type="email"
name="email"
value="<?= htmlspecialchars($data['email']); ?>"
required>

<label>NIP / NIS</label>

<input
type="text"
name="nomor"
value="<?= htmlspecialchars($data['nomor']); ?>"
required>

<label>No HP</label>

<input
type="text"
name="no_hp"
value="<?= htmlspecialchars($data['no_hp']); ?>">

<label>Alamat</label>

<textarea
name="alamat"><?= htmlspecialchars($data['alamat']); ?></textarea>

<button type="submit">

Simpan Perubahan

</button>

<a href="kelola_data_master.php">

<button type="button">

Kembali

</button>

</a>

</form>

</div>

</body>

</html>