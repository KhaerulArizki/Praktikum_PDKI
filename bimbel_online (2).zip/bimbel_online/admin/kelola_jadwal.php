<?php
session_start();
require_once "../config/config.php";

/** @var mysqli $conn */

// =======================
// Total Jadwal
// =======================
$result_jadwal = mysqli_query($conn, "
SELECT
    jadwal_mengajar.id,
    kelas.nama_kelas,
    mata_pelajaran.nama_mapel,
    users.nama_lengkap,
    jadwal_mengajar.hari,
    jadwal_mengajar.jam_mulai,
    jadwal_mengajar.jam_selesai,
    kelas.ruangan

FROM jadwal_mengajar

INNER JOIN kelas
ON jadwal_mengajar.kelas_id = kelas.id

INNER JOIN guru
ON kelas.guru_id = guru.id

INNER JOIN users
ON guru.user_id = users.id

INNER JOIN mata_pelajaran
ON kelas.mata_pelajaran_id = mata_pelajaran.id

ORDER BY
jadwal_mengajar.hari,
jadwal_mengajar.jam_mulai
");

if(!$result_jadwal){
    die("Query Error : ".mysqli_error($conn));
}

$total_jadwal = mysqli_num_rows($result_jadwal);

// =======================
// Nama Login
// =======================

$nama = "Admin";

if(isset($_SESSION['nama_lengkap'])){
    $nama = $_SESSION['nama_lengkap'];
}elseif(isset($_SESSION['nama'])){
    $nama = $_SESSION['nama'];
}

// =======================
// Hapus Jadwal
// =======================

if(isset($_GET['action']) && $_GET['action']=="delete"){

    $id = intval($_GET['id']);

    if(mysqli_query($conn,
        "DELETE FROM jadwal_mengajar WHERE id='$id'"
    )){

        header("Location: kelola_jadwal.php?msg=deleted");
        exit;

    }else{

        header("Location: kelola_jadwal.php?msg=error");
        exit;

    }

}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Jadwal - Bimbel Online</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }

        /* Header Styles */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo {
            font-size: 24px;
        }

        .header-title h2 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 20px;
            border: 1px solid white;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: white;
            color: #667eea;
        }

        /* Layout Styles */
        .layout {
            display: flex;
            min-height: calc(100vh - 80px);
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: #2c3e50;
            padding: 20px 0;
        }

        .sidebar-header {
            padding: 20px;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 10px;
        }

        .menu-item {
            padding: 15px 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #bdc3c7;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(52, 152, 219, 0.2);
            color: white;
            border-left-color: #3498db;
        }

        .menu-icon {
            font-size: 20px;
        }

        /* Container Styles */
        .container {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 28px;
            color: #333;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        /* Stats Card */
        .stats-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stats-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .stats-info h3 {
            font-size: 32px;
            color: #333;
        }

        .stats-info p {
            color: #666;
            font-size: 14px;
        }

        /* Search Box */
        .search-box {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: #667eea;
        }

        /* Table Styles */
        .table-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        thead th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }

        tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.3s;
        }

        tbody tr:hover {
            background-color: #f8f9fa;
        }

        tbody td {
            padding: 15px;
            font-size: 14px;
            color: #333;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-edit, .btn-delete, .btn-view {
            padding: 6px 12px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }

        .btn-view {
            background: #3498db;
            color: white;
        }

        .btn-edit {
            background: #2ecc71;
            color: white;
        }

        .btn-delete {
            background: #e74c3c;
            color: white;
        }

        .btn-view:hover {
            background: #2980b9;
        }

        .btn-edit:hover {
            background: #27ae60;
        }

        .btn-delete:hover {
            background: #c0392b;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }

        /* Alert Messages */
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            animation: slideDown 0.3s;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .modal-header h2 {
            color: #333;
            font-size: 24px;
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover {
            color: #333;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .layout {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
            }

            .page-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .table-container {
                overflow-x: auto;
            }

            table {
                min-width: 800px;
            }
        }
        </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo"></div>
            <div class="header-title">
                <h2>Kelola Jadwal</h2>
            </div>
        </div>
        <div class="header-right">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($nama ?? 'A', 0, 1)); ?></div>
                <span><?php echo htmlspecialchars($nama ?? 'Admin'); ?></span>
            </div>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="layout">
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Bimbel Online</h3>
            </div>
            <a href="dashboard_admin.php" class="menu-item">
                <span class="menu-icon"></span>
                <span>Dashboard</span>
            </a>
            <a href="kelola_kelas.php" class="menu-item active">
                <span class="menu-icon"></span>
                <span>Jadwal Siswa</span>
            </a>
        </div>

        <div class="container">
            <div class="page-header">
                <h1>Kelola jadwal</h1>
                <button class="btn-primary" onclick="openModal('modalTambahJadwal')">
                    <span></span>Tambah Jadwal
                </button>
            </div>

            <?php if (isset($_GET['msg'])): ?>
                <?php if ($_GET['msg'] == 'success'): ?>
                    <div class="alert alert-success">
                        ✓ jadwal berhasil ditambahkan!
                    </div>
                <?php elseif ($_GET['msg'] == 'deleted'): ?>
                    <div class="alert alert-success">
                        ✓ jadwal berhasil dihapus!
                    </div>
                <?php elseif ($_GET['msg'] == 'updated'): ?>
                    <div class="alert alert-success">
                        ✓ jadwal berhasil diupdate!
                    </div>
                <?php elseif ($_GET['msg']=="jadwal"):
                    ?>
                <div class="alert alert-danger">
                Jadwal bentrok dengan jadwal yang sudah ada.
                </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="stats-card">
                <div class="stats-icon"></div>
                <div class="stats-info">
                    <h3><?php echo $total_jadwal; ?></h3>
                    <p>Total Jadwal</p>
                </div>
            </div>

            <div class="search-box">
                <input type="text" id="searchInput" placeholder="🔍 Cari jadwal berdasarkan nama kelas, tingkat, atau wali kelas..." onkeyup="searchTable()">
            </div>

            <div class="table-container">
                <?php if(mysqli_num_rows($result_jadwal)>0): ?>
                    <table id="jadwalTable">
                    <thead>

<tr>

<th>No</th>
<th>Kelas</th>
<th>Mata Pelajaran</th>
<th>Guru</th>
<th>Hari</th>
<th>Jam</th>
<th>Ruangan</th>
<th width="220">Aksi</th>
</tr>
</thead>
<tbody>
<tbody>
<?php
$no = 1;
while($jadwal = mysqli_fetch_assoc($result_jadwal)):
?>
<tr>
<td><?= $no++; ?></td>
<td><?= htmlspecialchars($jadwal['nama_kelas']); ?></td>
<td><?= htmlspecialchars($jadwal['nama_mapel']); ?></td>
<td><?= htmlspecialchars($jadwal['nama_lengkap']); ?></td>
<td><?= htmlspecialchars($jadwal['hari']); ?></td>
<td>
<?= htmlspecialchars($jadwal['jam_mulai']); ?>
-
<?= htmlspecialchars($jadwal['jam_selesai']); ?>
</td>
<td><?= htmlspecialchars($jadwal['ruangan']); ?></td>
<td>

<div class="action-buttons">
<a
href="detail_jadwal.php?id=<?= $jadwal['id']; ?>"
class="btn-view">
Lihat
</a>
<a
href="edit_jadwal.php?id=<?= $jadwal['id']; ?>"
class="btn-edit">
Edit
</a>
<a href="hapus_jadwal.php?id=<?= $jadwal['id']; ?>"
   class="btn-delete"
   onclick="return confirm('Yakin ingin menghapus jadwal ini?');">
    Hapus
</a>
</div>
</td>
</tr>
<?php endwhile; ?>
</tbody>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-state-icon"></div>
                        <h3>Belum Ada Data Jadwal</h3>
                        <p>Klik tombol "Tambah Jadwal" untuk menambahkan kelas pertama Anda.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

   <div id="modalTambahJadwal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Tambah Jadwal</h2>
                <span class="close" onclick="closeModal('modalTambahJadwal')">&times;</span>
            </div>
            <form action="proses_tambah_jadwal.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                  <div class="form-group">

<label>Kelas *</label>

<select name="kelas_id" required>

<option value="">-- Pilih Kelas --</option>

<?php

$qKelas=mysqli_query($conn,"
SELECT id,nama_kelas
FROM kelas
ORDER BY nama_kelas ASC
");

while($k=mysqli_fetch_assoc($qKelas)):

?>

<option value="<?= $k['id']; ?>">

<?= htmlspecialchars($k['nama_kelas']); ?>

</option>

<?php endwhile; ?>

</select>

</div>


<div class="form-group">

<label>Hari *</label>

<select name="hari" required>

<option value="">-- Pilih Hari --</option>

<option>Senin</option>

<option>Selasa</option>

<option>Rabu</option>

<option>Kamis</option>

<option>Jumat</option>

<option>Sabtu</option>

<option>Minggu</option>

</select>

</div>


<div class="form-row">

<div class="form-group">

<label>Jam Mulai *</label>

<input
type="time"
name="jam_mulai"
required>

</div>

<div class="form-group">

<label>Jam Selesai *</label>

<input
type="time"
name="jam_selesai"
required>

</div>

</div>  
                <button type="submit" class="btn-submit">Simpan Jadwal</button>
            </form>
        </div>
    </div>

    <script>
       function searchTable(){
    let input=document.getElementById("searchInput");
    let filter=input.value.toUpperCase();
    let table=document.getElementById("jadwalTable");
    let tr=table.getElementsByTagName("tr");
    for(let i=1;i<tr.length;i++){
        let td=tr[i].getElementsByTagName("td");
        let tampil=false;
        for(let j=0;j<td.length;j++){
            if(td[j]){
                let txt=td[j].textContent||td[j].innerText;
                if(txt.toUpperCase().indexOf(filter)>-1){
                    tampil=true;
                    break;
                }
            }
        }
        tr[i].style.display=tampil?"":"none";
    }
}
function deleteJadwal(id){

    if(confirm("Yakin ingin menghapus jadwal ini?")){

        window.location.href = "hapus_jadwal.php?id=" + id;

    }

}

setTimeout(function(){
    let alert=document.querySelectorAll(".alert");
    alert.forEach(function(item){
        item.style.opacity="0";
        setTimeout(function(){
            item.remove();
        },500);
    });
},3000);

function openModal(id){
    document.getElementById(id).style.display="block";
}
function closeModal(id){
    document.getElementById(id).style.display="none";
}
window.onclick=function(e){
    if(e.target.classList.contains("modal")){
        e.target.style.display="none";
    }
}
document.addEventListener("keydown",function(e){
    if(e.key==="Escape"){
        let modal=document.getElementsByClassName("modal");
        for(let i of modal){
            i.style.display="none";
        }
    }
});
    </script>
</body>
</html>