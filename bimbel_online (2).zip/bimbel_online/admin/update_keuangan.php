<?php
session_start();

require_once "../config/config.php";

/** @var mysqli $conn */

// Cek apakah form dikirim
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: kelola_keuangan.php");
    exit;
}

// Ambil data dari form
$id                 = intval($_POST['id']);
$siswa_id           = intval($_POST['siswa_id']);
$mata_pelajaran_id  = intval($_POST['mata_pelajaran_id']);
$jumlah             = mysqli_real_escape_string($conn, $_POST['jumlah']);
$tanggal_tagihan    = mysqli_real_escape_string($conn, $_POST['tanggal_tagihan']);
$tanggal_bayar      = trim($_POST['tanggal_bayar']);
$status             = mysqli_real_escape_string($conn, $_POST['status']);
$keterangan         = mysqli_real_escape_string($conn, $_POST['keterangan']);

// Jika status belum lunas maka tanggal bayar dikosongkan
if ($status == "Belum Lunas" || empty($tanggal_bayar)) {

    $sql = "
    UPDATE pembayaran SET

        siswa_id = '$siswa_id',
        mata_pelajaran_id = '$mata_pelajaran_id',
        jumlah = '$jumlah',
        tanggal_tagihan = '$tanggal_tagihan',
        tanggal_bayar = NULL,
        status = '$status',
        keterangan = '$keterangan'

    WHERE id = '$id'
    ";

} else {

    $sql = "
    UPDATE pembayaran SET

        siswa_id = '$siswa_id',
        mata_pelajaran_id = '$mata_pelajaran_id',
        jumlah = '$jumlah',
        tanggal_tagihan = '$tanggal_tagihan',
        tanggal_bayar = '$tanggal_bayar',
        status = '$status',
        keterangan = '$keterangan'

    WHERE id = '$id'
    ";

}

// Jalankan query
$update = mysqli_query($conn, $sql);

// Cek hasil
if ($update) {

    header("Location: kelola_keuangan.php?msg=updated");
    exit;

} else {

    echo "<h2>Update Gagal</h2>";

    echo "<p><b>Error :</b> " . mysqli_error($conn) . "</p>";

    echo "<br>";

    echo "<a href='edit_keuangan.php?id=".$id."'>Kembali</a>";

}
?>