<?php
require_once "../config/config.php";

/** @var mysqli $conn */
$queryGuru = mysqli_query($conn, "SELECT COUNT(*) AS total FROM guru");
$dataGuru = mysqli_fetch_assoc($queryGuru);
$total_guru = $dataGuru['total'];

$querySiswa = mysqli_query($conn, "SELECT COUNT(*) AS total FROM siswa");
$dataSiswa = mysqli_fetch_assoc($querySiswa);
$total_siswa = $dataSiswa['total'];
$result_data_master = mysqli_query($conn, "

SELECT
    guru.id,
    guru.user_id,
    guru.nip AS nomor,
    users.nama_lengkap,
    users.email,
    'Guru' AS status
FROM guru
INNER JOIN users
ON guru.user_id = users.id

UNION ALL

SELECT
    siswa.id,
    siswa.user_id,
    siswa.nis AS nomor,
    users.nama_lengkap,
    users.email,
    'Siswa' AS status
FROM siswa
INNER JOIN users
ON siswa.user_id = users.id

ORDER BY nama_lengkap ASC

");

if (!$result_data_master) {
    die("Query gagal : " . mysqli_error($conn));
}

$total_data_master = mysqli_num_rows($result_data_master);
$nama = "Admin";
if (isset($_SESSION['nama_lengkap'])) {
    $nama = $_SESSION['nama_lengkap'];
} elseif (isset($_SESSION['nama'])) {
    $nama = $_SESSION['nama'];
}

if (isset($_GET['action']) && $_GET['action'] == "delete") {

    $id = intval($_GET['id']);
    $status = $_GET['status'];

    if ($status == "Guru") {

        $cek = mysqli_query($conn,
            "SELECT user_id FROM guru WHERE id='$id'");

        if ($row = mysqli_fetch_assoc($cek)) {

            $user_id = $row['user_id'];

            mysqli_query($conn,
                "DELETE FROM guru WHERE id='$id'");

            mysqli_query($conn,
                "DELETE FROM users WHERE id='$user_id'");
        }

    } else {

        $cek = mysqli_query($conn,
            "SELECT user_id FROM siswa WHERE id='$id'");

        if ($row = mysqli_fetch_assoc($cek)) {

            $user_id = $row['user_id'];

            mysqli_query($conn,
                "DELETE FROM siswa WHERE id='$id'");

            mysqli_query($conn,
                "DELETE FROM users WHERE id='$user_id'");
        }

    }

    header("Location: kelola_data_master.php?msg=deleted");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Data Master - Bimbel Online</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }

        /* Header Styles */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo {
            font-size: 24px;
        }

        .header-title h2 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 20px;
            border: 1px solid white;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: white;
            color: #667eea;
        }

        /* Layout Styles */
        .layout {
            display: flex;
            min-height: calc(100vh - 80px);
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: #2c3e50;
            padding: 20px 0;
        }

        .sidebar-header {
            padding: 20px;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 10px;
        }

        .menu-item {
            padding: 15px 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #bdc3c7;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(52, 152, 219, 0.2);
            color: white;
            border-left-color: #3498db;
        }

        .menu-icon {
            font-size: 20px;
        }

        /* Container Styles */
        .container {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 28px;
            color: #333;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        /* Stats Card */
        .stats-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stats-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .stats-info h3 {
            font-size: 32px;
            color: #333;
        }

        .stats-info p {
            color: #666;
            font-size: 14px;
        }

        /* Search Box */
        .search-box {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: #667eea;
        }

        /* Table Styles */
        .table-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        thead th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }

        tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.3s;
        }

        tbody tr:hover {
            background-color: #f8f9fa;
        }

        tbody td {
            padding: 15px;
            font-size: 14px;
            color: #333;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-edit, .btn-delete, .btn-view {
            padding: 6px 12px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }

        .btn-view {
            background: #3498db;
            color: white;
        }

        .btn-edit {
            background: #2ecc71;
            color: white;
        }

        .btn-delete {
            background: #e74c3c;
            color: white;
        }

        .btn-view:hover {
            background: #2980b9;
        }

        .btn-edit:hover {
            background: #27ae60;
        }

        .btn-delete:hover {
            background: #c0392b;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }

        /* Alert Messages */
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            animation: slideDown 0.3s;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .modal-header h2 {
            color: #333;
            font-size: 24px;
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover {
            color: #333;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .layout {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
            }

            .page-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .table-container {
                overflow-x: auto;
            }

            table {
                min-width: 800px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo"></div>
            <div class="header-title">
                <h2>Kelola Data Master</h2>
            </div>
        </div>
        <div class="header-right">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($nama ?? 'A', 0, 1)); ?></div>
                <span><?php echo htmlspecialchars($nama ?? 'Admin'); ?></span>
            </div>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="layout">
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Bimbel Online</h3>
            </div>
            <a href="dashboard_admin.php" class="menu-item">
                <span class="menu-icon"></span>
                <span>Dashboard</span>
            </a>
            <a href="kelola_data_master.php" class="menu-item">
                <span class="menu-icon"></span>
                <span>Data Guru & Siswa</span>
            </a>
        </div>

        <div class="container">
        <div class="page-header">
    <h1>Data Master</h1>
    <div style="display:flex; gap:20px;">
        <a href="dashboard_admin.php" class="btn-primary"
           style="background:#6c757d;">
            ⬅ Kembali ke Dashboard
        </a>
        <button class="btn-primary"
            onclick="openModal('modalTambahDataMaster')">
            Tambah Data
        </button>
    </div>

</div>
    <?php if(isset($_GET['msg'])): ?>
        <?php if($_GET['msg']=="success"): ?>
            <div class="alert alert-success">
                Data berhasil ditambahkan.
            </div>
        <?php elseif($_GET['msg']=="updated"): ?>
            <div class="alert alert-success">
                Data berhasil diubah.
            </div>
        <?php elseif($_GET['msg']=="deleted"): ?>
            <div class="alert alert-success">
                Data berhasil dihapus.
            </div>
        <?php elseif($_GET['msg']=="error"): ?>
            <div class="alert alert-danger">
                Terjadi kesalahan.
            </div>
            <?php elseif($_GET['msg']=="email"): ?>
            <div class="alert alert-danger">

    Email sudah digunakan.

            </div>
        <?php endif; ?>
    <?php endif; ?>


    <div style="display:flex;gap:20px;margin-bottom:25px;">

        <div class="stats-card" style="flex:1;">
            <div class="stats-info">
                <h3><?= $total_guru ?></h3>
                <p>Total Guru</p>
            </div>
        </div>
        <div class="stats-card" style="flex:1;">
            <div class="stats-info">
                <h3><?= $total_siswa ?></h3>
                <p>Total Siswa</p>
            </div>
        </div>
    </div>

    <div class="search-box">
        <input
            type="text"
            id="searchInput"
            placeholder="Cari berdasarkan nama, email atau NIP/NIS..."
            onkeyup="searchTable()">
    </div>


    <div class="table-container">

        <table id="datamasterTable">

            <thead>

                <tr>

                    <th>No</th>

                    <th>NIP / NIS</th>

                    <th>Nama Lengkap</th>

                    <th>Email</th>

                    <th>Status</th>

                    <th width="220">Aksi</th>

                </tr>

            </thead>

            <tbody>

            <?php

            $no=1;

            while($row=mysqli_fetch_assoc($result_data_master)):

            ?>

                <tr>

                    <td><?= $no++; ?></td>

                    <td><?= htmlspecialchars($row['nomor']); ?></td>

                    <td><?= htmlspecialchars($row['nama_lengkap']); ?></td>

                    <td><?= htmlspecialchars($row['email']); ?></td>

                    <td>

                        <?php

                        if($row['status']=="Guru"){

                            echo "<span style='background:#28a745;color:white;padding:5px 12px;border-radius:20px;'>Guru</span>";

                        }else{

                            echo "<span style='background:#007bff;color:white;padding:5px 12px;border-radius:20px;'>Siswa</span>";

                        }

                        ?>
                    </td>
                    <td>
                        <div class="action-buttons">
                            <a
                            href="detail_data_master.php?id=<?= $row['id']; ?>&status=<?= $row['status']; ?>"
                            class="btn-view">

                                Lihat
                            </a>
                            <a
                            href="edit_data_master.php?id=<?= $row['id']; ?>&status=<?= $row['status']; ?>"
                            class="btn-edit">

                                Edit
                            </a>
                            <a
                            href="#"
                            class="btn-delete"
                            onclick="deleteDatamaster(
                            <?= $row['id']; ?>,
                            '<?= $row['status']; ?>',
                            '<?= htmlspecialchars($row['nama_lengkap'],ENT_QUOTES); ?>'
                            )">
                                Hapus

                            </a>

                        </div>

                    </td>

                </tr>

            <?php endwhile; ?>

            </tbody>

        </table>

    </div>

</div>
<div id="modalTambahDataMaster" class="modal">

    <div class="modal-content">

        <div class="modal-header">
            <h2>Tambah Data Guru / Siswa</h2>

            <span class="close"
                onclick="closeModal('modalTambahDataMaster')">
                &times;
            </span>

        </div>

        <form action="proses_tambah_data_master.php" method="POST">

            <div class="form-group">

                <label>Jenis Data *</label>

                <select name="status" required>

                    <option value="">-- Pilih --</option>

                    <option value="Guru">Guru</option>

                    <option value="Siswa">Siswa</option>
                </select>
            </div>


            <div class="form-group">
                <label>Username *</label>
                <input
                    type="text"
                    name="username"
                    required>
            </div>

            <div class="form-group">
                <label>Nama Lengkap</label>
                <input
                    type="text"
                    name="nama_lengkap"
                    required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        name="email"
                        required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input
                        type="password"
                        name="password"
                        required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>NIP / NIS *</label>
                    <input
                        type="text"
                        name="nomor"
                        required>
                </div>
                <div class="form-group">
                    <label>No HP</label>
                    <input
                        type="text"
                        name="no_hp">
                </div>
            </div>

            <div class="form-group">
                <label>Alamat</label>
                <textarea
                    name="alamat"
                    rows="3"></textarea>
            </div>
            <button
                type="submit"
                class="btn-submit">
                Simpan Data
            </button>
        </form>
        </div>
        </div>
    <script>
       function openModal(id){
    document.getElementById(id).style.display="block";
    }
    function closeModal(id){
    document.getElementById(id).style.display="none";
    }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = "none";
            }
        }

        document.addEventListener('keydown', function(event) {
            if (event.key === "Escape") {
                const modals = document.getElementsByClassName('modal');
                for (let modal of modals) {
                    modal.style.display = "none";
                }
            }
        });

        function searchTable() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('datamasterTable');
            
            if (!table) return;
            
            const tr = table.getElementsByTagName('tr');

            for (let i = 1; i < tr.length; i++) {
                const td = tr[i].getElementsByTagName('td');
                let found = false;
                
                for (let j = 0; j < td.length; j++) {
                    if (td[j]) {
                        const txtValue = td[j].textContent || td[j].innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            found = true;
                            break;
                        }
                    }
                }
                
                tr[i].style.display = found ? "" : "none";
            }
        }

        function deleteDatamaster(id,status,nama){

    if(confirm("Yakin ingin menghapus "+nama+" ?")){

        window.location.href=
        "kelola_data_master.php?action=delete&id="+id+"&status="+status;

    }
}

        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                alert.style.transition = 'opacity 0.5s';
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.remove();
                }, 500);
            });
        }, 3000);
    </script>
</body>
</html>