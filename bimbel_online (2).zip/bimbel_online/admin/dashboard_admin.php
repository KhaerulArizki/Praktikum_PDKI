<?php
session_start();
date_default_timezone_set('Asia/Jakarta');
require_once(__DIR__ . '/../config/config.php');
if (session_status() == PHP_SESSION_NONE) {   
}
if($_SESSION['role']!="admin"){
    header("Location: ../index.php");
    exit;
}

$nama = isset($_SESSION['nama_lengkap']) ? $_SESSION['nama_lengkap'] : "Admini";

function getTotal($conn,$table)
{
    $allowed = [
        'data_master',
        'jadwal',
        'keuangan',
        'pembelajaran',
        'cetak_laporan'
    ];

    if(!in_array($table,$allowed)){
        return 0;
    }

    $sql = "SELECT COUNT(*) AS total FROM `$table`";
    $result = mysqli_query($conn,$sql);

    if($result){
        $row = mysqli_fetch_assoc($result);
        return $row['total'];
    }

    return 0;
}

$total_data_master  = getTotal($conn, "data_master");
$totalPembelajaran  = getTotal($conn, "pembelajaran");
$totalJadwal = getTotal($conn, "jadwal");
$totalKeuangan = getTotal($conn, "keuangan");
$totalCetak_laporann = getTotal($conn, "cetak_laporan");

$result_data_master = mysqli_query($conn,"SELECT * FROM datamaster ORDER BY id DESC");
if(!$result_data_master){
    $result_data_master = mysqli_query($conn,"SELECT * FROM datamaster");
}
$resultPembelajaran = mysqli_query($conn,"SELECT * FROM pembelajaran ORDER BY id DESC");
if(!$resultPembelajaran){
    $resultPembelajaran = mysqli_query($conn,"SELECT * FROM pembelajaran");
}
$cekPembelajaran = mysqli_query($conn, "SHOW TABLES LIKE 'Pembelajaran'");
if ($cekPembelajaran && mysqli_num_rows($cekPembelajaran) > 0) {
    $resultPembelajaran = mysqli_query($conn,"
        SELECT * FROM Pembelajaran 
        ORDER BY id DESC 
        LIMIT 10
    ");
} else {
    $resultPembelajaran = false;
}
$resultviatransfer = mysqli_query($conn,
"SELECT * FROM bank");

$resultAktivitas = mysqli_query($conn,"
SELECT nama_lengkap,
'Login ke sistem' AS deskripsi,
NOW() AS created_at
FROM pembelajaran
ORDER BY id DESC
LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Bimbel Online</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo {
            font-size: 24px;
        }

        .header-title h2 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 20px;
            border: 1px solid white;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: white;
            color: #667eea;
        }

        .layout {
            display: flex;
            min-height: calc(100vh - 80px);
        }

        .sidebar {
            width: 250px;
            background: #2c3e50;
            padding: 20px 0;
        }

        .sidebar-header {
            padding: 20px;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 10px;
        }

        .menu-item {
            padding: 15px 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #bdc3c7;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .menu-item:hover, .menu-item.active {
            background: rgba(52, 152, 219, 0.2);
            color: white;
            border-left-color: #3498db;
        }

        .menu-icon {
            font-size: 20px;
        }

        .container {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }

        .quick-actions {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .action-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 20px;
            transition: transform 0.3s;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
        }

        .stat-icon.blue {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .stat-icon.green {
            background: linear-gradient(135deg, #38ef7d 0%, #11998e 100%);
        }

        .stat-icon.orange {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        }

        .stat-icon.red {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
        }

        .stat-info h3 {
            font-size: 32px;
            font-weight: 700;
            color: #333;
        }

        .stat-info p {
            color: #666;
            font-size: 14px;
            margin-top: 5px;
        }

        .content-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 30px;
        }

        .card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .card-header h3 {
            font-size: 18px;
            color: #333;
        }

        .card-header a {
            color: #667eea;
            text-decoration: none;
            font-size: 14px;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            animation: slideDown 0.3s;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .modal-header h2 {
            color: #333;
            font-size: 24px;
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover {
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .activity-item {
            display: flex;
            align-items: flex-start;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e3f2fd;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .activity-info {
            flex: 1;
        }

        .activity-info h4 {
            font-size: 14px;
            color: #333;
            margin-bottom: 5px;
        }

        .activity-info p {
            font-size: 12px;
            color: #666;
        }

        .activity-time {
            font-size: 12px;
            color: #999;
        }

        .schedule-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .schedule-info h4 {
            font-size: 14px;
            color: #333;
            margin-bottom: 5px;
        }

        .schedule-info p {
            font-size: 12px;
            color: #666;
        }

        .schedule-time {
            background: #667eea;
            color: white;
            padding: 8px 15px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 600;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }

        @media (max-width: 768px) {
            .layout {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
            }

            .content-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .quick-actions {
                flex-direction: column;
            }

            .action-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo"></div>
            <div class="header-title">
                <h2>Admin</h2>
            </div>
        </div>
        <div class="header-right">
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($nama, 0, 1)); ?></div>
                <span><?php echo $nama; ?></span>
            </div>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="layout">
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Bimbel Online</h3>
            </div>
            <a href="dashboard_admin.php" class="menu-item active"><span>Dashboard</span></a>
            <a href="kelola_data_master.php" class="menu-item"><span>Kelola Data master</span></a>
            <a href="kelola_jadwal.php" class="menu-item"><span>Kelola Jadwal</span></a>
            <a href="kelola_keuangan.php" class="menu-item"><span>Kelola Keuangan</span></a>
            <a href="kelola_pembelajaran.php" class="menu-item"><span>Kelola Pembelajaran</span></a>
            <a href="laporan.php" class="menu-item"><span></span></a>
        </div>

        <div class="container">
            <div class="quick-actions">
                <button class="action-btn" onclick="openModal('modalData_master')"><span>➕</span> Tambah Data Master</button>
                <button class="action-btn" onclick="openModal('modalJadwal')"><span>➕</span> Tambah Jadwal</button>
                <button class="action-btn" onclick="openModal('modalKeuangan')"><span>➕</span> Tambah Keuangan</button>
                <button class="action-btn" onclick="openModal('modalPembelajaran')"><span>➕</span> Tambah Pembelajaran</button>
            </div>

            <div class="stats-grid">
                <div class="stat-card" onclick="location.href='kelola_data_master.php'">
                    <div class="stat-icon blue"></div>
                    <div class="stat-info">
                       <h3><?php echo $total_data_master; ?></h3>
                        <p>Total Data Master</p>
                    </div>
                </div>
                <div class="stat-card" onclick="location.href='kelola_jadwal.php'">
                    <div class="stat-icon green"></div>
                    <div class="stat-info">
                        <h3><?php echo $totalJadwal; ?></h3>
                        <p>Total Jadwal</p>
                    </div>
                </div>
                <div class="stat-card" onclick="location.href='kelola_keuangan.php'">
                    <div class="stat-icon orange"></div>
                    <div class="stat-info">
                       <h3><?php echo $totalKeuangan; ?></h3>
                        <p>Total Keuangan</p>
                    </div>
                </div>
                <div class="stat-card" onclick="location.href='kelola_Pembelajaran.php'">
                    <div class="stat-icon red"></div>
                    <div class="stat-info">
                        <h3><?php echo $totalPembelajaran; ?></h3>
                        <p>Total Pembelajaran</p>
                    </div>
                </div>
                 <div class="stat-card" onclick="location.href='kelola_laporan.php'">
                    <div class="stat-icon orange"></div>
                    <div class="stat-info">
                       <h3><?php echo $totalCetak_laporann; ?></h3>
                        <p>Cetak laporann</p>
                    </div>
                </div>
            <div class="content-grid">
                <div class="card">
                    <div class="card-header">
                        <h3>Aktivitas Terbaru</h3>
                        <a href="#">Lihat Semua →</a>
                    </div>
                    </div>
                    <?php if($resultAktivitas && mysqli_num_rows($resultAktivitas)>0): ?>
                        <?php while ($aktivitas = mysqli_fetch_assoc($resultAktivitas)): ?>
                            <div class="activity-item">
                                <div class="activity-icon">👤</div>
                                <div class="activity-info">
                                    <h4><?php echo htmlspecialchars($aktivitas['nama_lengkap']); ?></h4>
                                    <p><?php echo htmlspecialchars($aktivitas['deskripsi']); ?></p>
                                </div>
                                <div class="activity-time">
                                    <?php 
                                        $waktu = strtotime($aktivitas['created_at']);
                                        $selisih = time() - $waktu;
                                        if ($selisih < 3600) {
                                            echo floor($selisih / 60) . ' menit lalu';
                                        } elseif ($selisih < 86400) {
                                            echo floor($selisih / 3600) . ' jam lalu';
                                        } else {
                                            echo floor($selisih / 86400) . ' hari lalu';
                                        }
                                    ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <p>Belum ada aktivitas</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div id="modalData_master" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Tambah Data Master Baru</h2>
                <span class="close" onclick="closeModal('modalData_master')">&times;</span>
            </div>
            <form action="process_tambah_Data_master.php" method="POST">
                <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="text" name="nama_lengkap" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>No Telepon</label>
                    <input type="text" name="no_telepon">
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <textarea name="alamat"></textarea>
                </div>
                <button type="submit" class="btn-submit">Tambah Data Master</button>
            </form>
        </div>
    </div>

    <div id="modalJadwal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Tambah Jadwal Baru</h2>
                <span class="close" onclick="closeModal('modalJadwal')">&times;</span>
            </div>
            <form action="process_tambah_jadwal.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>Jadwal siswa</label>
                        <input type="text" name="mata_pelajaran" required>
                    </div>
                    <div class="form-group">
                        <label>Jadwal guru</label>
                        <input type="text" name="kelas" required>
                    </div>
                </div>
                <button type="submit" class="btn-submit">Tambah Jadwal</button>
            </form>
        </div>
    </div>

    <div id="modalKeuangan" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Tambah Keuangan Baru</h2>
                <span class="close" onclick="closeModal('modalKeuangan')">&times;</span>
            </div>
            <form action="process_tambah_keuangan.php" method="POST">
                <div class="form-group">
                    <label>Data keuangan</label>
                    <input type="text" name="nama_kelas" placeholder="Contoh: " required>
                </div>
                <div class="form-group">
                    <label>Spp</label>
                    <select name="mata_pelajaran_id" required>
                        <option value="">Pilih pembayaran</option>
                        <?php 
                      if($resultviatransfer && mysqli_num_rows($resultviatransfer) > 0)
                            mysqli_data_seek($resultviatransfer, 0);
                            while($vt = mysqli_fetch_assoc($resultviatransfer)): 
                        ?>
                            <option value="<?php echo $vt['id']; ?>">
                                <?php echo htmlspecialchars($vt['nama_bank']); ?>
                            </option>
                        <?php 
                            endwhile;
                        ?>
                    </select>
                </div>
                <button type="submit" class="btn-submit">Simpan Keuangan</button>
            </form>
        </div>
    </div>

    <div id="modalPembelajaran" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Tambah Pembelajaran</h2>
                <span class="close" onclick="closeModal('modalPembelajaran')">&times;</span>
            </div>
            <form action="process_tambah_pembelajaran.php" method="POST">
                <div class="form-group">
                    <label>Nama Pembelajaran</label>
                    <input type="text" name="nama_mapel" required>
                </div>
                <div class="form-group">
                    <label>Nama Mapel</label>
                    <input type="text" name="kode_mapel">
                </div>
                <div class="form-group">
                    <label>Deskripsi</label>
                    <textarea name="deskripsi" rows="4"></textarea>
                </div>
                <button type="submit" class="btn-submit">Simpan Pembelajaran</button>
            </form>
        </div>
    </div>

    <div id="modalLaporan" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Cetak Laporan</h2>
                <span class="close" onclick="closeModal('modalLaporan')">&times;</span>
            </div>
            <form action="process_cetak-laporan.php" method="POST">
                <div class="form-group">
                    <label>Laporan keuangan</label>
                    <select name="keuangan" required>
                        <option value="">Pilih Bank</option>
                        <?php
                        if($resultviatransfer && mysqli_num_rows($resultviatransfer) > 0) {
                            mysqli_data_seek($resultviatransfer, 0);
                            while($k = mysqli_fetch_assoc($resultviatransfer)){
                        ?>
                            <option value="<?= $k['id']; ?>">
                                <?= htmlspecialchars($k['nama_bank']); ?>
                            </option>
                        <?php 
                            }
                        } 
                        ?>
                    </select>
                </div>
                <button type="submit" class="btn-submit">Cetak</button>
            </form>
        </div>
    </div>

<script>
// Membuka Modal
function openModal(modalId){
    document.getElementById(modalId).style.display = "block";
}

// Menutup Modal
function closeModal(modalId){
    document.getElementById(modalId).style.display = "none";
}

// Klik di luar modal untuk menutup
window.onclick = function(event){
    let modals = document.getElementsByClassName("modal");
    for(let i=0;i<modals.length;i++){
        if(event.target == modals[i]){
            modals[i].style.display = "none";
        }
    }
}
</script>
</body>
</html>