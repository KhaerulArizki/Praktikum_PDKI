<?php
session_start();
require_once "../config/config.php";

/** @var mysqli $conn */

if ($_SERVER['REQUEST_METHOD'] != "POST") {
    header("Location: kelola_jadwal.php");
    exit;
}

$kelas_id    = intval($_POST['kelas_id']);
$hari        = mysqli_real_escape_string($conn,$_POST['hari']);
$jam_mulai   = mysqli_real_escape_string($conn,$_POST['jam_mulai']);
$jam_selesai = mysqli_real_escape_string($conn,$_POST['jam_selesai']);

if(
    empty($kelas_id) ||
    empty($hari) ||
    empty($jam_mulai) ||
    empty($jam_selesai)
){

    header("Location: kelola_jadwal.php?msg=error");
    exit;

}

/*
|--------------------------------------------------------------------------
| Cek Jadwal Bentrok
|--------------------------------------------------------------------------
*/

$cek = mysqli_query($conn,"
SELECT id
FROM jadwal_mengajar
WHERE kelas_id='$kelas_id'
AND hari='$hari'
AND(
    ('$jam_mulai' BETWEEN jam_mulai AND jam_selesai)
    OR
    ('$jam_selesai' BETWEEN jam_mulai AND jam_selesai)
)
");

if(mysqli_num_rows($cek)>0){

    header("Location: kelola_jadwal.php?msg=jadwal");
    exit;

}

/*
|--------------------------------------------------------------------------
| Simpan Jadwal
|--------------------------------------------------------------------------
*/

$query=mysqli_query($conn,"
INSERT INTO jadwal_mengajar
(
kelas_id,
hari,
jam_mulai,
jam_selesai
)
VALUES
(
'$kelas_id',
'$hari',
'$jam_mulai',
'$jam_selesai'
)
");

if($query){

    header("Location: kelola_jadwal.php?msg=success");

}else{

    header("Location: kelola_jadwal.php?msg=error");

}

exit;

?>