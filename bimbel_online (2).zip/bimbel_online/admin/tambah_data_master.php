<?php
session_start();
require_once "config/config.php";

// Cek koneksi
if (!$conn) {
    die("Koneksi database gagal.");
}

// Hanya menerima POST
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: dashboard_admin.php");
    exit();
}

// Ambil data dari form
$nama_lengkap   = trim($_POST['nama_lengkap']);
$username       = trim($_POST['username']);
$password       = trim($_POST['password']);
$email          = trim($_POST['email']);
$nip            = trim($_POST['nip']);
$mata_pelajaran = trim($_POST['spesialisasi']); // sesuai form dashboard
$no_hp = trim($_POST['no_telepon']);
$alamat         = trim($_POST['alamat']);

// Validasi sederhana
if (
    empty($nama_lengkap) ||
    empty($username) ||
    empty($password) ||
    empty($nip)
) {
    echo "<script>
            alert('Data belum lengkap!');
            window.history.back();
          </script>";
    exit();
}

// Cek username
$cek = mysqli_prepare($conn, "SELECT id FROM users WHERE username=?");
mysqli_stmt_bind_param($cek, "s", $username);
mysqli_stmt_execute($cek);
mysqli_stmt_store_result($cek);

if (mysqli_stmt_num_rows($cek) > 0) {

    echo "<script>
            alert('Username sudah digunakan!');
            window.history.back();
          </script>";

    exit();
}

mysqli_begin_transaction($conn);

try {

    // Simpan ke tabel users
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $sqlUser = mysqli_prepare(
        $conn,
        "INSERT INTO users(username,password,role,nama_lengkap,email)
         VALUES(?,?,?,?,?)"
    );

    $role = "guru";

    mysqli_stmt_bind_param(
        $sqlUser,
        "sssss",
        $username,
        $password_hash,
        $role,
        $nama_lengkap,
        $email
    );

    mysqli_stmt_execute($sqlUser);

    $user_id = mysqli_insert_id($conn);

    // Simpan ke tabel guru
    $sqlGuru = mysqli_prepare(
        $conn,
        "INSERT INTO guru
        (user_id,nip,mata_pelajaran,no_hp,alamat)
        VALUES(?,?,?,?,?)"
    );

    mysqli_stmt_bind_param(
    $sqlGuru,
    "issss",
    $user_id,
    $nip,
    $mata_pelajaran,
    $no_hp,
    $alamat
);

mysqli_stmt_execute($sqlGuru);

mysqli_commit($conn);

echo "<script>
alert('Guru berhasil ditambahkan');
window.location='../admin/kelola_guru.php';
</script>";

} catch (Exception $e) {

    mysqli_rollback($conn);

    echo "<script>
            alert('Gagal menambahkan guru!');
            window.history.back();
          </script>";
}
?>