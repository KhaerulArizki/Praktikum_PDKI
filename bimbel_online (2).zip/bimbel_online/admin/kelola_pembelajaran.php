<?php
session_start();

require_once "../config/config.php";

/** @var mysqli $conn */

/*Mengambil Data Jadwal Mengajar*/
$sql_jadwal = "

SELECT
jadwal_mengajar.id,
kelas.nama_kelas,
mata_pelajaran.nama_mapel,
users.nama_lengkap,
jadwal_mengajar.hari,
jadwal_mengajar.jam_mulai,
jadwal_mengajar.jam_selesai

FROM jadwal_mengajar
JOIN kelas
ON jadwal_mengajar.kelas_id = kelas.id

JOIN guru
ON kelas.guru_id = guru.id

JOIN users
ON guru.user_id = users.id

JOIN mata_pelajaran
ON kelas.mata_pelajaran_id = mata_pelajaran.id

ORDER BY

jadwal_mengajar.hari ASC,
jadwal_mengajar.jam_mulai ASC
";

$result = mysqli_query($conn, $sql_jadwal);

if (!$result) {

    die("Query gagal : " . mysqli_error($conn));

}

$total = mysqli_num_rows($result);

/*Data Guru*/

$resultGuru = mysqli_query($conn, "

SELECT

guru.id,
users.nama_lengkap

FROM guru

JOIN users
ON guru.user_id = users.id

ORDER BY users.nama_lengkap

");

/*Data Mata Pelajaran*/

$resultMapel = mysqli_query($conn, "

SELECT

id,
nama_mapel

FROM mata_pelajaran

ORDER BY nama_mapel

");

/*Data Kelas*/

$resultKelas = mysqli_query($conn, "

SELECT

id,
nama_kelas

FROM kelas

ORDER BY nama_kelas

");

/*
|--------------------------------------------------------------------------
| Nama Login
|--------------------------------------------------------------------------
*/

$nama = $_SESSION['nama_lengkap']
        ?? $_SESSION['nama']
        ?? 'Administrator';

?>

<!DOCTYPE html>
<html lang="id"><head>
<meta charset="UTF-8">
<title>Kelola Jadwal</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Segoe UI';background:#f5f7fa;}

.header{
    background:linear-gradient(135deg,#667eea,#764ba2);
    color:#fff;padding:20px 30px;
    display:flex;justify-content:space-between;
}
.modal-header h2{
    font-size:18px;
    font-weight:600;
}
.form-group label{
    font-size:13px;
    margin-bottom:5px;
}
.layout{display:flex;}
.sidebar{width:250px;background:#2c3e50;}
.container{flex:1;padding:30px;}

.page-header{
    display:flex;
    justify-content:space-between;
    margin-bottom:20px;
}

.btn-primary{
    background:linear-gradient(135deg,#667eea,#764ba2);
    color:#fff;padding:10px 20px;
    border:none;border-radius:10px;
    cursor:pointer;
}

.stats-card{
    background:#fff;
    padding:20px;
    border-radius:15px;
    margin-bottom:20px;
}

.table-container{
    background:#fff;
    border-radius:15px;
    overflow:hidden;
}

table{width:100%;border-collapse:collapse;}
thead{
    background:linear-gradient(135deg,#38ef7d,#11998e);
    color:#fff;
}

td,th{padding:12px;}
.action-buttons{
display:flex;
gap:8px;
}
.modal{
display:none;
position:fixed;
left:0;
top:0;
width:100%;
height:100%;
background:rgba(0,0,0,.5);
z-index:999;
}

.modal-content{
    background:#fff;
    margin:3% auto;
    padding:20px;
    border-radius:12px;
    width:70%;
    max-width:480px;
    max-height:85vh;
    overflow-y:auto;
}

.modal-header{

display:flex;

justify-content:space-between;

align-items:center;

margin-bottom:20px;

}

.close{

font-size:28px;

cursor:pointer;

}

.form-group{

margin-bottom:15px;

}

.form-group label{

display:block;

margin-bottom:6px;

font-weight:bold;
.form-group{
    margin-bottom:12px;
}
}

.form-group input,
.form-group select,
.form-group textarea{
    padding:8px 12px;
    height:40px;
    font-size:13px;
    border-radius:8px;
}

.form-group textarea{
    height:80px;
    resize:none;
}
.action-buttons a{
display:inline-block;
padding:7px 12px;

border-radius:6px;

color:white;

text-decoration:none;

font-size:13px;

font-weight:bold;

transition:.3s;

}

.btn-view{

background:#3498db;

}

.btn-view:hover{

background:#2980b9;

}

.btn-edit{

background:#2ecc71;

}

.btn-edit:hover{

background:#27ae60;

}

.btn-delete{

background:#e74c3c;

}

.btn-delete:hover{

background:#c0392b;

}
.btn-submit{
    height:42px;
    font-size:14px;
    border-radius:8px;
}
</style>
</head>
<body>
    <footer
style="
margin-top:40px;
padding:20px;
text-align:center;
color:#777;
font-size:14px;
">

<?= date('Y'); ?> Bimbel Online

</footer>
<div class="layout">
<div class="container">
<div class="page-header">

    <h1>Kelola Pembelajaran</h1>
    <button class="btn-primary" onclick="openModal()">
     Tambah Jadwal
    </button>

</div>

<?php if(isset($_GET['msg'])): ?>

<?php if($_GET['msg']=="success"): ?>

<div style="background:#d4edda;padding:15px;border-radius:8px;margin-bottom:20px;color:#155724;"
Data jadwal berhasil ditambahkan.

</div>

<?php elseif($_GET['msg']=="updated"): ?>

<div style="background:#d4edda;padding:15px;border-radius:8px;margin-bottom:20px;color:#155724;">

Data jadwal berhasil diperbarui.

</div>

<?php elseif($_GET['msg']=="deleted"): ?>

<div style="background:#d4edda;padding:15px;border-radius:8px;margin-bottom:20px;color:#155724;">

Data jadwal berhasil dihapus.

</div>

<?php elseif($_GET['msg']=="error"): ?>

<div style="background:#f8d7da;padding:15px;border-radius:8px;margin-bottom:20px;color:#721c24;">

Terjadi kesalahan.

</div>

<?php endif; ?>

<?php endif; ?>


<div class="stats-card">

<h2><?= $total; ?></h2>

<p>Total Jadwal Mengajar</p>

</div>


<div style="margin-bottom:15px;">

<input
type="text"
id="searchInput"
placeholder="Cari Guru / Mata Pelajaran / Kelas..."
style="
width:100%;
padding:12px;
border-radius:8px;
border:1px solid #ccc;
"
onkeyup="searchTable()">

</div>


<div class="table-container">

<table id="jadwalTable">

<thead>

<tr>

<th>No</th>

<th>Guru</th>

<th>Mata Pelajaran</th>

<th>Kelas</th>

<th>Hari</th>

<th>Jam</th>

<th>Aksi</th>

</tr>

</thead>

<tbody>

<?php

$no=1;

while($row=mysqli_fetch_assoc($result)):

?>

<tr>

<td><?= $no++; ?></td>

<td><?= htmlspecialchars($row['nama_lengkap']); ?></td>

<td><?= htmlspecialchars($row['nama_mapel']); ?></td>

<td><?= htmlspecialchars($row['nama_kelas']); ?></td>

<td><?= htmlspecialchars($row['hari']); ?></td>

<td>

<?= $row['jam_mulai']; ?>

-

<?= $row['jam_selesai']; ?>

<td>

<div class="action-buttons">

<a
href="detail_jadwal.php?id=<?= $row['id']; ?>"
class="btn-view">Lihat</a>

<a href="edit_jadwal.php?id=<?= $row['id']; ?>"
class="btn-edit">Edit</a>
<a href="#"onclick="hapusJadwal(<?= $row['id']; ?>)"
class="btn-delete">Hapus</a>
</div>
</td>
</tr>

<?php endwhile; ?>

</tbody>

</table>

</div>

</div>

</div>

<!-- ================= MODAL TAMBAH JADWAL ================= -->

<div id="modal" class="modal">

<div class="modal-content">

<div class="modal-header">

<h2>Tambah Jadwal Mengajar</h2>

<span class="close" onclick="closeModal()">&times;</span>

</div>

<form action="process_tambah_keuangan.php" method="POST">

<div class="form-group">

<label>Guru</label>

<select name="guru_id" required>

<option value="">-- Pilih Guru --</option>

<?php while($guru=mysqli_fetch_assoc($resultGuru)): ?>

<option value="<?= $guru['id']; ?>">

<?= htmlspecialchars($guru['nama_lengkap']); ?>

</option>

<?php endwhile; ?>

</select>

</div>


<div class="form-group">

<label>Mata Pelajaran</label>

<select name="mapel_id" required>

<option value="">-- Pilih Mata Pelajaran --</option>

<?php while($mapel=mysqli_fetch_assoc($resultMapel)): ?>

<option value="<?= $mapel['id']; ?>">

<?= htmlspecialchars($mapel['nama_mapel']); ?>

</option>

<?php endwhile; ?>

</select>

</div>


<div class="form-group">

<label>Kelas</label>

<select name="kelas_id" required>

<option value="">-- Pilih Kelas --</option>

<?php while($kelas=mysqli_fetch_assoc($resultKelas)): ?>

<option value="<?= $kelas['id']; ?>">

<?= htmlspecialchars($kelas['nama_kelas']); ?>

</option>

<?php endwhile; ?>

</select>

</div>


<div class="form-group">

<label>Hari</label>

<select name="hari" required>

<option value="">Pilih Hari</option>

<option>Senin</option>

<option>Selasa</option>

<option>Rabu</option>

<option>Kamis</option>

<option>Jumat</option>

<option>Sabtu</option>

<option>Minggu</option>

</select>

</div>


<div class="form-group">

<label>Jam Mulai</label>

<input
type="time"
name="jam_mulai"
required>

</div>


<div class="form-group">

<label>Jam Selesai</label>

<input
type="time"
name="jam_selesai"
required>

</div>


<button
type="submit"
class="btn-primary"
style="width:100%;margin-top:10px;">

Simpan Jadwal

</button>

</form>

</div>

</div>


<script>
function openModal(){

    document.getElementById("modal").style.display="block";

}



// TUTUP MODAL // 

function closeModal(){

    document.getElementById("modal").style.display="none";

}



// Klik di luar modal //

window.onclick=function(event){

    let modal=document.getElementById("modal");

    if(event.target==modal){

        modal.style.display="none";

    }

}


// Tombol ESC //
document.addEventListener("keydown",function(e){
    if(e.key==="Escape"){
        closeModal();
    }
});



// SEARCH TABLE //

function searchTable(){

    let input=document.getElementById("searchInput");

    let filter=input.value.toUpperCase();

    let table=document.getElementById("jadwalTable");

    let tr=table.getElementsByTagName("tr");

    for(let i=1;i<tr.length;i++){

        let td=tr[i].getElementsByTagName("td");

        let tampil=false;

        for(let j=0;j<td.length;j++){

            if(td[j]){

                let txt=td[j].textContent || td[j].innerText;

                if(txt.toUpperCase().indexOf(filter)>-1){

                    tampil=true;

                    break;

                }

            }

        }

        tr[i].style.display=tampil ? "" : "none";

    }

}

// KONFIRMASI HAPUS //
function hapusJadwal(id){

    if(confirm("Yakin ingin menghapus jadwal ini?")){

        window.location.href="hapus_jadwal.php?id="+id;

    }

}


// ============================
// AUTO HILANG ALERT
// ============================

setTimeout(function(){

    let alert=document.querySelector(".alert");

    if(alert){

        alert.style.transition="0.5s";

        alert.style.opacity="0";

        setTimeout(function(){

            alert.remove();

        },500);

    }

},3000);

</script>
</body>
</html>