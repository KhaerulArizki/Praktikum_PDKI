<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if($_SERVER['REQUEST_METHOD']!="POST"){
    header("Location: profil_guru.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$nama            = mysqli_real_escape_string($conn,$_POST['nama_lengkap']);
$email           = mysqli_real_escape_string($conn,$_POST['email']);
$nip             = mysqli_real_escape_string($conn,$_POST['nip']);
$mata_pelajaran  = mysqli_real_escape_string($conn,$_POST['mata_pelajaran']);
$no_hp           = mysqli_real_escape_string($conn,$_POST['no_hp']);
$alamat          = mysqli_real_escape_string($conn,$_POST['alamat']);

// Validasi
if(
    empty($nama) ||
    empty($email) ||
    empty($nip) ||
    empty($mata_pelajaran)
){
    header("Location: edit_profil_guru.php?msg=kosong");
    exit;
}

// Update tabel users
$updateUser = mysqli_query($conn,"
UPDATE users SET

nama_lengkap='$nama',
email='$email'

WHERE id='$user_id'
");

// Update tabel guru
$updateGuru = mysqli_query($conn,"
UPDATE guru SET

nip='$nip',
mata_pelajaran='$mata_pelajaran',
no_hp='$no_hp',
alamat='$alamat'

WHERE user_id='$user_id'
");

if($updateUser && $updateGuru){

    header("Location: profil_guru.php?success=1");

}else{

    header("Location: edit_profil_guru.php?msg=error");

}

exit;
?>