<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if (!isset($_SESSION['role'])) {
    header("Location: ../index.php");
    exit;
}
$keyword = "";
if (isset($_GET['cari'])) {
    $keyword = mysqli_real_escape_string($conn, $_GET['cari']);
}
$result_tugas = mysqli_query($conn, "
SELECT
    tugas.id,
    tugas.judul_tugas,
    tugas.deskripsi,
    tugas.file_tugas,
    tugas.deadline,
    tugas.status,
    tugas.created_at,

    kelas.nama_kelas,

    users.nama_lengkap

FROM tugas

LEFT JOIN kelas
ON tugas.kelas_id = kelas.id

LEFT JOIN guru
ON tugas.guru_id = guru.id

LEFT JOIN users
ON guru.user_id = users.id

WHERE
tugas.judul_tugas LIKE '%$keyword%'
OR kelas.nama_kelas LIKE '%$keyword%'
OR users.nama_lengkap LIKE '%$keyword%'

ORDER BY tugas.created_at DESC
");

if (!$result_tugas) {
    die(mysqli_error($conn));
}

$total_tugas = mysqli_num_rows($result_tugas);

$nama = "Admin";
if (isset($_SESSION['nama_lengkap'])) {
    $nama = $_SESSION['nama_lengkap'];
} elseif (isset($_SESSION['nama'])) {
    $nama = $_SESSION['nama'];
}
// Penghapusan diproses oleh hapus_tugas.php
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Kelola Tugas</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
}

body{
font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;
background:#f5f7fa;
}

/* ================= HEADER ================= */

.header{

background:linear-gradient(135deg,#667eea,#764ba2);

color:white;

padding:20px 30px;

display:flex;

justify-content:space-between;

align-items:center;

box-shadow:0 2px 10px rgba(0,0,0,.1);

}

.header-left{

display:flex;

align-items:center;

gap:15px;

}

.header-title h2{

font-size:24px;

font-weight:600;

}

.header-right{

display:flex;

align-items:center;

gap:20px;

}

.user-info{

display:flex;

align-items:center;

gap:10px;

}

.user-avatar{

width:40px;

height:40px;

background:white;

border-radius:50%;

display:flex;

justify-content:center;

align-items:center;

font-weight:bold;

color:#667eea;

}

.logout-btn{

padding:8px 20px;

border-radius:8px;

border:1px solid white;

text-decoration:none;

color:white;

transition:.3s;

}

.logout-btn:hover{

background:white;

color:#667eea;

}

/* ================= LAYOUT ================= */

.layout{

display:flex;

min-height:calc(100vh - 80px);

}

/* ================= SIDEBAR ================= */

.sidebar{

width:250px;

background:#2c3e50;

padding:20px 0;

}

.sidebar-header{

padding:20px;

text-align:center;

color:white;

border-bottom:1px solid rgba(255,255,255,.1);

margin-bottom:10px;

}

.menu-item{

display:flex;

align-items:center;

gap:12px;

padding:15px 30px;

text-decoration:none;

color:#bdc3c7;

transition:.3s;

border-left:3px solid transparent;

}

.menu-item:hover,

.menu-item.active{

background:rgba(52,152,219,.2);

color:white;

border-left:3px solid #3498db;

}

/* ================= CONTENT ================= */

.container{

flex:1;

padding:30px;

overflow:auto;

}

.page-header{

display:flex;

justify-content:space-between;

align-items:center;

margin-bottom:25px;

}

.page-header h1{

font-size:28px;

color:#333;

}

.btn-primary{

background:linear-gradient(135deg,#667eea,#764ba2);

color:white;

padding:12px 24px;

border:none;

border-radius:10px;

cursor:pointer;

font-size:14px;

text-decoration:none;

transition:.3s;

}

.btn-primary:hover{

transform:translateY(-2px);

box-shadow:0 5px 15px rgba(0,0,0,.2);

}

/* ================= CARD ================= */

.stats-card{

background:white;

padding:20px;

border-radius:15px;

box-shadow:0 2px 10px rgba(0,0,0,.08);

display:flex;

align-items:center;

gap:20px;

margin-bottom:20px;

}

.stats-icon{

width:60px;

height:60px;

background:linear-gradient(135deg,#38ef7d,#11998e);

border-radius:15px;

display:flex;

justify-content:center;

align-items:center;

font-size:28px;

color:white;

}

.stats-info h3{

font-size:30px;

color:#333;

}

.stats-info p{

color:#777;

}

/* ================= SEARCH ================= */

.search-box{

background:white;

padding:20px;

border-radius:15px;

box-shadow:0 2px 10px rgba(0,0,0,.08);

margin-bottom:20px;

}

.search-box form{

display:flex;

gap:10px;

}

.search-box input{

flex:1;

padding:12px;

border:2px solid #ddd;

border-radius:10px;

font-size:14px;

}

.search-box input:focus{

outline:none;

border-color:#667eea;

}

/* ================= TABLE ================= */

.table-container{

background:white;

border-radius:15px;

overflow:hidden;

box-shadow:0 2px 10px rgba(0,0,0,.08);

}

table{

width:100%;

border-collapse:collapse;

}

thead{

background:linear-gradient(135deg,#38ef7d,#11998e);

color:white;

}

thead th{

padding:15px;

text-align:left;

}

tbody td{

padding:15px;

border-bottom:1px solid #eee;

font-size:14px;

}

tbody tr:hover{

background:#f8f9fa;

}

.action-buttons{

display:flex;

gap:8px;

}

.btn-edit{

background:#27ae60;

color:white;

padding:6px 12px;

border-radius:6px;

text-decoration:none;

}

.btn-delete{

background:#e74c3c;

color:white;

padding:6px 12px;

border-radius:6px;

text-decoration:none;

}

.btn-view{

background:#3498db;

color:white;

padding:6px 12px;

border-radius:6px;

text-decoration:none;

}

.alert{

padding:15px;

border-radius:10px;

margin-bottom:20px;

}

.alert-success{

background:#d4edda;

color:#155724;

}

.alert-danger{

background:#f8d7da;

color:#721c24;

}

.empty-state{

text-align:center;

padding:60px;

color:#888;

}

.modal{

display:none;

position:fixed;

left:0;

top:0;

width:100%;

height:100%;

background:rgba(0,0,0,.5);

z-index:999;

}

.modal-content{

background:white;

width:700px;

max-width:95%;

margin:50px auto;

padding:30px;

border-radius:15px;

}

.close{

float:right;

font-size:28px;

cursor:pointer;

}

.form-group{

margin-bottom:20px;

}

.form-group label{

display:block;

margin-bottom:8px;

font-weight:bold;

}

.form-group input,

.form-group select,

.form-group textarea{

width:100%;

padding:12px;

border:2px solid #ddd;

border-radius:8px;

}

.form-group textarea{

height:120px;

resize:none;

}

.btn-submit{

width:100%;

background:#667eea;

color:white;

padding:14px;

border:none;

border-radius:10px;

cursor:pointer;

font-size:15px;

}

.btn-submit:hover{

background:#5a67d8;

}

</style>
</head>
<body>

<div class="header">

    <div class="header-left">
        <div class="header-title">
            <h2>Kelola Tugas</h2>
        </div>
    </div>

    <div class="header-right">

        <div class="user-info">

            <div class="user-avatar">

                <?= strtoupper(substr($nama,0,1)); ?>

            </div>

            <span><?= htmlspecialchars($nama); ?></span>

        </div>

        <a href="../logout.php" class="logout-btn">

            Logout

        </a>

    </div>

</div>


<div class="layout">

<div class="sidebar">

<div class="sidebar-header">

<h3>Bimbel Online</h3>
</div>
<a href="kelola_tugas.php" class="menu-item">Kelola Tugas</a>
</div>
<div class="container">
<div class="page-header">
<h1>Tugas</h1>
<div style="display:flex; gap:10px;">
<a href="dashboard_guru.php" class="btn-primary" style="background:#6c757d;">
← Kembali
</a>
<button
class="btn-primary"
onclick="openModal('modalTambahTugas')">
➕ Tambah Tugas
</button>
</div>

</div>
<?php if(isset($_GET['msg'])): ?>
<?php if($_GET['msg']=="success"): ?>

<div class="alert alert-success">

✓ Tugas berhasil ditambahkan.

</div>

<?php elseif($_GET['msg']=="updated"): ?>

<div class="alert alert-success">

✓ Tugas berhasil diperbarui.

</div>

<?php elseif($_GET['msg']=="deleted"): ?>

<div class="alert alert-success">

✓ Tugas berhasil dihapus.

</div>

<?php endif; ?>

<?php endif; ?>

<div class="stats-card">
<div class="stats-icon">
</div>
<div class="stats-info">
<h3><?= $total_tugas; ?></h3>
<p>Total Tugas</p>
</div>
</div>
<div class="search-box">
<form method="GET">
<input type="text"name="cari"
placeholder="Cari Judul Tugas, Guru atau Kelas..."
value="<?= htmlspecialchars($keyword); ?>">
<button class="btn-primary">Cari</button>
</form>
</div>

<div class="table-container">

<?php if(mysqli_num_rows($result_tugas)>0): ?>

<table id="tugasTable">

<thead>

<tr>

<th width="60">No</th>

<th>Judul Tugas</th>

<th>Kelas</th>

<th>Guru</th>

<th>Deadline</th>

<th>Status</th>

<th>File</th>

<th width="180">Aksi</th>

</tr>

</thead>

<tbody>
<?php $no=1;while($row=mysqli_fetch_assoc($result_tugas)):?><tr>
<td><?= $no++; ?></td>
<td>
<b><?= htmlspecialchars($row['judul_tugas']); ?></b><br>
<small>
<?= htmlspecialchars($row['deskripsi']); ?>
</small>
</td>
<td><?= htmlspecialchars($row['nama_kelas']); ?>
</td>
<td><?= htmlspecialchars($row['nama_lengkap']); ?>
</td>
<td><?= date('d-m-Y',strtotime($row['deadline'])); ?>
</td>
<td>
<?php
if($row['status']=="pending"){
echo "<span style='color:#ff9800;font-weight:bold;'>Pending</span>";
}elseif($row['status']=="selesai"){
echo "<span style='color:green;font-weight:bold;'>Selesai</span>";
}else{
echo "<span style='color:red;font-weight:bold;'>".$row['status']."</span>";
}
?>

</td>
<td>
<?php
if(!empty($row['file_tugas'])){?>
<a href="../uploads/tugas/<?= $row['file_tugas']; ?>"
target="_blank"class="btn-view">Download</a>
<?php
}else{
echo "-";
}
?>
</td>
<td>
    
<div class="action-buttons">
<a href="edit_tugas.php?id=<?= $row['id']; ?>" class="btn-edit">
Edit
</a>
<a href="hapus_tugas.php?id=<?= $row['id']; ?>"
class="btn-delete"
onclick="return confirm('Yakin ingin menghapus tugas ini?')">
Hapus
</a>
</div>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>

<div class="empty-state">

<h3>Belum Ada Data Tugas</h3>
<p>
Klik tombol <b>Tambah Tugas</b> untuk menambahkan tugas baru.
</p>
</div>
<?php endif; ?>
</div>
</div>
</div>
<?php if(isset($_GET['msg'])): ?>

<?php if($_GET['msg']=="success"): ?>

<div class="alert alert-success">
✓ Tugas berhasil ditambahkan.
</div>

<?php elseif($_GET['msg']=="updated"): ?>

<div class="alert alert-success">
✓ Tugas berhasil diperbarui.
</div>

<?php elseif($_GET['msg']=="deleted"): ?>

<div class="alert alert-success">
✓ Tugas berhasil dihapus.
</div>

<?php elseif($_GET['msg']=="format"): ?>

<div class="alert alert-danger">
Format file tidak didukung.
</div>

<?php elseif($_GET['msg']=="besar"): ?>

<div class="alert alert-danger">
Ukuran file maksimal 10 MB.
</div>

<?php elseif($_GET['msg']=="error"): ?>

<div class="alert alert-danger">
Terjadi kesalahan saat memproses data.
</div>

<?php endif; ?>

<?php endif; ?>
<!-- ================= MODAL TAMBAH TUGAS ================= -->

<div id="modalTambahTugas" class="modal">

    <div class="modal-content">

        <span class="close"
              onclick="closeModal('modalTambahTugas')">&times;</span>

        <h2 style="margin-bottom:20px;">
            Tambah Tugas
        </h2>
        <form action="proses_tambah_tugas.php"
method="POST"
enctype="multipart/form-data"></form>

            <!-- KELAS -->

            <div class="form-group">

                <label>Kelas</label>

                <select name="kelas_id" required>

                    <option value="">-- Pilih Kelas --</option>

                    <?php

                    $kelas = mysqli_query($conn,"
                    SELECT id,nama_kelas
                    FROM kelas
                    ORDER BY nama_kelas ASC
                    ");

                    while($k=mysqli_fetch_assoc($kelas)){

                    ?>

                    <option value="<?= $k['id']; ?>">

                        <?= htmlspecialchars($k['nama_kelas']); ?>

                    </option>

                    <?php } ?>

                </select>

            </div>


            <!-- GURU -->

            <div class="form-group">

                <label>Guru</label>

                <select name="guru_id" required>

                    <option value="">-- Pilih Guru --</option>

                    <?php

                    $guru=mysqli_query($conn,"
                    SELECT
                    guru.id,
                    users.nama_lengkap

                    FROM guru

                    JOIN users
                    ON guru.user_id=users.id

                    ORDER BY users.nama_lengkap ASC
                    ");

                    while($g=mysqli_fetch_assoc($guru)){

                    ?>

                    <option value="<?= $g['id']; ?>">

                        <?= htmlspecialchars($g['nama_lengkap']); ?>

                    </option>

                    <?php } ?>

                </select>

            </div>


            <!-- JUDUL -->

            <div class="form-group">

                <label>Judul Tugas</label>

                <input
                    type="text"
                    name="judul_tugas"
                    required>

            </div>


            <!-- DESKRIPSI -->

            <div class="form-group">

                <label>Deskripsi</label>

                <textarea
                    name="deskripsi"
                    placeholder="Masukkan deskripsi tugas..."></textarea>

            </div>


            <!-- DEADLINE -->

            <div class="form-group">

                <label>Deadline</label>

                <input
                    type="date"
                    name="deadline"
                    required>

            </div>


            <!-- STATUS -->

            <div class="form-group">

                <label>Status</label>

                <select name="status">

                    <option value="pending">

                        Pending

                    </option>

                    <option value="selesai">

                        Selesai

                    </option>

                </select>

            </div>


            <!-- FILE -->

            <div class="form-group">

                <label>Upload File Tugas</label>

                <input
                    type="file"
                    name="file_tugas">

            </div>


            <button
                type="submit"
                class="btn-submit">

                Simpan Tugas

            </button>

        </form>

    </div>

</div>

<script>

// =======================
// OPEN MODAL
// =======================

function openModal(id){

    document.getElementById(id).style.display="block";

}

// =======================
// CLOSE MODAL
// =======================

function closeModal(id){

    document.getElementById(id).style.display="none";

}

// =======================
// TUTUP MODAL SAAT KLIK DI LUAR
// =======================

window.onclick=function(e){

    if(e.target.classList.contains("modal")){

        e.target.style.display="none";

    }

}

// =======================
// ESC
// =======================

document.addEventListener("keydown",function(e){

    if(e.key==="Escape"){

        let modal=document.getElementsByClassName("modal");

        for(let i of modal){

            i.style.display="none";

        }

    }

});

// =======================
// AUTO HILANG ALERT
// =======================

setTimeout(function(){

    let alert=document.querySelectorAll(".alert");

    alert.forEach(function(item){

        item.style.transition=".5s";

        item.style.opacity="0";

        setTimeout(function(){

            item.remove();

        },500);

    });

},3000);

</script>

</body>
</html>
