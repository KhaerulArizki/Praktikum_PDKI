<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
$user_id = $_SESSION['user_id'];

$query = mysqli_query($conn,"
SELECT
guru.*,
users.nama_lengkap,
users.email
FROM guru
JOIN users ON guru.user_id=users.id
WHERE guru.user_id='$user_id'
");

$data=mysqli_fetch_assoc($query);

if(!$data){
    die("Data guru tidak ditemukan.");
}

if(isset($_POST['update'])){

    $nama=mysqli_real_escape_string($conn,$_POST['nama_lengkap']);
    $email=mysqli_real_escape_string($conn,$_POST['email']);
    $nip=mysqli_real_escape_string($conn,$_POST['nip']);
    $mapel=mysqli_real_escape_string($conn,$_POST['mata_pelajaran']);
    $hp=mysqli_real_escape_string($conn,$_POST['no_hp']);
    $alamat=mysqli_real_escape_string($conn,$_POST['alamat']);

    mysqli_query($conn,"
    UPDATE users SET

    nama_lengkap='$nama',
    email='$email'

    WHERE id='$user_id'
    ");

    mysqli_query($conn,"
    UPDATE guru SET

    nip='$nip',
    mata_pelajaran='$mapel',
    no_hp='$hp',
    alamat='$alamat'

    WHERE user_id='$user_id'
    ");

    header("Location: profil_guru.php?success=1");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Edit Profil Guru</title>

<style>

body{
font-family:Segoe UI;
background:#eef2f7;
}

.container{
width:700px;
margin:40px auto;
background:white;
padding:30px;
border-radius:15px;
box-shadow:0 2px 10px rgba(0,0,0,.15);
}

.form-group{
margin-bottom:18px;
}

label{
display:block;
margin-bottom:8px;
font-weight:bold;
}

input,
textarea{

width:100%;
padding:12px;
border:1px solid #ddd;
border-radius:8px;

}

textarea{
height:120px;
resize:none;
}

button{

background:#667eea;
color:white;
border:none;
padding:12px 25px;
border-radius:8px;
cursor:pointer;

}

a{

background:#6c757d;
color:white;
padding:12px 25px;
text-decoration:none;
border-radius:8px;

}

</style>

</head>

<body>

<div class="container">

<h2>Edit Profil Guru</h2>

<form method="POST">

<div class="form-group">

<label>Nama Lengkap</label>

<input
type="text"
name="nama_lengkap"
value="<?= htmlspecialchars($data['nama_lengkap']); ?>">

</div>

<div class="form-group">

<label>Email</label>

<input
type="email"
name="email"
value="<?= htmlspecialchars($data['email']); ?>">

</div>

<div class="form-group">

<label>NIP</label>

<input
type="text"
name="nip"
value="<?= htmlspecialchars($data['nip']); ?>">

</div>

<div class="form-group">

<label>Mata Pelajaran</label>

<input
type="text"
name="mata_pelajaran"
value="<?= htmlspecialchars($data['mata_pelajaran']); ?>">

</div>

<div class="form-group">

<label>No HP</label>

<input
type="text"
name="no_hp"
value="<?= htmlspecialchars($data['no_hp']); ?>">

</div>

<div class="form-group">

<label>Alamat</label>

<textarea
name="alamat"><?= htmlspecialchars($data['alamat']); ?></textarea>

</div>

<button
type="submit"
name="update">
Simpan Perubahan
</button>
<a href="profil_guru.php">
Kembali
</a>
<?php if(isset($_GET['msg'])): ?>

<?php if($_GET['msg']=="kosong"): ?>

<div style="background:#fff3cd;padding:10px;border-radius:8px;color:#856404;margin-bottom:15px;">
Semua data wajib diisi.
</div>

<?php elseif($_GET['msg']=="error"): ?>

<div style="background:#f8d7da;padding:10px;border-radius:8px;color:#721c24;margin-bottom:15px;">
Gagal menyimpan profil.
</div>

<?php endif; ?>

<?php endif; ?>
</form>

</div>

</body>
</html>