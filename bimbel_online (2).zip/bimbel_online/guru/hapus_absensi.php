<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if (!isset($_GET['id'])) {
    header("Location: kelola_absensi.php");
    exit;
}

$id = intval($_GET['id']);

// Cek data
$cek = mysqli_query($conn,"
SELECT id
FROM absensi
WHERE id='$id'
");

if(mysqli_num_rows($cek)==0){

    header("Location: kelola_absensi.php?msg=error");
    exit;

}

// Hapus data
$query = mysqli_query($conn,"
DELETE FROM absensi
WHERE id='$id'
");

if($query){

    header("Location: kelola_absensi.php?msg=deleted");

}else{

    header("Location: kelola_absensi.php?msg=error");

}

exit;
?>

