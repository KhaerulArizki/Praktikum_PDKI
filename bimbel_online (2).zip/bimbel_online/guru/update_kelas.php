<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if ($_SERVER['REQUEST_METHOD'] != "POST") {
    header("Location: kelola_kelas.php");
    exit;
}

// Ambil data
$id          = intval($_POST['id']);
$nama_kelas  = mysqli_real_escape_string($conn, trim($_POST['nama_kelas']));
$guru_id     = intval($_POST['guru_id']);
$jadwal      = mysqli_real_escape_string($conn, trim($_POST['jadwal']));
$ruangan     = mysqli_real_escape_string($conn, trim($_POST['ruangan']));
$kuota       = intval($_POST['kuota']);
$status      = mysqli_real_escape_string($conn, trim($_POST['status']));

// Validasi
if (
    empty($id) ||
    empty($nama_kelas) ||
    empty($guru_id) ||
    empty($jadwal) ||
    empty($kuota) ||
    empty($status)
) {
    header("Location: edit_kelas.php?id=$id&msg=kosong");
    exit;
}

// Cek apakah nama kelas sudah dipakai kelas lain
$cek = mysqli_query($conn, "
SELECT id
FROM kelas
WHERE nama_kelas='$nama_kelas'
AND id != '$id'
");

if (mysqli_num_rows($cek) > 0) {
    header("Location: edit_kelas.php?id=$id&msg=duplicate");
    exit;
}

// Update data
$query = mysqli_query($conn, "
UPDATE kelas SET
    nama_kelas = '$nama_kelas',
    guru_id    = '$guru_id',
    jadwal     = '$jadwal',
    ruangan    = '$ruangan',
    kuota      = '$kuota',
    status     = '$status'
WHERE id = '$id'
");

if ($query) {

    header("Location: kelola_kelas.php?msg=updated");
    exit;

} else {

    echo "<h3>Gagal memperbarui data.</h3>";
    echo mysqli_error($conn);

}
?>