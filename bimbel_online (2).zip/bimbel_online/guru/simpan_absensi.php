<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if ($_SERVER['REQUEST_METHOD'] != "POST") {
    header("Location: kelola_absensi.php");
    exit;
}

// Ambil data dari form
$siswa_id = intval($_POST['siswa_id']);
$kelas_id = intval($_POST['kelas_id']);
$tanggal  = mysqli_real_escape_string($conn, $_POST['tanggal']);
$status   = mysqli_real_escape_string($conn, $_POST['status']);

// Validasi
if (
    empty($siswa_id) ||
    empty($kelas_id) ||
    empty($tanggal) ||
    empty($status)
) {
    header("Location: kelola_absensi.php?msg=error");
    exit;
}

// Cek apakah siswa sudah melakukan absensi pada tanggal yang sama
$cek = mysqli_query($conn, "
SELECT id
FROM absensi
WHERE siswa_id='$siswa_id'
AND tanggal='$tanggal'
");

if (mysqli_num_rows($cek) > 0) {
    header("Location: kelola_absensi.php?msg=duplicate");
    exit;
}

// Simpan data
$query = mysqli_query($conn, "
INSERT INTO absensi
(
    siswa_id,
    kelas_id,
    tanggal,
    status
)
VALUES
(
    '$siswa_id',
    '$kelas_id',
    '$tanggal',
    '$status'
)
");

if ($query) {

    header("Location: kelola_absensi.php?msg=success");
    exit;

} else {

    header("Location: kelola_absensi.php?msg=error");
    exit;

}
?>