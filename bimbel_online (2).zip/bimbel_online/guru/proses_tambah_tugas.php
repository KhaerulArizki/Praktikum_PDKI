<?php
session_start();
require_once "../config/config.php";

if($_SERVER['REQUEST_METHOD']!="POST"){
    header("Location: kelola_tugas.php");
    exit;
}

require_once "simpan_tugas.php";
?>