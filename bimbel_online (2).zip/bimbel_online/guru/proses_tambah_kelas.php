<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: kelola_kelas.php");
    exit;
}

$nama_kelas = mysqli_real_escape_string($conn, trim($_POST['nama_kelas']));
$guru_id    = intval($_POST['guru_id']);
$jadwal     = mysqli_real_escape_string($conn, trim($_POST['jadwal']));
$ruangan    = mysqli_real_escape_string($conn, trim($_POST['ruangan']));
$kuota      = intval($_POST['kuota']);
$status     = mysqli_real_escape_string($conn, trim($_POST['status']));

// Validasi
if (
    empty($nama_kelas) ||
    empty($guru_id) ||
    empty($jadwal) ||
    empty($kuota) ||
    empty($status)
) {
    header("Location: kelola_kelas.php?msg=kosong");
    exit;
}

// Cek apakah nama kelas sudah ada
$cek = mysqli_query($conn, "
SELECT id
FROM kelas
WHERE nama_kelas='$nama_kelas'
");

if (mysqli_num_rows($cek) > 0) {
    header("Location: kelola_kelas.php?msg=duplicate");
    exit;
}

// Simpan data
$query = mysqli_query($conn, "
INSERT INTO kelas
(
    nama_kelas,
    guru_id,
    jadwal,
    ruangan,
    kuota,
    status
)
VALUES
(
    '$nama_kelas',
    '$guru_id',
    '$jadwal',
    '$ruangan',
    '$kuota',
    '$status'
)
");

if ($query) {

    header("Location: kelola_kelas.php?msg=success");
    exit;

} else {

    echo "Gagal menyimpan data.<br><br>";
    echo mysqli_error($conn);

}
?>