<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if(!isset($_GET['id'])){

    header("Location: kelola_tugas.php");
    exit;

}

$id=intval($_GET['id']);

$data=mysqli_query($conn,"
SELECT file_tugas
FROM tugas
WHERE id='$id'
");

if(mysqli_num_rows($data)==0){

    header("Location: kelola_tugas.php?msg=error");
    exit;

}

$row=mysqli_fetch_assoc($data);

if(!empty($row['file_tugas'])){

    $file="../uploads/tugas/".$row['file_tugas'];

    if(file_exists($file)){
        unlink($file);
    }

}

$query=mysqli_query($conn,"
DELETE FROM tugas
WHERE id='$id'
");

if($query){

    header("Location: kelola_tugas.php?msg=deleted");

}else{

    header("Location: kelola_tugas.php?msg=error");

}

exit;
?>