<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */ 
$id=intval($_POST['id']);

$kelas_id=intval($_POST['kelas_id']);
$guru_id=intval($_POST['guru_id']);
$judul_tugas=mysqli_real_escape_string($conn,$_POST['judul_tugas']);
$deskripsi=mysqli_real_escape_string($conn,$_POST['deskripsi']);
$deadline=$_POST['deadline'];
$status=mysqli_real_escape_string($conn,$_POST['status']);

$data=mysqli_query($conn,"
SELECT file_tugas
FROM tugas
WHERE id='$id'
");

$row=mysqli_fetch_assoc($data);

$namaFile=$row['file_tugas'];

if(isset($_FILES['file_tugas']) && $_FILES['file_tugas']['error']==0){

    if(!empty($namaFile) && file_exists("../uploads/tugas/".$namaFile)){
        unlink("../uploads/tugas/".$namaFile);
    }

    $namaFile=time()."_".basename($_FILES['file_tugas']['name']);

    move_uploaded_file(
        $_FILES['file_tugas']['tmp_name'],
        "../uploads/tugas/".$namaFile
    );

}

$query=mysqli_query($conn,"
UPDATE tugas SET

kelas_id='$kelas_id',
guru_id='$guru_id',
judul_tugas='$judul_tugas',
deskripsi='$deskripsi',
file_tugas='$namaFile',
deadline='$deadline',
status='$status'

WHERE id='$id'
");

if($query){

    header("Location: kelola_tugas.php?msg=updated");

}else{

    header("Location: kelola_tugas.php?msg=error");

}

exit;
?>