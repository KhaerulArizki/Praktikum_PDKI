<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if (!isset($_GET['id'])) {
    header("Location: kelola_kelas.php");
    exit;
}

$id = intval($_GET['id']);

$query = mysqli_query($conn,"
SELECT *
FROM kelas
WHERE id='$id'
");

if(mysqli_num_rows($query)==0){
    header("Location: kelola_kelas.php");
    exit;
}

$data = mysqli_fetch_assoc($query);

if(isset($_POST['update'])){

    $nama_kelas = mysqli_real_escape_string($conn,$_POST['nama_kelas']);
    $guru_id    = intval($_POST['guru_id']);
    $jadwal     = mysqli_real_escape_string($conn,$_POST['jadwal']);
    $ruangan    = mysqli_real_escape_string($conn,$_POST['ruangan']);
    $kuota      = intval($_POST['kuota']);
    $status     = mysqli_real_escape_string($conn,$_POST['status']);

    $update = mysqli_query($conn,"
    UPDATE kelas
    SET
        nama_kelas='$nama_kelas',
        guru_id='$guru_id',
        jadwal='$jadwal',
        ruangan='$ruangan',
        kuota='$kuota',
        status='$status'
    WHERE id='$id'
    ");

    if($update){
        header("Location: kelola_kelas.php?msg=updated");
        exit;
    }else{
        echo mysqli_error($conn);
    }

}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Kelas</title>

<style>

body{
font-family:Segoe UI;
background:#f5f7fa;
}

.container{
width:700px;
margin:40px auto;
background:white;
padding:30px;
border-radius:12px;
box-shadow:0 2px 10px rgba(0,0,0,.15);
}

h2{
margin-bottom:20px;
}

.form-group{
margin-bottom:18px;
}

label{
display:block;
margin-bottom:8px;
font-weight:bold;
}

input,select,textarea{

width:100%;
padding:12px;
border:1px solid #ddd;
border-radius:8px;

}

textarea{

height:100px;

}

button{

background:#667eea;
color:white;
border:none;
padding:12px 25px;
border-radius:8px;
cursor:pointer;

}

a{

text-decoration:none;
padding:12px 20px;
background:#6c757d;
color:white;
border-radius:8px;

}

</style>

</head>
<body>

<div class="container">

<h2>Edit Kelas</h2>

<form method="POST">

<div class="form-group">
<label>Nama Kelas</label>
<input
type="text"
name="nama_kelas"
value="<?= htmlspecialchars($data['nama_kelas']); ?>"
required>
</div>
<div class="form-group">
<label>Guru</label>
<select name="guru_id" required>
<?php
$guru=mysqli_query($conn,"
SELECT
guru.id,
users.nama_lengkap
FROM guru
JOIN users
ON guru.user_id=users.id
ORDER BY users.nama_lengkap ASC
");
while($g=mysqli_fetch_assoc($guru)){
?>
<option
value="<?= $g['id']; ?>"
<?= ($g['id']==$data['guru_id'])?'selected':''; ?>>
<?= htmlspecialchars($g['nama_lengkap']); ?>
</option>
<?php } ?>
</select>
</div>
<div class="form-group">
<label>Jadwal</label>
<input
type="text"
name="jadwal"
value="<?= htmlspecialchars($data['jadwal']); ?>"
required>
</div>
<div class="form-group">
<label>Ruangan</label>
<textarea
name="ruangan"><?= htmlspecialchars($data['ruangan']); ?></textarea>
</div>
<div class="form-group">
<label>Kuota</label>
<input
type="number"
name="kuota"
value="<?= $data['kuota']; ?>"
required>
</div>
<div class="form-group">
<label>Status</label>

<select name="status">

<option value="aktif"
<?=($data['status']=="aktif")?"selected":"";?>>
Aktif
</option>

<option value="nonaktif"
<?=($data['status']=="nonaktif")?"selected":"";?>>
Nonaktif
</option>

</select>

</div>

<button
type="submit"
name="update">

Simpan Perubahan

</button>

<a href="kelola_kelas.php">

Kembali

</a>
<form action="update_kelas.php" method="POST"></form>
<input type="hidden" name="id" value="<?= $data['id']; ?>">
<?php if(isset($_GET['msg'])): ?>

<?php if($_GET['msg']=="duplicate"): ?>
<div style="padding:10px;background:#f8d7da;color:#721c24;border-radius:6px;margin-bottom:15px;">
Nama kelas sudah digunakan.
</div>
<?php endif; ?>

<?php if($_GET['msg']=="kosong"): ?>
<div style="padding:10px;background:#fff3cd;color:#856404;border-radius:6px;margin-bottom:15px;">
Semua data wajib diisi.
</div>
<?php endif; ?>

<?php endif; ?>
<form action="update_kelas.php" method="POST">

<input type="hidden" name="id" value="<?= $data['id']; ?>">

<input type="text" name="nama_kelas" value="<?= htmlspecialchars($data['nama_kelas']); ?>" required>

<select name="guru_id">
    ...
</select>

<input type="text" name="jadwal" value="<?= htmlspecialchars($data['jadwal']); ?>" required>

<input type="text" name="ruangan" value="<?= htmlspecialchars($data['ruangan']); ?>">

<input type="number" name="kuota" value="<?= $data['kuota']; ?>" required>

<select name="status">
    <option value="aktif" <?= $data['status']=="aktif" ? "selected" : ""; ?>>Aktif</option>
    <option value="nonaktif" <?= $data['status']=="nonaktif" ? "selected" : ""; ?>>Nonaktif</option>
</select>

<button type="submit">Simpan Perubahan</button>

</form>
</form>

</div>

</body>
</html>