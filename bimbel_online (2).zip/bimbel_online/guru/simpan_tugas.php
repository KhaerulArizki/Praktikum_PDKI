<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
$kelas_id     = intval($_POST['kelas_id']);
$guru_id      = intval($_POST['guru_id']);
$judul_tugas  = mysqli_real_escape_string($conn,$_POST['judul_tugas']);
$deskripsi    = mysqli_real_escape_string($conn,$_POST['deskripsi']);
$deadline     = $_POST['deadline'];
$status       = mysqli_real_escape_string($conn,$_POST['status']);

$namaFile = "";

if(isset($_FILES['file_tugas']) && $_FILES['file_tugas']['error']==0){

    $folder="../uploads/tugas/";

    if(!is_dir($folder)){
        mkdir($folder,0777,true);
    }

    $namaFile=time()."_".basename($_FILES['file_tugas']['name']);

    move_uploaded_file(
        $_FILES['file_tugas']['tmp_name'],
        $folder.$namaFile
    );

}

$query=mysqli_query($conn,"
INSERT INTO tugas
(
kelas_id,
guru_id,
judul_tugas,
deskripsi,
file_tugas,
deadline,
status
)

VALUES
(
'$kelas_id',
'$guru_id',
'$judul_tugas',
'$deskripsi',
'$namaFile',
'$deadline',
'$status'
)
");

if($query){

    header("Location: kelola_tugas.php?msg=success");

}else{

    header("Location: kelola_tugas.php?msg=error");

}
exit;
?>