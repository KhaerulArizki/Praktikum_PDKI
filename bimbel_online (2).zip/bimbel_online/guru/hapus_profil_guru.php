<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
$user_id=$_SESSION['user_id'];

$guru=mysqli_query($conn,"
SELECT id
FROM guru
WHERE user_id='$user_id'
");

$data=mysqli_fetch_assoc($guru);

if($data){

    mysqli_query($conn,"
    DELETE FROM guru
    WHERE user_id='$user_id'
    ");

}

mysqli_query($conn,"
DELETE FROM users
WHERE id='$user_id'
");

session_destroy();

header("Location: ../index.php");
exit;
?>