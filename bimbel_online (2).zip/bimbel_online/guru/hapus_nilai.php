<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if(!isset($_GET['id'])){

    header("Location: kelola_nilai.php");
    exit;

}

$id=intval($_GET['id']);

$cek=mysqli_query($conn,"
SELECT id
FROM nilai
WHERE id='$id'
");

if(mysqli_num_rows($cek)==0){

    header("Location: kelola_nilai.php?msg=error");
    exit;

}

$query=mysqli_query($conn,"
DELETE FROM nilai
WHERE id='$id'
");

if($query){

    header("Location: kelola_nilai.php?msg=deleted");

}else{

    header("Location: kelola_nilai.php?msg=error");

}

exit;
?>