<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if($_SERVER['REQUEST_METHOD']!="POST"){
    header("Location: kelola_absensi.php");
    exit;
}

$id       = intval($_POST['id']);
$siswa_id = intval($_POST['siswa_id']);
$kelas_id = intval($_POST['kelas_id']);
$tanggal  = mysqli_real_escape_string($conn,$_POST['tanggal']);
$status   = mysqli_real_escape_string($conn,$_POST['status']);

$query=mysqli_query($conn,"
UPDATE absensi SET

siswa_id='$siswa_id',
kelas_id='$kelas_id',
tanggal='$tanggal',
status='$status'

WHERE id='$id'
");

if($query){

header("Location: kelola_absensi.php?msg=updated");

}else{

header("Location: kelola_absensi.php?msg=error");

}
exit;
?>
