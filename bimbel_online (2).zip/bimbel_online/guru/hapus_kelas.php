<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if (!isset($_GET['id'])) {
    header("Location: kelola_kelas.php");
    exit;
}

$id = intval($_GET['id']);

// Cek apakah data kelas ada
$cek = mysqli_query($conn, "SELECT id FROM kelas WHERE id='$id'");

if (mysqli_num_rows($cek) == 0) {
    header("Location: kelola_kelas.php?msg=notfound");
    exit;
}

// Hapus data kelas
$hapus = mysqli_query($conn, "DELETE FROM kelas WHERE id='$id'");

if ($hapus) {
    header("Location: kelola_kelas.php?msg=deleted");
    exit;
} else {
    header("Location: kelola_kelas.php?msg=error");
    exit;
}
?>