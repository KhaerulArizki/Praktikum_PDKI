<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if(!isset($_GET['id'])){
    header("Location: kelola_tugas.php");
    exit;
}

$id = intval($_GET['id']);

$query = mysqli_query($conn,"
SELECT *
FROM tugas
WHERE id='$id'
");

if(mysqli_num_rows($query)==0){
    header("Location: kelola_tugas.php");
    exit;
}

$data = mysqli_fetch_assoc($query);

if(isset($_POST['update'])){

    $kelas_id = intval($_POST['kelas_id']);
    $guru_id = intval($_POST['guru_id']);
    $judul_tugas = mysqli_real_escape_string($conn,$_POST['judul_tugas']);
    $deskripsi = mysqli_real_escape_string($conn,$_POST['deskripsi']);
    $deadline = $_POST['deadline'];
    $status = mysqli_real_escape_string($conn,$_POST['status']);

    mysqli_query($conn,"
    UPDATE tugas SET
        kelas_id='$kelas_id',
        guru_id='$guru_id',
        judul_tugas='$judul_tugas',
        deskripsi='$deskripsi',
        deadline='$deadline',
        status='$status'
    WHERE id='$id'
    ");

    header("Location: kelola_tugas.php?msg=updated");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Edit Tugas</title>

<style>

body{
font-family:Segoe UI;
background:#f5f7fa;
}

.container{
width:700px;
margin:40px auto;
background:#fff;
padding:30px;
border-radius:10px;
box-shadow:0 2px 10px rgba(0,0,0,.2);
}

.form-group{
margin-bottom:18px;
}

label{
display:block;
margin-bottom:8px;
font-weight:bold;
}

input,
select,
textarea{
width:100%;
padding:12px;
border:1px solid #ddd;
border-radius:8px;
}

textarea{
height:120px;
resize:none;
}

button{
padding:12px 25px;
background:#667eea;
color:white;
border:none;
border-radius:8px;
cursor:pointer;
}

a{
padding:12px 25px;
background:#6c757d;
color:white;
text-decoration:none;
border-radius:8px;
}

</style>

</head>
<body>

<div class="container">

<h2>Edit Tugas</h2>

<form method="POST">

<div class="form-group">

<label>Kelas</label>

<select name="kelas_id">

<?php

$kelas=mysqli_query($conn,"SELECT * FROM kelas ORDER BY nama_kelas");

while($k=mysqli_fetch_assoc($kelas)){

?>

<option
value="<?= $k['id'];?>"
<?=($data['kelas_id']==$k['id'])?'selected':'';?>>

<?= $k['nama_kelas'];?>

</option>

<?php } ?>

</select>

</div>

<div class="form-group">

<label>Guru</label>

<select name="guru_id">

<?php

$guru=mysqli_query($conn,"
SELECT guru.id,users.nama_lengkap
FROM guru
JOIN users
ON guru.user_id=users.id
ORDER BY users.nama_lengkap
");

while($g=mysqli_fetch_assoc($guru)){

?>

<option
value="<?= $g['id'];?>"
<?=($data['guru_id']==$g['id'])?'selected':'';?>>

<?= $g['nama_lengkap'];?>

</option>

<?php } ?>

</select>

</div>

<div class="form-group">

<label>Judul Tugas</label>

<input
type="text"
name="judul_tugas"
value="<?= htmlspecialchars($data['judul_tugas']);?>"
required>

</div>

<div class="form-group">

<label>Deskripsi</label>

<textarea
name="deskripsi"><?= htmlspecialchars($data['deskripsi']);?></textarea>

</div>

<div class="form-group">

<label>Deadline</label>

<input
type="date"
name="deadline"
value="<?= $data['deadline'];?>">

</div>

<div class="form-group">

<label>Status</label>

<select name="status">

<option value="pending" <?=($data['status']=="pending")?"selected":"";?>>Pending</option>

<option value="selesai" <?=($data['status']=="selesai")?"selected":"";?>>Selesai</option>

</select>

</div>

<button type="submit" name="update">

Simpan Perubahan

</button>

<a href="kelola_tugas.php">

Kembali

</a>

</form>

</div>

</body>
</html>