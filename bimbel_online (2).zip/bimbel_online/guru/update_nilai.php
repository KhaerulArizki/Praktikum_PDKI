<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if($_SERVER['REQUEST_METHOD']!="POST"){
    header("Location: kelola_nilai.php");
    exit;
}

$id             = intval($_POST['id']);
$siswa_id       = intval($_POST['siswa_id']);
$kelas_id       = intval($_POST['kelas_id']);
$jenis_nilai    = mysqli_real_escape_string($conn,$_POST['jenis_nilai']);
$nilai          = intval($_POST['nilai']);
$keterangan     = mysqli_real_escape_string($conn,$_POST['keterangan']);
$tanggal_input  = mysqli_real_escape_string($conn,$_POST['tanggal_input']);

$query=mysqli_query($conn,"
UPDATE nilai SET

siswa_id='$siswa_id',
kelas_id='$kelas_id',
jenis_nilai='$jenis_nilai',
nilai='$nilai',
keterangan='$keterangan',
tanggal_input='$tanggal_input'

WHERE id='$id'
");

if($query){

    header("Location: kelola_nilai.php?msg=updated");

}else{

    header("Location: kelola_nilai.php?msg=error");

}

exit;
?>