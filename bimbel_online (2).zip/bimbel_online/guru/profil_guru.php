<?php
session_start();
require_once "../config/config.php";

/** @var mysqli $conn */

// Ambil user login
$user_id = $_SESSION['user_id'] ?? 0;

// Ambil data guru + user
$query = mysqli_query($conn, "
SELECT 
    guru.*,
    users.nama_lengkap,
    users.email
FROM guru
JOIN users ON guru.user_id = users.id
WHERE guru.user_id = '$user_id'
");

$data = mysqli_fetch_assoc($query);

if(!$data){
    die("Data guru tidak ditemukan");
}

$nama = $data['nama_lengkap'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profil Guru</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Segoe UI',sans-serif;
    background:#eef2f7;
}

/* CONTAINER */
.wrapper{
    max-width:1000px;
    margin:40px auto;
    padding:20px;
}

/* CARD */
.card{
    background:white;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,.08);
    overflow:hidden;
}

/* HEADER */
.profile-header{
    background:linear-gradient(135deg,#667eea,#764ba2);
    padding:40px;
    color:white;
    display:flex;
    align-items:center;
    gap:20px;
}

/* AVATAR */
.avatar{
    width:80px;
    height:80px;
    border-radius:50%;
    background:white;
    color:#667eea;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:30px;
    font-weight:bold;
}

/* INFO */
.profile-info h2{
    font-size:24px;
}

.profile-info p{
    opacity:.8;
}

/* BODY */
.profile-body{
    padding:30px;
}

/* GRID */
.grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

/* ITEM */
.item{
    background:#f8fafc;
    padding:15px;
    border-radius:12px;
}

.label{
    font-size:12px;
    color:#888;
    margin-bottom:5px;
}

.value{
    font-size:16px;
    font-weight:500;
}

/* QR */
.qr{
    text-align:center;
    margin-top:30px;
}

/* BUTTON */
.actions{
    margin-top:30px;
    display:flex;
    gap:10px;
}

.btn{
    padding:10px 20px;
    border-radius:10px;
    text-decoration:none;
    font-size:14px;
    transition:.3s;
}

.btn-primary{
    background:#667eea;
    color:white;
}

.btn-secondary{
    background:#e2e8f0;
    color:#333;
}

.btn:hover{
    transform:translateY(-2px);
    box-shadow:0 5px 15px rgba(0,0,0,.1);
}

/* RESPONSIVE */
@media(max-width:700px){
    .grid{
        grid-template-columns:1fr;
    }

    .profile-header{
        flex-direction:column;
        text-align:center;
    }
}
</style>
</head>

<body>
<div class="wrapper">
<div class="card">
<div class="profile-header">
    <div class="avatar"><?= strtoupper(substr($nama,0,1)); ?>
    </div>
    <div class="profile-info">
    <h2><?= htmlspecialchars($nama); ?></h2>
    <p><?= htmlspecialchars($data['email']); ?></p>
</div>
</div>

<div class="profile-body">
<div class="grid">
        <div class="item">
    <div class="label">Nama Guru</div>
    <div class="value"><?= htmlspecialchars($nama); ?></div>
</div>
        <div class="label">NIP</div>
        <div class="value"><?= htmlspecialchars($data['nip']); ?></div>
    </div>

    <div class="item">
        <div class="label">Mata Pelajaran</div>
        <div class="value"><?= htmlspecialchars($data['mata_pelajaran']); ?></div>
    </div>

    <div class="item">
        <div class="label">No HP</div>
        <div class="value"><?= htmlspecialchars($data['no_hp']); ?></div>
    </div>

    <div class="item">
        <div class="label">Alamat</div>
        <div class="value">
            <?= $data['alamat'] ? htmlspecialchars($data['alamat']) : '-'; ?>
        </div>
    </div>
</div>

<div class="actions">
<a href="dashboard_guru.php" class="btn btn-secondary">
← Kembali
</a>
<a href="edit_profil_guru.php" class="btn btn-primary">
Edit Profil
</a>
<a href="hapus_profil_guru.php"
class="btn btn-secondary"
style="background:#dc3545;color:white;"
onclick="return confirm('Yakin ingin menghapus akun guru ini?')">
Hapus Profil
</a>
</div>
<?php if(isset($_GET['success'])): ?>
    <div style="background:#d4edda;padding:10px;border-radius:8px;color:#155724;margin-bottom:15px;">
        Profil berhasil diperbarui!
    </div>
<?php endif; ?>
</div>
</div>
</div>

</body>
</html>