<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if($_SERVER['REQUEST_METHOD']!="POST"){
    header("Location: kelola_nilai.php");
    exit;
}
$siswa_id      = intval($_POST['siswa_id']);
$kelas_id      = intval($_POST['kelas_id']);
$jenis_nilai   = mysqli_real_escape_string($conn,$_POST['jenis_nilai']);
$nilai         = intval($_POST['nilai']);
$keterangan    = mysqli_real_escape_string($conn,$_POST['keterangan']);
$tanggal_input = mysqli_real_escape_string($conn,$_POST['tanggal_input']);

if(
    empty($siswa_id) ||
    empty($kelas_id) ||
    empty($jenis_nilai) ||
    empty($tanggal_input)
){
    header("Location: kelola_nilai.php?msg=error");
    exit;
}

// Cek data ganda
$cek=mysqli_query($conn,"
SELECT id
FROM nilai
WHERE siswa_id='$siswa_id'
AND jenis_nilai='$jenis_nilai'
AND tanggal_input='$tanggal_input'
");

if(mysqli_num_rows($cek)>0){

    header("Location: kelola_nilai.php?msg=duplicate");
    exit;

}

$query=mysqli_query($conn,"
INSERT INTO nilai
(
siswa_id,
kelas_id,
jenis_nilai,
nilai,
keterangan,
tanggal_input
)

VALUES
(
'$siswa_id',
'$kelas_id',
'$jenis_nilai',
'$nilai',
'$keterangan',
'$tanggal_input'
)
");

if($query){

    header("Location: kelola_nilai.php?msg=success");

}else{

    header("Location: kelola_nilai.php?msg=error");

}

exit;
?>