<?php
session_start();
require_once "../config/config.php";
if (!isset($_GET['id'])) {
    header("Location: kelola_absensi.php");
    exit;
}
$id = intval($_GET['id']);
/** @var mysqli $conn */
$query = mysqli_query($conn,"
SELECT *
FROM absensi
WHERE id='$id'
");

if(mysqli_num_rows($query)==0){
    header("Location: kelola_absensi.php");
    exit;
}

$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Absensi</title>

<style>

body{
font-family:Segoe UI;
background:#f5f7fa;
}

.container{
width:700px;
margin:40px auto;
background:white;
padding:30px;
border-radius:12px;
box-shadow:0 2px 10px rgba(0,0,0,.15);
}

h2{
margin-bottom:20px;
}

.form-group{
margin-bottom:18px;
}

label{
display:block;
margin-bottom:8px;
font-weight:bold;
}

input,select{
width:100%;
padding:12px;
border:1px solid #ddd;
border-radius:8px;
}

button{
background:#667eea;
color:white;
padding:12px 20px;
border:none;
border-radius:8px;
cursor:pointer;
}

.btn-back{
background:#6c757d;
padding:12px 20px;
color:white;
text-decoration:none;
border-radius:8px;
margin-left:10px;
}

</style>

</head>
<body>

<div class="container">

<h2>Edit Absensi</h2>

<form action="update_absensi.php" method="POST">

<input type="hidden" name="id" value="<?= $data['id']; ?>">

<div class="form-group">

<label>Siswa</label>

<select name="siswa_id" required>

<?php

$siswa=mysqli_query($conn,"
SELECT siswa.id,users.nama_lengkap
FROM siswa
JOIN users
ON siswa.user_id=users.id
ORDER BY users.nama_lengkap
");

while($s=mysqli_fetch_assoc($siswa)){

?>

<option
value="<?= $s['id']; ?>"
<?= ($data['siswa_id']==$s['id'])?"selected":""; ?>>

<?= htmlspecialchars($s['nama_lengkap']); ?>

</option>

<?php } ?>

</select>

</div>

<div class="form-group">

<label>Kelas</label>

<select name="kelas_id" required>

<?php

$kelas=mysqli_query($conn,"
SELECT *
FROM kelas
ORDER BY nama_kelas
");

while($k=mysqli_fetch_assoc($kelas)){

?>

<option
value="<?= $k['id']; ?>"
<?= ($data['kelas_id']==$k['id'])?"selected":""; ?>>

<?= htmlspecialchars($k['nama_kelas']); ?>

</option>

<?php } ?>

</select>

</div>

<div class="form-group">

<label>Tanggal</label>

<input
type="date"
name="tanggal"
value="<?= $data['tanggal']; ?>"
required>

</div>

<div class="form-group">

<label>Status</label>

<select name="status">

<option value="hadir" <?= $data['status']=="hadir"?"selected":""; ?>>Hadir</option>

<option value="izin" <?= $data['status']=="izin"?"selected":""; ?>>Izin</option>

<option value="sakit" <?= $data['status']=="sakit"?"selected":""; ?>>Sakit</option>

<option value="alpha" <?= $data['status']=="alpha"?"selected":""; ?>>Alpha</option>

</select>

</div>

<button type="submit">

Simpan Perubahan

</button>

<a href="kelola_absensi.php" class="btn-back">

Kembali

</a>

</form>

</div>

</body>
</html>