<?php
session_start();
require_once "../config/config.php";

if($_SERVER['REQUEST_METHOD']!="POST"){
    header("Location: profil_guru.php");
    exit;
}

require_once "simpan_profil_guru.php";
?>