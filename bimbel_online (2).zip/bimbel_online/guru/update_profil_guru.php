<?php
session_start();
require_once "../config/config.php";
/** @var mysqli $conn */
if ($_SERVER['REQUEST_METHOD'] != "POST") {
    header("Location: profil_guru.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data dari form
$nama_lengkap   = mysqli_real_escape_string($conn, trim($_POST['nama_lengkap']));
$email          = mysqli_real_escape_string($conn, trim($_POST['email']));
$nip            = mysqli_real_escape_string($conn, trim($_POST['nip']));
$mata_pelajaran = mysqli_real_escape_string($conn, trim($_POST['mata_pelajaran']));
$no_hp          = mysqli_real_escape_string($conn, trim($_POST['no_hp']));
$alamat         = mysqli_real_escape_string($conn, trim($_POST['alamat']));

// Validasi
if (
    empty($nama_lengkap) ||
    empty($email) ||
    empty($nip) ||
    empty($mata_pelajaran)
) {
    header("Location: edit_profil_guru.php?msg=kosong");
    exit;
}

// Cek email digunakan user lain
$cek = mysqli_query($conn, "
SELECT id
FROM users
WHERE email='$email'
AND id != '$user_id'
");

if (mysqli_num_rows($cek) > 0) {
    header("Location: edit_profil_guru.php?msg=email");
    exit;
}

// Update tabel users
$updateUser = mysqli_query($conn, "
UPDATE users
SET
    nama_lengkap='$nama_lengkap',
    email='$email'
WHERE id='$user_id'
");

// Update tabel guru
$updateGuru = mysqli_query($conn, "
UPDATE guru
SET
    nip='$nip',
    mata_pelajaran='$mata_pelajaran',
    no_hp='$no_hp',
    alamat='$alamat'
WHERE user_id='$user_id'
");

if ($updateUser && $updateGuru) {

    header("Location: profil_guru.php?success=1");
    exit;

} else {

    echo "Gagal mengupdate data.<br><br>";
    echo mysqli_error($conn);

}
?>