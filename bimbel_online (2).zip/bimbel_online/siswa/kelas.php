<?php
include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
/** @var int $siswa_id */

$query = mysqli_query($conn, "
    SELECT
        k.nama_kelas,
        k.jadwal,
        k.ruangan,
        mp.nama_mapel,
        u.nama_lengkap AS guru
    FROM pendaftaran_kelas pk
    JOIN kelas k ON pk.kelas_id = k.id
    LEFT JOIN guru g ON k.guru_id = g.id
    LEFT JOIN users u ON g.user_id = u.id
    LEFT JOIN mata_pelajaran mp ON k.mata_pelajaran_id = mp.id
    WHERE pk.siswa_id='$siswa_id'
");
?>

<div class="content">
    <h3>Kelas Saya</h3>

    <div class="card">
        <div class="card-body">
            <table class="table table-bordered">
                <thead class="table-primary">
                    <tr>
                        <th>No</th>
                        <th>Kelas</th>
                        <th>Mapel</th>
                        <th>Guru</th>
                        <th>Jadwal</th>
                        <th>Ruangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php if ($query && mysqli_num_rows($query) > 0): ?>
                        <?php while ($d = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($d['nama_kelas']) ?></td>
                                <td><?= htmlspecialchars($d['nama_mapel'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($d['guru'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($d['jadwal'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($d['ruangan'] ?? '-') ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center text-muted">Belum terdaftar di kelas manapun</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
