<?php
include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
/** @var int $siswa_id */

$query = mysqli_query($conn, "
    SELECT k.nama_kelas, a.tanggal, a.status, a.keterangan
    FROM absensi a
    JOIN kelas k ON a.kelas_id = k.id
    WHERE a.siswa_id='$siswa_id'
    ORDER BY a.tanggal DESC
");

$badge = [
    'hadir' => 'bg-success',
    'izin'  => 'bg-info text-dark',
    'sakit' => 'bg-warning text-dark',
    'alpha' => 'bg-danger',
];
?>

<div class="content">
    <h3>Riwayat Absensi</h3>

    <div class="card">
        <div class="card-body">
            <table class="table table-bordered">
                <thead class="table-primary">
                    <tr>
                        <th>Tanggal</th>
                        <th>Kelas</th>
                        <th>Status</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($query && mysqli_num_rows($query) > 0): ?>
                        <?php while ($a = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= date('d/m/Y', strtotime($a['tanggal'])) ?></td>
                                <td><?= htmlspecialchars($a['nama_kelas']) ?></td>
                                <td>
                                    <span class="badge <?= $badge[$a['status']] ?? 'bg-secondary' ?>">
                                        <?= ucfirst(htmlspecialchars($a['status'])) ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($a['keterangan'] ?? '-') ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="text-center text-muted">Belum ada riwayat absensi</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
