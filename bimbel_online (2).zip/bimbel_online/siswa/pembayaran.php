<?php
include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
/** @var int $siswa_id */

$query = mysqli_query($conn, "
    SELECT p.*, mp.nama_mapel
    FROM pembayaran p
    LEFT JOIN mata_pelajaran mp ON p.mata_pelajaran_id = mp.id
    WHERE p.siswa_id='$siswa_id'
    ORDER BY p.tanggal_tagihan DESC
");
?>

<div class="content">
    <h3>Riwayat Pembayaran</h3>

    <div class="card">
        <div class="card-body">
            <table class="table table-bordered">
                <thead class="table-primary">
                    <tr>
                        <th>Keterangan</th>
                        <th>Mapel</th>
                        <th>Jumlah</th>
                        <th>Tanggal Tagihan</th>
                        <th>Tanggal Bayar</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($query && mysqli_num_rows($query) > 0): ?>
                        <?php while ($p = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= htmlspecialchars($p['keterangan'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['nama_mapel'] ?? '-') ?></td>
                                <td>Rp <?= number_format($p['jumlah'], 0, ',', '.') ?></td>
                                <td><?= date('d/m/Y', strtotime($p['tanggal_tagihan'])) ?></td>
                                <td><?= $p['tanggal_bayar'] ? date('d/m/Y', strtotime($p['tanggal_bayar'])) : '-' ?></td>
                                <td>
                                    <span class="badge <?= $p['status'] === 'Lunas' ? 'bg-success' : 'bg-warning text-dark' ?>">
                                        <?= htmlspecialchars($p['status']) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center text-muted">Belum ada riwayat pembayaran</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
