<?php
include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
/** @var int $siswa_id */

$query = mysqli_query($conn, "
    SELECT
        t.id,
        t.judul_tugas,
        t.deadline,
        k.nama_kelas,
        pt.id AS pengumpulan_id,
        pt.nilai AS nilai_tugas
    FROM tugas t
    JOIN kelas k ON t.kelas_id = k.id
    JOIN pendaftaran_kelas pk ON pk.kelas_id = t.kelas_id
    LEFT JOIN pengumpulan_tugas pt ON pt.tugas_id = t.id AND pt.siswa_id = '$siswa_id'
    WHERE pk.siswa_id='$siswa_id'
    ORDER BY t.deadline ASC
");
?>

<div class="content">
    <h3>Tugas Saya</h3>

    <div class="card">
        <div class="card-body">
            <table class="table table-bordered align-middle">
                <thead class="table-primary">
                    <tr>
                        <th>No</th>
                        <th>Kelas</th>
                        <th>Judul</th>
                        <th>Deadline</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php if ($query && mysqli_num_rows($query) > 0): ?>
                        <?php while ($t = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= htmlspecialchars($t['nama_kelas']) ?></td>
                                <td><?= htmlspecialchars($t['judul_tugas']) ?></td>
                                <td><?= $t['deadline'] ? date('d/m/Y', strtotime($t['deadline'])) : '-' ?></td>
                                <td>
                                    <?php if ($t['pengumpulan_id']): ?>
                                        <span class="badge bg-success">Sudah dikumpulkan<?= $t['nilai_tugas'] !== null ? ' • Nilai: ' . htmlspecialchars($t['nilai_tugas']) : '' ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Belum dikumpulkan</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!$t['pengumpulan_id']): ?>
                                        <a href="upload_tugas.php?id=<?= (int)$t['id'] ?>" class="btn btn-success btn-sm">Upload</a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center text-muted">Belum ada tugas</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
