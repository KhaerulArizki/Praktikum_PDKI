<?php $current = basename($_SERVER['PHP_SELF']); ?>
<div class="sidebar">
    <h4 class="text-center">Bimbel Online</h4>
    <p class="text-center text-white-50" style="font-size:13px;">MENU SISWA</p>
    <hr>

    <a href="dashboard_siswa.php" class="<?= $current === 'dashboard_siswa.php' ? 'active' : '' ?>">
        <i class="fa fa-house"></i> Dashboard
    </a>
    <a href="profil.php" class="<?= $current === 'profil.php' ? 'active' : '' ?>">
        <i class="fa fa-user"></i> Profil
    </a>
    <a href="kelas.php" class="<?= $current === 'kelas.php' ? 'active' : '' ?>">
        <i class="fa fa-school"></i> Kelas Saya
    </a>
    <a href="tugas.php" class="<?= $current === 'tugas.php' ? 'active' : '' ?>">
        <i class="fa fa-book"></i> Tugas
    </a>
    <a href="nilai.php" class="<?= $current === 'nilai.php' ? 'active' : '' ?>">
        <i class="fa fa-star"></i> Nilai
    </a>
    <a href="absensi.php" class="<?= $current === 'absensi.php' ? 'active' : '' ?>">
        <i class="fa fa-check-circle"></i> Absensi
    </a>
    <a href="pembayaran.php" class="<?= $current === 'pembayaran.php' ? 'active' : '' ?>">
        <i class="fa fa-wallet"></i> Pembayaran
    </a>
    <a href="../logout.php">
        <i class="fa fa-sign-out-alt"></i> Logout
    </a>
</div>
