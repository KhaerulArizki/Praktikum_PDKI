<?php
include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
/** @var int $siswa_id */
/** @var array $siswa */

$pesan = "";
$sukses = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $no_hp = mysqli_real_escape_string($conn, trim($_POST['no_hp'] ?? ''));
    $alamat = mysqli_real_escape_string($conn, trim($_POST['alamat'] ?? ''));
    $tanggal_lahir = mysqli_real_escape_string($conn, trim($_POST['tanggal_lahir'] ?? ''));

    $ok1 = mysqli_query($conn, "UPDATE siswa SET no_hp='$no_hp', alamat='$alamat', tanggal_lahir=" . ($tanggal_lahir ? "'$tanggal_lahir'" : "NULL") . " WHERE id='$siswa_id'");

    if ($ok1) {
        $sukses = true;
        // refresh data
        $q = mysqli_query($conn, "SELECT siswa.*, users.nama_lengkap, users.email FROM siswa JOIN users ON siswa.user_id = users.id WHERE siswa.id='$siswa_id'");
        $siswa = mysqli_fetch_assoc($q);
    } else {
        $pesan = "Gagal menyimpan perubahan.";
    }
}
?>

<div class="content">
    <h3>Profil Saya</h3>

    <?php if ($sukses): ?>
        <div class="alert alert-success">Profil berhasil diperbarui.</div>
    <?php elseif ($pesan): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($pesan) ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($siswa['nama_lengkap']) ?>" disabled>
                    <small class="text-muted">Hubungi admin untuk mengubah nama.</small>
                </div>
                <div class="mb-3">
                    <label class="form-label">NIS</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($siswa['nis']) ?>" disabled>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($siswa['email'] ?? '-') ?>" disabled>
                </div>
                <div class="mb-3">
                    <label class="form-label">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control" value="<?= htmlspecialchars($siswa['tanggal_lahir'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">No. HP</label>
                    <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($siswa['no_hp'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" rows="3"><?= htmlspecialchars($siswa['alamat'] ?? '') ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </form>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
