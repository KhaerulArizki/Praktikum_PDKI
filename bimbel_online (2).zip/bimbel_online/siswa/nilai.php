<?php
include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
/** @var int $siswa_id */

$query = mysqli_query($conn, "
    SELECT k.nama_kelas, n.jenis_nilai, n.nilai, n.keterangan, n.tanggal_input
    FROM nilai n
    JOIN kelas k ON n.kelas_id = k.id
    WHERE n.siswa_id='$siswa_id'
    ORDER BY n.tanggal_input DESC
");
?>

<div class="content">
    <h3>Nilai Saya</h3>

    <div class="card">
        <div class="card-body">
            <table class="table table-bordered">
                <thead class="table-primary">
                    <tr>
                        <th>Kelas</th>
                        <th>Jenis</th>
                        <th>Nilai</th>
                        <th>Keterangan</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($query && mysqli_num_rows($query) > 0): ?>
                        <?php while ($n = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= htmlspecialchars($n['nama_kelas']) ?></td>
                                <td><?= htmlspecialchars($n['jenis_nilai']) ?></td>
                                <td><?= htmlspecialchars($n['nilai']) ?></td>
                                <td><?= htmlspecialchars($n['keterangan'] ?? '-') ?></td>
                                <td><?= date('d/m/Y', strtotime($n['tanggal_input'])) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center text-muted">Belum ada nilai</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
