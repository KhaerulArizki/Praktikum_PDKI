<?php
include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
/** @var int $siswa_id */


// Statistik ringkas //
$total_kelas = 0;
$q = mysqli_query($conn, "SELECT COUNT(*) total FROM pendaftaran_kelas WHERE siswa_id='$siswa_id' AND status='aktif'");
if ($q) $total_kelas = mysqli_fetch_assoc($q)['total'];

$tugas_pending = 0;
$q = mysqli_query($conn, "
    SELECT COUNT(*) total
    FROM tugas t
    JOIN pendaftaran_kelas pk ON pk.kelas_id = t.kelas_id
    WHERE pk.siswa_id='$siswa_id'
    AND t.id NOT IN (SELECT tugas_id FROM pengumpulan_tugas WHERE siswa_id='$siswa_id')
");
if ($q) $tugas_pending = mysqli_fetch_assoc($q)['total'];
$tugas_selesai = 0;
$q = mysqli_query($conn, "SELECT COUNT(*) total FROM pengumpulan_tugas WHERE siswa_id='$siswa_id'");
if ($q) $tugas_selesai = mysqli_fetch_assoc($q)['total'];


// Kehadiran //
$total_absen = 0;
$total_hadir = 0;
$q = mysqli_query($conn, "SELECT COUNT(*) total FROM absensi WHERE siswa_id='$siswa_id'");
if ($q) $total_absen = mysqli_fetch_assoc($q)['total'];
$q = mysqli_query($conn, "SELECT COUNT(*) total FROM absensi WHERE siswa_id='$siswa_id' AND status='hadir'");
if ($q) $total_hadir = mysqli_fetch_assoc($q)['total'];
$persentase_kehadiran = $total_absen > 0 ? round(($total_hadir / $total_absen) * 100) : 0;


// Tagihan pending //
$total_pending = 0;
$q = mysqli_query($conn, "SELECT SUM(jumlah) total_pending FROM pembayaran WHERE siswa_id='$siswa_id' AND status='Belum Lunas'");
if ($q) {
    $row = mysqli_fetch_assoc($q);
    $total_pending = $row['total_pending'] ?? 0;
}


// Kelas hari ini (berdasarkan jadwal_mengajar) //
$hari_ini = date('l');
$hari_map = [
    'Monday' => 'Senin', 'Tuesday' => 'Selasa', 'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis', 'Friday' => 'Jumat', 'Saturday' => 'Sabtu', 'Sunday' => 'Minggu'
];
$hari_ini_id = $hari_map[$hari_ini] ?? $hari_ini;

$result_kelas_today = mysqli_query($conn, "
    SELECT k.nama_kelas, k.ruangan, mp.nama_mapel, jm.jam_mulai, jm.jam_selesai
    FROM jadwal_mengajar jm
    JOIN kelas k ON jm.kelas_id = k.id
    JOIN pendaftaran_kelas pk ON pk.kelas_id = k.id
    LEFT JOIN mata_pelajaran mp ON k.mata_pelajaran_id = mp.id
    WHERE pk.siswa_id='$siswa_id'
    AND jm.hari='$hari_ini_id'
    ORDER BY jm.jam_mulai
");

// Tugas pending (belum dikumpulkan) //
$result_tugas_pending = mysqli_query($conn, "
    SELECT t.*, k.nama_kelas
    FROM tugas t
    JOIN kelas k ON t.kelas_id = k.id
    JOIN pendaftaran_kelas pk ON pk.kelas_id = t.kelas_id
    WHERE pk.siswa_id='$siswa_id'
    AND t.id NOT IN (SELECT tugas_id FROM pengumpulan_tugas WHERE siswa_id='$siswa_id')
    ORDER BY t.deadline ASC
    LIMIT 5
");

// Riwayat absensi terbaru // 
$result_absensi_recent = mysqli_query($conn, "
    SELECT a.*, k.nama_kelas
    FROM absensi a
    JOIN kelas k ON a.kelas_id = k.id
    WHERE a.siswa_id='$siswa_id'
    ORDER BY a.tanggal DESC
    LIMIT 5
");


// Riwayat pembayaran terbaru //
$result_pembayaran_recent = mysqli_query($conn, "
    SELECT *
    FROM pembayaran
    WHERE siswa_id='$siswa_id'
    ORDER BY tanggal_tagihan DESC
    LIMIT 5
");


// Mata pelajaran yang sedang diikuti //
$result_mapel = mysqli_query($conn, "
    SELECT DISTINCT mp.nama_mapel, mp.kode_mapel
    FROM mata_pelajaran mp
    JOIN kelas k ON k.mata_pelajaran_id = mp.id
    JOIN pendaftaran_kelas pk ON pk.kelas_id = k.id
    WHERE pk.siswa_id='$siswa_id'
");
?>

<style>
.stats-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:20px; margin-bottom:25px; }
.stat-card{ background:#fff; padding:22px; border-radius:12px; box-shadow:0 2px 10px rgba(0,0,0,.05); display:flex; align-items:center; gap:15px; }
.stat-icon{ width:48px; height:48px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:22px; color:#fff; }
.stat-icon.blue{ background:linear-gradient(135deg,#667eea,#764ba2); }
.stat-icon.red{ background:linear-gradient(135deg,#ff6b6b,#ee5a6f); }
.stat-icon.green{ background:linear-gradient(135deg,#38ef7d,#11998e); }
.stat-icon.orange{ background:linear-gradient(135deg,#f093fb,#f5576c); }
.stat-icon.purple{ background:linear-gradient(135deg,#4facfe,#00f2fe); }
.stat-number{ font-size:26px; font-weight:700; color:#333; }
.stat-label{ font-size:13px; color:#666; }
.content-grid{ display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:20px; }
.card-header{ display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; padding-bottom:12px; border-bottom:2px solid #f0f0f0; }
.class-item{ background:linear-gradient(135deg,#667eea,#764ba2); color:#fff; padding:16px; border-radius:10px; margin-bottom:12px; }
.task-item{ background:#fff4e6; border-left:4px solid #ff9800; padding:14px; border-radius:8px; margin-bottom:10px; }
.absensi-item, .pembayaran-item{ background:#f8f9fa; padding:14px; border-radius:8px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center; }
.status-badge{ padding:5px 12px; border-radius:6px; font-size:12px; font-weight:600; }
.status-badge.hadir{ background:#d4edda; color:#155724; }
.status-badge.izin{ background:#d1ecf1; color:#0c5460; }
.status-badge.sakit{ background:#fff3cd; color:#856404; }
.status-badge.alpha{ background:#f8d7da; color:#721c24; }
.status-badge.lunas{ background:#d4edda; color:#155724; }
.status-badge.belum-lunas{ background:#fff3cd; color:#856404; }
.subjects-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:15px; }
.subject-card{ background:#fff; padding:18px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,.05); }
.empty-state{ text-align:center; padding:30px; color:#999; }
@media (max-width:768px){ .content-grid, .stats-grid{ grid-template-columns:1fr; } }
</style>

<div class="content">

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon blue">📚</div>
            <div><div class="stat-number"><?= $total_kelas ?></div><div class="stat-label">Total Kelas</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon red">📋</div>
            <div><div class="stat-number"><?= $tugas_pending ?></div><div class="stat-label">Tugas Pending</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green">✅</div>
            <div><div class="stat-number"><?= $tugas_selesai ?></div><div class="stat-label">Tugas Selesai</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon orange">📊</div>
            <div><div class="stat-number"><?= $persentase_kehadiran ?>%</div><div class="stat-label">Kehadiran</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon purple">💳</div>
            <div><div class="stat-number">Rp <?= number_format($total_pending, 0, ',', '.') ?></div><div class="stat-label">Tagihan Pending</div></div>
        </div>
    </div>

    <div class="content-grid">
        <div class="card p-3">
            <div class="card-header"><h3>Kelas Hari Ini (<?= htmlspecialchars($hari_ini_id) ?>)</h3></div>
            <?php if ($result_kelas_today && mysqli_num_rows($result_kelas_today) > 0): ?>
                <?php while ($k = mysqli_fetch_assoc($result_kelas_today)): ?>
                    <div class="class-item">
                        <h4><?= htmlspecialchars($k['nama_kelas']) ?></h4>
                        <div><?= htmlspecialchars($k['nama_mapel'] ?? '-') ?></div>
                        <div><?= substr($k['jam_mulai'],0,5) ?> - <?= substr($k['jam_selesai'],0,5) ?> • <?= htmlspecialchars($k['ruangan'] ?? '-') ?></div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state"><p>Tidak ada kelas hari ini</p></div>
            <?php endif; ?>
        </div>

        <div class="card p-3">
            <div class="card-header"><h3>Tugas Pending</h3><a href="tugas.php">Lihat Semua →</a></div>
            <?php if ($result_tugas_pending && mysqli_num_rows($result_tugas_pending) > 0): ?>
                <?php while ($t = mysqli_fetch_assoc($result_tugas_pending)): ?>
                    <div class="task-item">
                        <h4><?= htmlspecialchars($t['judul_tugas']) ?></h4>
                        <div style="display:flex; justify-content:space-between; font-size:13px; color:#666;">
                            <span><?= htmlspecialchars($t['nama_kelas']) ?></span>
                            <span><?= $t['deadline'] ? date('d/m/Y', strtotime($t['deadline'])) : '-' ?></span>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state"><p>Tidak ada tugas pending</p></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="content-grid">
        <div class="card p-3">
            <div class="card-header"><h3>Riwayat Absensi</h3><a href="absensi.php">Lihat Semua →</a></div>
            <?php if ($result_absensi_recent && mysqli_num_rows($result_absensi_recent) > 0): ?>
                <?php while ($a = mysqli_fetch_assoc($result_absensi_recent)): ?>
                    <div class="absensi-item">
                        <div>
                            <h4 style="font-size:14px; margin:0;"><?= htmlspecialchars($a['nama_kelas']) ?></h4>
                            <p style="font-size:12px; color:#666; margin:0;"><?= date('d M Y', strtotime($a['tanggal'])) ?></p>
                        </div>
                        <span class="status-badge <?= strtolower($a['status']) ?>"><?= ucfirst($a['status']) ?></span>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state"><p>Belum ada riwayat absensi</p></div>
            <?php endif; ?>
        </div>

        <div class="card p-3">
            <div class="card-header"><h3>Riwayat Pembayaran</h3><a href="pembayaran.php">Lihat Semua →</a></div>
            <?php if ($result_pembayaran_recent && mysqli_num_rows($result_pembayaran_recent) > 0): ?>
                <?php while ($p = mysqli_fetch_assoc($result_pembayaran_recent)): ?>
                    <div class="pembayaran-item">
                        <div>
                            <div style="font-weight:600; font-size:14px;"><?= htmlspecialchars($p['keterangan'] ?? 'Pembayaran') ?></div>
                            <div style="font-size:12px; color:#666;"><?= date('d M Y', strtotime($p['tanggal_tagihan'])) ?></div>
                        </div>
                        <div style="text-align:right;">
                            <div style="font-weight:700; color:#667eea;">Rp <?= number_format($p['jumlah'], 0, ',', '.') ?></div>
                            <span class="status-badge <?= $p['status'] === 'Lunas' ? 'lunas' : 'belum-lunas' ?>"><?= htmlspecialchars($p['status']) ?></span>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state"><p>Belum ada riwayat pembayaran</p></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card p-3">
        <div class="card-header"><h3>Mata Pelajaran</h3></div>
        <?php if ($result_mapel && mysqli_num_rows($result_mapel) > 0): ?>
            <div class="subjects-grid">
                <?php while ($m = mysqli_fetch_assoc($result_mapel)): ?>
                    <div class="subject-card">
                        <div style="font-size:24px;">📖</div>
                        <h4 style="margin:8px 0 4px;"><?= htmlspecialchars($m['nama_mapel']) ?></h4>
                        <p style="color:#666; font-size:12px; margin:0;"><?= htmlspecialchars($m['kode_mapel'] ?? '') ?></p>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty-state"><p>Belum mengikuti mata pelajaran</p></div>
        <?php endif; ?>
    </div>

</div>

<?php include "footer.php"; ?>
