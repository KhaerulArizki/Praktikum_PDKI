<?php
include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
/** @var int $siswa_id */

$id = intval($_GET['id'] ?? 0);

// Pastikan tugas ini memang untuk siswa yang login (lewat kelas yang dia ikuti)
$cekTugas = mysqli_query($conn, "
    SELECT t.id, t.judul_tugas, k.nama_kelas
    FROM tugas t
    JOIN kelas k ON t.kelas_id = k.id
    JOIN pendaftaran_kelas pk ON pk.kelas_id = t.kelas_id
    WHERE t.id='$id' AND pk.siswa_id='$siswa_id'
");
$tugas = $cekTugas ? mysqli_fetch_assoc($cekTugas) : null;

if (!$tugas) {
    echo "<div class='content'><div class='alert alert-danger'>Tugas tidak ditemukan.</div></div>";
    include "footer.php";
    exit;
}

$pesan = "";

if (isset($_POST['upload']) && isset($_FILES['file'])) {

    if ($_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $pesan = "Gagal mengunggah file.";
    } else {
        $folder = __DIR__ . "/../uploads/tugas_siswa/";
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }

        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        $allowed = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];

        if (!in_array($ext, $allowed)) {
            $pesan = "Format file tidak didukung. Gunakan PDF, DOC, DOCX, JPG, atau PNG.";
        } else {
            $namaFile = "tugas_" . $siswa_id . "_" . $id . "_" . time() . "." . $ext;
            move_uploaded_file($_FILES['file']['tmp_name'], $folder . $namaFile);

            // Cek apakah sudah pernah mengumpulkan, kalau sudah update saja
            $cek = mysqli_query($conn, "SELECT id FROM pengumpulan_tugas WHERE tugas_id='$id' AND siswa_id='$siswa_id'");
            if ($cek && mysqli_num_rows($cek) > 0) {
                $row = mysqli_fetch_assoc($cek);
                mysqli_query($conn, "
                    UPDATE pengumpulan_tugas
                    SET file_tugas='$namaFile', tanggal_kumpul=NOW()
                    WHERE id='" . intval($row['id']) . "'
                ");
            } else {
                mysqli_query($conn, "
                    INSERT INTO pengumpulan_tugas (tugas_id, siswa_id, file_tugas)
                    VALUES ('$id', '$siswa_id', '$namaFile')
                ");
            }

            echo "<script>alert('Tugas berhasil dikumpulkan'); location='tugas.php';</script>";
            exit;
        }
    }
}
?>

<div class="content">
    <h3>Upload Tugas</h3>
    <p class="text-muted"><?= htmlspecialchars($tugas['nama_kelas']) ?> — <?= htmlspecialchars($tugas['judul_tugas']) ?></p>

    <?php if ($pesan): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($pesan) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="card">
            <div class="card-body">
                <input type="file" name="file" class="form-control" required>
                <small class="text-muted">Format: PDF, DOC, DOCX, JPG, PNG</small>
                <br><br>
                <button type="submit" name="upload" class="btn btn-primary">Upload</button>
                <a href="tugas.php" class="btn btn-secondary">Batal</a>
            </div>
        </div>
    </form>
</div>

<?php include "footer.php"; ?>
