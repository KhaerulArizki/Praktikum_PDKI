<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/../config/config.php";
/** @var mysqli $conn */

// Harus login sebagai siswa
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "siswa") {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$siswaQuery = mysqli_query($conn, "
    SELECT siswa.*, users.nama_lengkap, users.email, users.no_hp AS user_no_hp
    FROM siswa
    JOIN users ON siswa.user_id = users.id
    WHERE siswa.user_id = '" . intval($user_id) . "'
");
$siswa = $siswaQuery ? mysqli_fetch_assoc($siswaQuery) : null;

if (!$siswa) {
    // Akun ada tapi data siswa belum dibuat oleh admin
    die("Data siswa tidak ditemukan. Silakan hubungi admin untuk melengkapi data akun Anda.");
}

$siswa_id = $siswa['id'];
$nama = $siswa['nama_lengkap'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Siswa - Bimbel Online</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">

<style>
* { box-sizing: border-box; }
body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:#f4f6f9;
    margin:0;
}
.topbar{
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color:#fff;
    padding:15px 25px;
    margin-left:250px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 2px 10px rgba(0,0,0,.1);
}
.topbar .user-info{ display:flex; align-items:center; gap:10px; }
.topbar .user-avatar{
    width:38px; height:38px; border-radius:50%;
    background:#fff; color:#667eea; font-weight:bold;
    display:flex; align-items:center; justify-content:center;
}
.topbar .logout-btn{
    background:rgba(255,255,255,.2);
    color:#fff; padding:6px 16px; border:1px solid #fff;
    border-radius:8px; text-decoration:none; transition:.3s;
}
.topbar .logout-btn:hover{ background:#fff; color:#667eea; }

.sidebar{
    position:fixed;
    top:0; left:0;
    width:250px;
    height:100%;
    background:#2c3e50;
    padding-top:20px;
    overflow-y:auto;
}
.sidebar h4{ color:#fff; }
.sidebar hr{ border-color:rgba(255,255,255,.15); }
.sidebar a{
    display:flex;
    align-items:center;
    gap:10px;
    padding:13px 20px;
    color:#bdc3c7;
    text-decoration:none;
    border-left:3px solid transparent;
    transition:.2s;
}
.sidebar a:hover, .sidebar a.active{
    background:rgba(52,152,219,.15);
    color:#fff;
    border-left-color:#3498db;
}
.content{
    margin-left:250px;
    padding:25px;
}
.card{
    border:none;
    box-shadow:0 2px 10px rgba(0,0,0,.06);
    border-radius:12px;
}
@media (max-width: 768px){
    .sidebar{ position:relative; width:100%; height:auto; }
    .topbar, .content{ margin-left:0; }
}
</style>
</head>
<body>

<div class="topbar">
    <div><strong>Dashboard Siswa</strong></div>
    <div class="user-info">
        <div class="user-avatar"><?= strtoupper(substr($nama, 0, 1)) ?></div>
        <span><?= htmlspecialchars($nama) ?></span>
        <a href="../logout.php" class="logout-btn">Logout</a>
    </div>
</div>
