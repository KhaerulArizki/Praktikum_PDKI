<?php
session_start();
require_once(__DIR__ . '/config/config.php');
$error="";
if(isset($_POST['login'])){

    $username=mysqli_real_escape_string($conn,$_POST['username']);
    $password=$_POST['password'];
    $role = $_POST['login_as'];

    $query=mysqli_query($conn,"
        SELECT *
        FROM users
        WHERE username='$username'
        AND role='$role'
    ");

    if(mysqli_num_rows($query)>0){

        $data=mysqli_fetch_assoc($query);

        if(password_verify($password,$data['password']) || $password==$data['password']){

            $_SESSION['user_id']=$data['id'];
            $_SESSION['nama']=$data['nama_lengkap'];
            $_SESSION['username']=$data['username'];
            $_SESSION['role']=$data['role'];

            switch($data['role']){

                case "admin":
                    header("Location: admin/dashboard_admin.php");
                break;

                case "guru":
                    header("Location: guru/dashboard_guru.php");
                break;

                case "siswa":
                    header("Location: siswa/dashboard_siswa.php");
                break;

                case "kepala_bimbel":
                    header("Location: kepala_bimbel/dashboard_kepala_bimbel.php");
                break;
            }

            exit;

        }else{

            $error="Password salah.";

        }

    }else{

        $error="Username atau Role salah.";

    }

}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rumah Belajar Mrs,Fifah</title>

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
        }

        body{
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            min-height:100vh;
            color:#333;
        }

        .navbar{
            width:100%;
            background: rgba(255,255,255,0.95);
            padding:15px 40px;
            display:flex;
            justify-content:space-between;
            align-items:center;
            position:sticky;
            top:0;
            z-index:100;
            box-shadow:0 2px 10px rgba(0,0,0,0.1);
        }

        .navbar h2{
            color:#667eea;
        }

        .navbar ul{
            display:flex;
            list-style:none;
            gap:20px;
        }

        .navbar a{
            text-decoration:none;
            color:#333;
            font-weight:600;
            transition:0.3s;
        }

        .navbar a:hover{
            color:#667eea;
        }

        .hero{
            text-align:center;
            padding:80px 20px 50px;
            color:white;
        }

        .hero h1{
            font-size:48px;
            margin-bottom:20px;
        }

        .hero p{
            font-size:18px;
            max-width:700px;
            margin:auto;
            line-height:1.7;
        }

        .content{
            max-width:1200px;
            margin:auto;
            padding:40px 20px;
        }

        .card{
            background:white;
            border-radius:20px;
            padding:35px;
            margin-bottom:30px;
            box-shadow:0 10px 30px rgba(0,0,0,0.1);
        }

        .card h2{
            color:#667eea;
            margin-bottom:15px;
        }

        .visi-misi{
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:20px;
        }

        /* Tentang */
        .about-grid{
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:25px;
            margin-top:25px;
        }

        .about-box{
            background:#f9f9f9;
            border-radius:15px;
            overflow:hidden;
            box-shadow:0 5px 15px rgba(0,0,0,0.08);
            transition:0.3s;
        }

        .about-box:hover{
            transform:translateY(-5px);
        }

        .about-box img{
            width:100%;
            height:250px;
            object-fit:cover;
        }

        .about-box .text{
            padding:20px;
        }

        .about-box h3{
            color:#667eea;
            margin-bottom:10px;
        }

        .about-box p{
            line-height:1.7;
            color:#555;
        }

        .login-container{
            background: rgba(255,255,255,0.95);
            border-radius:30px;
            padding:50px 40px;
            width:100%;
            max-width:420px;
            margin:50px auto;
            box-shadow:0 20px 60px rgba(0,0,0,0.3);
        }

        .logo-section{
            text-align:center;
            margin-bottom:40px;
        }

        .book-icon{
            width:80px;
            height:80px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius:15px;
            margin:0 auto 20px;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:40px;
            box-shadow:0 10px 30px rgba(102,126,234,0.3);
        }

        .subtitle{
            color:#666;
            font-size:14px;
        }

        .form-group{
            margin-bottom:20px;
        }

        label{
            display:block;
            margin-bottom:8px;
            font-weight:600;
        }

        input,
        select{
            width:100%;
            padding:15px;
            border:2px solid #e0e0e0;
            border-radius:10px;
            font-size:14px;
        }

        input:focus,
        select:focus{
            outline:none;
            border-color:#667eea;
        }

        .btn-login{
            width:100%;
            padding:15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color:white;
            border:none;
            border-radius:10px;
            font-size:16px;
            font-weight:bold;
            cursor:pointer;
            transition:0.3s;
        }

        .btn-login:hover{
            transform:translateY(-2px);
        }

        .error-message{
            background:#fee;
            color:#c33;
            padding:12px;
            border-radius:10px;
            margin-bottom:20px;
        }

        .register-link{
            text-align:center;
            margin-top:20px;
        }

        .register-link a{
            color:#667eea;
            text-decoration:none;
            font-weight:bold;
        }

        .info-box{
            background:#e3f2fd;
            padding:15px;
            border-radius:10px;
            margin-top:20px;
            font-size:13px;
        }

        footer{
            text-align:center;
            color:white;
            padding:30px;
        }

        @media(max-width:768px){

            .visi-misi{
                grid-template-columns:1fr;
            }

            .about-grid{
                grid-template-columns:1fr;
            }

            .hero h1{
                font-size:35px;
            }

            .navbar{
                flex-direction:column;
                gap:10px;
            }
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <div class="navbar">
        <h2>Rumah Belajar Mrs.Fifah</h2>

        <ul>
            <li><a href="#beranda">Beranda</a></li>
            <li><a href="#login">Login</a></li>
        </ul>
    </div>

    <!-- Hero -->
    <section class="hero" id="beranda">
        <h1>Selamat Datang di Rumah Belajar Mrs.Fifah</h1>

        <p>
            Platform pembelajaran modern yang membantu siswa belajar
            dengan mudah, interaktif, dan berkualitas bersama guru terbaik.
        </p>
    </section>


    <div class="content">
        <div class="card" id="tentang">

            <h2>Tentang Bimbel</h2>

            <p style="margin-bottom:25px; line-height:1.8;">
                Bimbel Online merupakan sistem informasi rumah belajar yang
                menyediakan layanan pembelajaran digital untuk siswa Paud/TK, SD.
                Kami hadir untuk membantu siswa baca, tulis, dan menghitung. Serta dapat memahami
                materi pelajaran dengan lebih efektif melalui metode belajar
                modern dan interaktif.
            </p>

            <div class="about-grid">

                <!-- Profil -->
                <div class="about-box">

                    <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=1200&auto=format&fit=crop" alt="Profil Bimbel">

                    <div class="text">
                        <h3>Profil Bimbel</h3>

                        <p>
                            Kami memiliki tenaga pengajar profesional dan sistem
                            pembelajaran yang mendukung perkembangan akademik siswa
                            secara maksimal dengan suasana belajar yang nyaman.
                        </p>
                    </div>

                </div>

                <!-- Kegiatan -->
                <div class="about-box">

                    <img src="https://images.unsplash.com/photo-1513258496099-48168024aec0?q=80&w=1200&auto=format&fit=crop" alt="Kegiatan Belajar">

                    <div class="text">
                        <h3>Program Belajar</h3>

                        <p>
                            1. Calistung
                            2. Matematika
                            3. Bimbingan Belajar Sekolah Dasar
                        </p>
                    </div>

                </div>

            </div>

        </div>

        <!-- Visi Misi -->
        <div class="visi-misi" id="visi">

            <div class="card">
                <h2>Visi dan Misi</h2>

                <p>
                   "Mewujudkan Belajar Yang Ramah Anak, 
                   Nyaman dan Berkualitas Tinggi, 
                   Sebagai Pondasi Akhlaqul Karimah"
                </p>
            </div>

        </div>

    </div>

    <!-- Login -->
    <div class="login-container" id="login">

        <div class="logo-section">
            <div class="book-icon">📚</div>

            <h1>Rumah Belajar Mrs.Fifah</h1>

            <p class="subtitle">
                Sistem Informasi Rumah Belajar
            </p>
        </div>

        <?php 
if (!empty($error)) {
?>
    <div class="error-message">
        <?php echo $error; ?>
    </div>
<?php 
}
?>

        <form method="POST" action="">

            <div class="form-group">
                <label>Username</label>

                <input type="text" name="username"
                    placeholder="Masukkan username" required>
            </div>

            <div class="form-group">
                <label>Password</label>

                <input type="password" name="password"
                    placeholder="••••••" required>
            </div>

            <div class="form-group">
                <label>Login Sebagai</label>

                <select name="login_as" required>
                    <option value="">-- Pilih Role --</option>
                    <option value="admin">Admin</option>
                    <option value="guru">Guru</option>
                    <option value="siswa">Siswa</option>
                    <option value="kepala_bimbel">Kepala Bimbel</option>
                </select>
            </div>
            <button
type="submit"
name="login"
class="btn-login">

Login Sekarang

</button>


        </form>

        <div class="register-link">
            Belum punya akun? Hubungi Admin untuk didaftarkan.
        </div>

    </div>

    <footer>
        © 2026 Bimbel Online | Sistem Informasi Rumah Belajar
    </footer>

</body>
</html>