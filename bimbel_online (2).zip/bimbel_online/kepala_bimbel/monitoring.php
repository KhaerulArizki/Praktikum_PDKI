<?php

include "header.php";
include "sidebar.php";

?>

<div class="content">

<div class="card">

<div class="card-header">

Monitoring Pembelajaran

</div>

<div class="card-body">

<ul>

<?php /** @var mysqli $conn */ // <-- Tambahkan ini sekali di atas agar semua $conn di bawahnya aman ?>

<li>Total Guru : <?= mysqli_num_rows(mysqli_query($conn, "SELECT * FROM guru")) ?></li>

<li>Total Siswa : <?= mysqli_num_rows(mysqli_query($conn, "SELECT * FROM siswa")) ?></li>

<li>Total Kelas : <?= mysqli_num_rows(mysqli_query($conn, "SELECT * FROM kelas")) ?></li>

<li>Total Tugas : <?= mysqli_num_rows(mysqli_query($conn, "SELECT * FROM tugas")) ?></li>

<li>Total Nilai : <?= mysqli_num_rows(mysqli_query($conn, "SELECT * FROM nilai")) ?></li>

<li>Total Absensi : <?= mysqli_num_rows(mysqli_query($conn, "SELECT * FROM absensi")) ?></li>

</ul>

</div>

</div>

</div>

<?php include "footer.php"; ?>