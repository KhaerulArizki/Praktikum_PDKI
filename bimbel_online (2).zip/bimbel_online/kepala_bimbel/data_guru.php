<?php
include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
$data = mysqli_query($conn,"
SELECT guru.*,users.nama_lengkap,users.username,users.email
FROM guru
JOIN users ON guru.user_id=users.id
ORDER BY guru.id DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Siswa - Bimbel Online</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }

        /* Header Styles */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo {
            font-size: 24px;
        }

        .header-title h2 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 20px;
            border: 1px solid white;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: white;
            color: #667eea;
        }

        /* Layout Styles */
        .layout {
            display: flex;
            min-height: calc(100vh - 80px);
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: #2c3e50;
            padding: 20px 0;
        }

        .sidebar-header {
            padding: 20px;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 10px;
        }

        .menu-item {
            padding: 15px 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #bdc3c7;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(52, 152, 219, 0.2);
            color: white;
            border-left-color: #3498db;
        }

        .menu-icon {
            font-size: 20px;
        }

        /* Container Styles */
        .container {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 28px;
            color: #333;
        }

        .btn-back {
            background: #95a5a6;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .btn-back:hover {
            background: #7f8c8d;
        }

        /* Form Container */
        .form-container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            max-width: 900px;
        }

        .form-section {
            margin-bottom: 30px;
        }

        .form-section h3 {
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
            font-size: 18px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group label span {
            color: #e74c3c;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-note {
            font-size: 12px;
            color: #999;
            margin-top: 5px;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
            cursor: pointer;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            flex: 1;
            transition: all 0.3s;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-cancel {
            background: #95a5a6;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .btn-cancel:hover {
            background: #7f8c8d;
        }

        /* Alert Messages */
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .layout {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .form-actions {
                flex-direction: column;
            }

            .page-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <div class="logo">🎓</div>
            <div class="header-title">
                <h2>Edit Siswa</h2>
            </div>
        </div>
<div class="header-right">
    <div class="user-info">
        <div class="user-avatar">
            <?php 
                /** @var string $nama */ // <-- Membantu VS Code mengenali variabel $nama
                echo strtoupper(substr($nama, 0, 1)); 
            ?>
        </div>
        <span>
            <?php 
                /** @var string $nama */ // <-- Menghapus garis merah di baris ini juga
                echo htmlspecialchars($nama); 
            ?>
        </span>
    </div>
    <a href="../logout.php" class="logout-btn">Logout</a>
</div>

    <!-- Main Layout -->
    <div class="layout">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>📚 Bimbel Online</h3>
            </div>
            <a href="dashboard_admin.php" class="menu-item">
                <span class="menu-icon">📊</span>
                <span>Dashboard</span>
            </a>
            <a href="kelola_siswa.php" class="menu-item active">
                <span class="menu-icon">🎓</span>
                <span>Kelola Siswa</span>
            </a>
            <a href="kelola_guru.php" class="menu-item">
                <span class="menu-icon">👨‍🏫</span>
                <span>Kelola Guru</span>
            </a>
            <a href="kelola_kelas.php" class="menu-item">
                <span class="menu-icon">🏛️</span>
                <span>Kelola Kelas</span>
            </a>
            <a href="kelola_mapel.php" class="menu-item">
                <span class="menu-icon">📚</span>
                <span>Materi</span>
            </a>
            <a href="jadwal_mengajar.php" class="menu-item">
                <span class="menu-icon">📅</span>
                <span>Jadwal Mengajar</span>
            </a>
            <a href="laporan.php" class="menu-item">
                <span class="menu-icon">📈</span>
                <span>Laporan</span>
            </a>
        </div>

        <!-- Main Container -->
        <div class="container">
            <!-- Page Header -->
            <div class="page-header">
                <h1>Edit Data Siswa</h1>
                <a href="kelola_siswa.php" class="btn-back">
                    ← Kembali
                </a>
            </div>

            <!-- Alert Messages -->
            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-danger">
                    ✗ <?php echo htmlspecialchars($_GET['error']); ?>
                </div>
            <?php endif; ?>

            <!-- Form Container -->
<div class="form-container">
    <?php /** @var array $siswa */ // <-- Tambahkan ini sekali di atas form agar semua $siswa di bawahnya aman ?>
    
    <form action="process_edit_siswa.php" method="POST">
        <input type="hidden" name="siswa_id" value="<?php echo $siswa['id']; ?>">
        <input type="hidden" name="user_id" value="<?php echo $siswa['user_id']; ?>">

        <!-- Informasi Akun -->
        <div class="form-section">
            <h3>📝 Informasi Akun</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Username <span>*</span></label>
                    <input type="text" name="username" value="<?php echo htmlspecialchars($siswa['username']); ?>" required>
                    <div class="form-note">Username untuk login ke sistem</div>
                </div>
                <div class="form-group">
                    <label>Email <span>*</span></label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($siswa['email']); ?>" required>
                </div>
            </div>
        </div>
    </form>
</div>
                        
                        <div class="form-group">
                            <div class="checkbox-group">
                                <input type="checkbox" id="changePassword" name="change_password" value="1">
                                <label for="changePassword" style="margin: 0;">Ubah Password</label>
                            </div>
                        </div>

                        <div class="form-group" id="passwordField" style="display: none;">
                            <label>Password Baru</label>
                            <input type="password" name="password" placeholder="Masukkan password baru">
                            <div class="form-note">Kosongkan jika tidak ingin mengubah password</div>
                        </div>
                    </div>

                    <!-- Data Pribadi -->
                    <div class="form-section">
                        <h3>👤 Data Pribadi</h3>
                        <div class="form-group">
                            <label>Nama Lengkap <span>*</span></label>
                            <input type="text" name="nama_lengkap" value="<?php echo htmlspecialchars($siswa['nama_lengkap']); ?>" required>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>NISN</label>
                                <input type="text" name="nisn" value="<?php echo htmlspecialchars($siswa['nisn']); ?>">
                                <div class="form-note">Nomor Induk Siswa Nasional</div>
                            </div>
                            <div class="form-group">
                                <label>Tanggal Lahir <span>*</span></label>
                                <input type="date" name="tanggal_lahir" value="<?php echo $siswa['tanggal_lahir']; ?>" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>Jenis Kelamin <span>*</span></label>
                                <select name="jenis_kelamin" required>
                                    <option value="">Pilih Jenis Kelamin</option>
                                    <option value="L" <?php echo ($siswa['jenis_kelamin'] == 'L') ? 'selected' : ''; ?>>Laki-laki</option>
                                    <option value="P" <?php echo ($siswa['jenis_kelamin'] == 'P') ? 'selected' : ''; ?>>Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>No. Telepon</label>
                                <input type="text" name="no_telepon" value="<?php echo htmlspecialchars($siswa['no_telepon']); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Alamat <span>*</span></label>
                            <textarea name="alamat" required><?php echo htmlspecialchars($siswa['alamat']); ?></textarea>
                        </div>
                    </div>

                    <!-- Data Orang Tua -->
                    <div class="form-section">
                        <h3>👨‍👩‍👦 Data Orang Tua/Wali</h3>
                        <div class="form-group">
                            <label>Nama Orang Tua/Wali</label>
                            <input type="text" name="nama_ortu" value="<?php echo htmlspecialchars($siswa['nama_ortu']); ?>">
                        </div>
                    </div>

                    <!-- Form Actions -->
                    <div class="form-actions">
                        <a href="kelola_siswa.php" class="btn-cancel">Batal</a>
                        <button type="submit" class="btn-submit">💾 Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        // Toggle password field
        document.getElementById('changePassword').addEventListener('change', function() {
            const passwordField = document.getElementById('passwordField');
            if (this.checked) {
                passwordField.style.display = 'block';
                passwordField.querySelector('input').required = true;
            } else {
                passwordField.style.display = 'none';
                passwordField.querySelector('input').required = false;
                passwordField.querySelector('input').value = '';
            }
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const changePassword = document.getElementById('changePassword').checked;
            const passwordInput = document.querySelector('input[name="password"]');
            
            if (changePassword && passwordInput.value.length < 6) {
                e.preventDefault();
                alert('Password minimal 6 karakter!');
                passwordInput.focus();
            }
        });
    </script>
</body>
</html>