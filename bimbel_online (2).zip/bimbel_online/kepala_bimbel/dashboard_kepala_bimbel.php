<?php
require_once(__DIR__ . '/../config/config.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if(!isset($_SESSION['login'])){
    header("Location: ../index.php");
    exit;
}

if($_SESSION['role']!="kepala_bimbel"){
    header("Location: ../index.php");
    exit;
}
/** @var mysqli $conn */

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'kepala_bimbel') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Memberitahu VS Code bahwa fungsi ini ada (jika fungsi ini dibuat di file lain)
if (function_exists('getDashboardStats')) {
    $stats = getDashboardStats($conn, 'kepala_bimbel');
} else {
    $stats = []; // fallback aman jika fungsi belum terbaca
}

// 2. QUERY LAPORAN
$query_laporan = "SELECT lg.*, u.nama_lengkap as nama_guru
                  FROM laporan_guru lg
                  JOIN guru g ON lg.guru_id = g.id
                  JOIN users u ON g.user_id = u.id
                  ORDER BY lg.created_at DESC
                  LIMIT 3";
$result_laporan = mysqli_query($conn, $query_laporan);

// 3. QUERY MONITORING
$query_monitoring = "SELECT mk.*, k.nama_kelas
                     FROM monitoring_kelas mk
                     JOIN kelas k ON mk.kelas_id = k.id
                     ORDER BY mk.created_at DESC
                     LIMIT 3";
$result_monitoring = mysqli_query($conn, $query_monitoring);

// 4. QUERY KEHADIRAN (Gunakan string biasa tanpa NOW() langsung di string jika VS Code sensitif)
$query_kehadiran = "SELECT u.nama_lengkap, 'Hadir' AS status, NOW() AS waktu
                    FROM users u
                    WHERE u.role = 'guru'
                    LIMIT 3";
$result_kehadiran = mysqli_query($conn, $query_kehadiran);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kepala Bimbel - Bimbel Online</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }
        .header {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    padding: 18px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 6px 20px rgba(0,0,0,0.15);
    position: sticky;
    top: 0;
    z-index: 100;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo-circle {
    width: 48px;
    height: 48px;
    background: rgba(255,255,255,0.15);
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
}

.header-title h2 {
    font-size: 22px;
    font-weight: 700;
    margin: 0;
}

.header-title small {
    font-size: 12px;
    opacity: 0.85;
}

.header-right {
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background: white;
    color: #667eea;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.logout-btn {
    padding: 8px 18px;
    border-radius: 10px;
    border: 1px solid rgba(255,255,255,0.7);
    background: transparent;
    color: white;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
}

.logout-btn:hover {
    background: white;
    color: #667eea;
}


        .layout {
            display: flex;
            min-height: calc(100vh - 80px);
        }

        .sidebar {
            width: 250px;
            background: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.05);
        }

        .menu-item {
            padding: 15px 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #666;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .menu-item:hover, .menu-item.active {
            background: #f0f4ff;
            color: #667eea;
            border-left-color: #667eea;
        }

        .menu-icon {
            font-size: 20px;
        }

        .main-content {
            flex: 1;
            padding: 30px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .stat-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
        }

        .stat-icon.blue {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .stat-icon.green {
            background: linear-gradient(135deg, #38ef7d 0%, #11998e 100%);
        }

        .stat-icon.orange {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        }

        .stat-icon.red {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
        }

        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: #333;
        }

        .stat-label {
            color: #666;
            font-size: 14px;
        }

        .content-section {
            margin-bottom: 30px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-header h3 {
            font-size: 20px;
            color: #333;
        }

        .view-all {
            color: #667eea;
            text-decoration: none;
            font-size: 14px;
        }

        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .report-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }

        .report-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .report-image {
            width: 100%;
            height: 180px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 60px;
        }

        .report-content {
            padding: 20px;
        }

        .report-content h4 {
            font-size: 16px;
            color: #333;
            margin-bottom: 8px;
        }

        .report-content p {
            font-size: 13px;
            color: #666;
            line-height: 1.5;
        }

        .report-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #f0f0f0;
        }

        .report-author {
            font-size: 12px;
            color: #666;
        }

        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-badge.success {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .status-badge.warning {
            background: #fff3e0;
            color: #f57c00;
        }

        .monitoring-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .monitoring-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .monitoring-image {
            width: 100%;
            height: 160px;
            background: linear-gradient(135deg, #38ef7d 0%, #11998e 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
        }

        .monitoring-content {
            padding: 20px;
        }

        .monitoring-content h4 {
            font-size: 15px;
            color: #333;
            margin-bottom: 10px;
        }

        .monitoring-content p {
            font-size: 13px;
            color: #666;
            line-height: 1.5;
        }

        .card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .table-responsive {
            overflow-x: auto;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th {
            background: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-size: 14px;
            color: #333;
            border-bottom: 2px solid #e0e0e0;
        }

        table td {
            padding: 12px;
            font-size: 13px;
            color: #666;
            border-bottom: 1px solid #f0f0f0;
        }

        table tr:hover {
            background: #f8f9fa;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }

        @media (max-width: 768px) {
            .layout {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
            }
            
            .cards-grid, .monitoring-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
   
   <div class="header">
    <div class="header-left">
        <div class="logo-circle">👔</div>
        <div class="header-title">
            <h2>Kepala Bimbel</h2>
            <small>Dashboard Manajemen</small>
        </div>
    </div>

    <div class="header-right">
        <div class="user-avatar">KB</div>
        <a href="../logout.php" class="logout-btn">Logout</a>
    </div>
</div>


    <div class="layout">
        <div class="sidebar">
            <a href="dashboard_kepala_bimbel.php" class="menu-item active">
                <span class="menu-icon">📊</span>
                <span>Dashboard</span>
            </a>
            <a href="#" class="menu-item">
                <span class="menu-icon"></span>
                <span>Data guru</span>
            </a>
            <a href="#" class="menu-item">
                <span class="menu-icon"></span>
                <span>Data siswa</span>
            </a>
            <a href="#" class="menu-item">
                <span class="menu-icon"></span>
                <span>Jadwal mengajar</span>
            </a>
            <a href="#" class="menu-item">
                <span class="menu-icon"></span>
                <span>Data absensi</span>
            </a>
            <a href="#" class="menu-item">
                <span class="menu-icon"></span>
                <span>Data keuangan</span>
            </a>
            <a href="#" class="menu-item">
                <span class="menu-icon"></span>
                <span>Data perkembangan siswa</span>
            </a>
            <a href="#" class="menu-item">
                <span class="menu-icon"></span>
                <span>Data laporan</span>
            </a>
        </div>

       
        <div class="main-content">

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-icon blue">🎓</div>
                        <div>
                            <div class="stat-number"><?php echo $stats['total_siswa']; ?></div>
                            <div class="stat-label">Siswa Aktif</div>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-icon green">👨‍🏫</div>
                        <div>
                            <div class="stat-number"><?php echo $stats['total_guru']; ?></div>
                            <div class="stat-label">Guru Siswa</div>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-icon orange">📚</div>
                        <div>
                            <div class="stat-number"><?php echo $stats['total_kelas']; ?></div>
                            <div class="stat-label">Kelas Berlangsung</div>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-icon red">📊</div>
                        <div>
                            <div class="stat-number"><?php echo $stats['tingkat_kelulusan']; ?>%</div>
                            <div class="stat-label">Tingkat Kelulusan</div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="content-section">
                <div class="section-header">
                    <h3>Laporan Kinerja Guru</h3>
                    <a href="#" class="view-all">Lihat Semua →</a>
                </div>

                <?php if (mysqli_num_rows($result_laporan) > 0): ?>
                    <div class="cards-grid">
                        <?php while ($laporan = mysqli_fetch_assoc($result_laporan)): ?>
                            <div class="report-card">
                                <div class="report-image">👨‍🏫</div>
                                <div class="report-content">
                                    <h4><?php echo htmlspecialchars($laporan['judul_laporan']); ?></h4>
                                    <p><?php echo htmlspecialchars(substr($laporan['deskripsi'], 0, 100)); ?>...</p>
                                    <div class="report-footer">
                                        <span class="report-author">
                                            <?php echo htmlspecialchars($laporan['nama_guru']); ?>
                                        </span>
                                        <span class="status-badge success">
                                            <?php echo htmlspecialchars($laporan['status']); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <p>Belum ada laporan kinerja guru</p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="content-section">
                <div class="section-header">
                    <h3>Monitoring Kelas</h3>
                    <a href="#" class="view-all">Lihat Semua →</a>
                </div>

                <?php if (mysqli_num_rows($result_monitoring) > 0): ?>
                    <div class="monitoring-grid">
                        <?php while ($monitoring = mysqli_fetch_assoc($result_monitoring)): ?>
                            <div class="monitoring-card">
                                <div class="monitoring-image">📹</div>
                                <div class="monitoring-content">
                                    <h4><?php echo htmlspecialchars($monitoring['nama_kelas']); ?></h4>
                                    <p><?php echo htmlspecialchars($monitoring['catatan']); ?></p>
                                    <p style="margin-top: 10px; font-size: 12px; color: #999;">
                                        <?php echo date('d M Y', strtotime($monitoring['tanggal_monitoring'])); ?>
                                    </p>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <p>Belum ada monitoring kelas</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>