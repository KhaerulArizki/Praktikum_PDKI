<?php
include "header.php";
include "sidebar.php";

/** @var mysqli $conn */
$data = mysqli_query($conn,"
SELECT siswa.*, users.nama_lengkap, users.username, users.email
FROM siswa
JOIN users ON siswa.user_id = users.id
ORDER BY siswa.id DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Siswa - Bimbel Online</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
        }

        /* Header Styles */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo {
            font-size: 24px;
        }

        .header-title h2 {
            font-size: 24px;
            font-weight: 600;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 20px;
            border: 1px solid white;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: white;
            color: #667eea;
        }

        /* Layout Styles */
        .layout {
            display: flex;
            min-height: calc(100vh - 80px);
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: #2c3e50;
            padding: 20px 0;
        }

        .sidebar-header {
            padding: 20px;
            color: white;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 10px;
        }

        .menu-item {
            padding: 15px 30px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #bdc3c7;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .menu-item:hover,
        .menu-item.active {
            background: rgba(52, 152, 219, 0.2);
            color: white;
            border-left-color: #3498db;
        }

        .menu-icon {
            font-size: 20px;
        }

        /* Container Styles */
        .container {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 28px;
            color: #333;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        /* Stats Card */
        .stats-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stats-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .stats-info h3 {
            font-size: 32px;
            color: #333;
        }

        .stats-info p {
            color: #666;
            font-size: 14px;
        }

        /* Search Box */
        .search-box {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: #667eea;
        }

        /* Table Styles */
        .table-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        thead th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }

        tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.3s;
        }

        tbody tr:hover {
            background-color: #f8f9fa;
        }

        tbody td {
            padding: 15px;
            font-size: 14px;
            color: #333;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-edit, .btn-delete, .btn-view {
            padding: 6px 12px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }

        .btn-view {
            background: #3498db;
            color: white;
        }

        .btn-edit {
            background: #2ecc71;
            color: white;
        }

        .btn-delete {
            background: #e74c3c;
            color: white;
        }

        .btn-view:hover {
            background: #2980b9;
        }

        .btn-edit:hover {
            background: #27ae60;
        }

        .btn-delete:hover {
            background: #c0392b;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }

        /* Alert Messages */
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            animation: slideDown 0.3s;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .modal-header h2 {
            color: #333;
            font-size: 24px;
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover {
            color: #333;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .layout {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
            }

            .page-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .table-container {
                overflow-x: auto;
            }

            table {
                min-width: 800px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-left">
            <div class="logo">🎓</div>
            <div class="header-title">
                <h2>Kelola Siswa</h2>
            </div>
        </div>
        <div class="header-right">
    <div class="user-info">
        <div class="user-avatar">
            <?php 
                /** @var string $nama */ // <-- Beritahu VS Code bahwa variabel ini ada dan berupa teks
                echo strtoupper(substr($nama, 0, 1)); 
            ?>
        </div>
        <span>
            <?php 
                /** @var string $nama */ // <-- Taruh di sini juga agar garis merahnya hilang total
                echo htmlspecialchars($nama); 
            ?>
        </span>
    </div>
    <a href="../logout.php" class="logout-btn">Logout</a>
</div>

    <!-- Main Layout -->
    <div class="layout">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>📚 Bimbel Online</h3>
            </div>
            <a href="dashboard_admin.php" class="menu-item">
                <span class="menu-icon">📊</span>
                <span>Dashboard</span>
            </a>
            <a href="kelola_siswa.php" class="menu-item active">
                <span class="menu-icon">🎓</span>
                <span>Kelola Siswa</span>
            </a>
            <a href="kelola_guru.php" class="menu-item">
                <span class="menu-icon">👨‍🏫</span>
                <span>Kelola Guru</span>
            </a>
            <a href="kelola_kelas.php" class="menu-item">
                <span class="menu-icon">🏛️</span>
                <span>Kelola Kelas</span>
            </a>
            <a href="kelola_mapel.php" class="menu-item">
                <span class="menu-icon">📚</span>
                <span>Materi</span>
            </a>
            <a href="jadwal_mengajar.php" class="menu-item">
                <span class="menu-icon">📅</span>
                <span>Jadwal Mengajar</span>
            </a>
            <a href="laporan.php" class="menu-item">
                <span class="menu-icon">📈</span>
                <span>Laporan</span>
            </a>
        </div>

        <!-- Main Container -->
        <div class="container">
            <!-- Page Header -->
            <div class="page-header">
                <h1>Manajemen Siswa</h1>
                <button class="btn-primary" onclick="openModal('modalTambahSiswa')">
                    <span>➕</span> Tambah Siswa Baru
                </button>
            </div>

            <!-- Alert Messages -->
            <?php if (isset($_GET['msg'])): ?>
                <?php if ($_GET['msg'] == 'success'): ?>
                    <div class="alert alert-success">
                        ✓ Data siswa berhasil ditambahkan!
                    </div>
                <?php elseif ($_GET['msg'] == 'deleted'): ?>
                    <div class="alert alert-success">
                        ✓ Data siswa berhasil dihapus!
                    </div>
                <?php elseif ($_GET['msg'] == 'updated'): ?>
                    <div class="alert alert-success">
                        ✓ Data siswa berhasil diupdate!
                    </div>
                <?php elseif ($_GET['msg'] == 'error'): ?>
                    <div class="alert alert-danger">
                        ✗ Terjadi kesalahan! Silakan coba lagi.
                    </div>
                <?php endif; ?>
            <?php endif; ?>

          <!-- Stats Card -->
<div class="stats-card">
    <div class="stats-icon">🎓</div>
    <div class="stats-info">
        <h3>
            <?php 
                /** @var int $total_siswa */ // <-- Tambahkan ini untuk memberi tahu VS Code bahwa ini variabel angka yang sah
                echo $total_siswa; 
            ?>
        </h3>
        <p>Total Siswa Terdaftar</p>
    </div>
</div>

            <!-- Search Box -->
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="🔍 Cari siswa berdasarkan nama, email, atau NISN..." onkeyup="searchTable()">
            </div>

            <!-- Table Container -->
<div class="table-container">
    <?php 
        /** @var mysqli_result $result_siswa */ // <-- Tambahkan ini untuk memberi tahu VS Code bahwa variabel ini ada
        if (mysqli_num_rows($result_siswa) > 0): 
    ?>
        <table id="siswaTable">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NISN</th>
                    <th>Nama Lengkap</th>
                    <th>Email</th>
                    <th>No. Telepon</th>
                    <th>Tanggal Lahir</th>
                    <th>Nama Orang Tua</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                while($siswa = mysqli_fetch_assoc($result_siswa)): 
                ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo htmlspecialchars($siswa['nisn'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($siswa['nama_lengkap']); ?></td>
                                    <td><?php echo htmlspecialchars($siswa['email']); ?></td>
                                    <td><?php echo htmlspecialchars($siswa['no_telepon'] ?? '-'); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($siswa['tanggal_lahir'])); ?></td>
                                    <td><?php echo htmlspecialchars($siswa['nama_ortu'] ?? '-'); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="#" class="btn-view" onclick="viewSiswa(<?php echo $siswa['id']; ?>)">👁️ Lihat</a>
                                            <a href="#" class="btn-edit" onclick="editSiswa(<?php echo $siswa['id']; ?>)">✏️ Edit</a>
                                            <a href="#" class="btn-delete" onclick="deleteSiswa(<?php echo $siswa['id']; ?>, '<?php echo htmlspecialchars($siswa['nama_lengkap']); ?>')">🗑️ Hapus</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-state-icon">📚</div>
                        <h3>Belum Ada Data Siswa</h3>
                        <p>Klik tombol "Tambah Siswa Baru" untuk menambahkan siswa pertama Anda.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal Tambah Siswa -->
    <div id="modalTambahSiswa" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Tambah Siswa Baru</h2>
                <span class="close" onclick="closeModal('modalTambahSiswa')">&times;</span>
            </div>
            <form action="process_tambah_siswa.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>Nama Lengkap *</label>
                        <input type="text" name="nama_lengkap" required placeholder="Masukkan nama lengkap">
                    </div>
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" name="email" required placeholder="contoh@email.com">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Username *</label>
                        <input type="text" name="username" required placeholder="Username untuk login">
                    </div>
                    <div class="form-group">
                        <label>Password *</label>
                        <input type="password" name="password" required placeholder="Minimal 6 karakter">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>NISN</label>
                        <input type="text" name="nisn" placeholder="Nomor Induk Siswa Nasional">
                    </div>
                    <div class="form-group">
                        <label>Tanggal Lahir *</label>
                        <input type="date" name="tanggal_lahir" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Jenis Kelamin *</label>
                        <select name="jenis_kelamin" required>
                            <option value="">Pilih Jenis Kelamin</option>
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>No. Telepon</label>
                        <input type="text" name="no_telepon" placeholder="08xxxxxxxxxx">
                    </div>
                </div>
                <div class="form-group">
                    <label>Alamat *</label>
                    <textarea name="alamat" required placeholder="Alamat lengkap siswa"></textarea>
                </div>
                <div class="form-group">
                    <label>Nama Orang Tua</label>
                    <input type="text" name="nama_ortu" placeholder="Nama orang tua/wali">
                </div>
                <button type="submit" class="btn-submit">Tambah Siswa</button>
            </form>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        // Modal Functions
        function openModal(modalId) {
            document.getElementById(modalId).style.display = "block";
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = "none";
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = "none";
            }
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === "Escape") {
                const modals = document.getElementsByClassName('modal');
                for (let modal of modals) {
                    modal.style.display = "none";
                }
            }
        });

        // Search Function
        function searchTable() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('siswaTable');
            
            if (!table) return;
            
            const tr = table.getElementsByTagName('tr');

            for (let i = 1; i < tr.length; i++) {
                const td = tr[i].getElementsByTagName('td');
                let found = false;
                
                for (let j = 0; j < td.length; j++) {
                    if (td[j]) {
                        const txtValue = td[j].textContent || td[j].innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            found = true;
                            break;
                        }
                    }
                }
                
                tr[i].style.display = found ? "" : "none";
            }
        }

        // View Siswa
        function viewSiswa(id) {
            window.location.href = 'detail_siswa.php?id=' + id;
        }

        // Edit Siswa
        function editSiswa(id) {
            window.location.href = 'edit_siswa.php?id=' + id;
        }

        // Delete Siswa
        function deleteSiswa(id, nama) {
            if (confirm('Apakah Anda yakin ingin menghapus siswa "' + nama + '"?\n\nData yang dihapus tidak dapat dikembalikan!')) {
                window.location.href = 'kelola_siswa.php?action=delete&id=' + id;
            }
        }

        // Auto hide alert messages
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                alert.style.transition = 'opacity 0.5s';
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.remove();
                }, 500);
            });
        }, 3000);
    </script>
</body>
</html>