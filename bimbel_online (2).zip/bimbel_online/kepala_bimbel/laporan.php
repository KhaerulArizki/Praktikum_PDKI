<?php

include "header.php";
include "sidebar.php";

?>

<div class="content">

<div class="card">

<div class="card-body">

<h3>Laporan Sistem</h3>

<p>

Menu ini nantinya digunakan untuk:

</p>

<ul>

<li>Cetak Data Guru</li>

<li>Cetak Data Siswa</li>

<li>Cetak Nilai</li>

<li>Cetak Absensi</li>

<li>Export Excel</li>

<li>Export PDF</li>

</ul>

</div>

</div>

</div>

<?php include "footer.php"; ?>