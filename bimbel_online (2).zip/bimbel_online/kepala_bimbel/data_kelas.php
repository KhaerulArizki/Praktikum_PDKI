<?php

include "header.php";
include "sidebar.php";
/** @var mysqli $conn */
$data=mysqli_query($conn,"
SELECT
kelas.*,
mata_pelajaran.nama_mapel
FROM kelas
LEFT JOIN mata_pelajaran
ON kelas.mata_pelajaran_id=mata_pelajaran.id
");
?>

<div class="content">

<h3>Data Kelas</h3>

<table class="table table-bordered">

<tr>

<th>Kelas</th>

<th>Mapel</th>

<th>Ruangan</th>

<th>Status</th>

</tr>

<?php while($d=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $d['nama_kelas'] ?></td>

<td><?= $d['nama_mapel'] ?></td>

<td><?= $d['ruangan'] ?></td>

<td><?= ucfirst($d['status']) ?></td>

</tr>

<?php } ?>

</table>

</div>

<?php include "footer.php"; ?>